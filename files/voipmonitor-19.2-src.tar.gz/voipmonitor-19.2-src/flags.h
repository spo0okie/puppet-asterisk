#ifndef FLAGS_H
#define FLAGS_H


#define T38FAX 		1 << 0
#define T38FAXRESET 	1 << 1
#define T30FAX 		1 << 2


#endif //FLAGS_H
