#ifndef MOS_G729_H
#define MOS_G729_H


long double mos_g729(long double l, long double b);


#endif //MOS_G729_H
