#ifndef HASH_H
#define HASH_H


void init_hash();
u_int mkhash (u_int , u_short , u_int , u_short);


#endif //HASH_H
