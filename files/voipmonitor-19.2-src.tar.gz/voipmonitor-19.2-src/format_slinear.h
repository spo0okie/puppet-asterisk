#ifndef FORMAT_SLINEAR_H
#define FORMAT_SLINEAR_H


void slinear_saturated_add(short *input, short *value);


#endif //FORMAT_SLINEAR_H
