#include "config.h"
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>
#include <unistd.h>
#include <string>
#include <fcntl.h>
#include <errno.h>
#include <syslog.h>
#include <netdb.h>
#include <resolv.h>
#include <vorbis/codec.h>
#include <vorbis/vorbisenc.h>
#include <pcap.h>
#include <math.h>
#include <time.h>

#ifdef HAVE_LIBSSH
#include <libssh/libssh.h>
#include <libssh/callbacks.h>
#endif 

#include <openssl/crypto.h>  

#include <sstream>

#include "ipaccount.h"
#include "voipmonitor.h"
#include "calltable.h"
#include "sniff.h"
#include "format_slinear.h"
#include "codec_alaw.h"
#include "codec_ulaw.h"
#include "tools.h"
#include "calltable.h"
#include "format_ogg.h"
#include "cleanspool.h"
#include "pcap_queue.h"
#include "manager.h"
#include "country_detect.h"
#include "fraud.h"
#include "rrd.h"
#include "tar.h"
#include "http.h"
#include "send_call_info.h"
#include "config_param.h"
#include "sniff_proc_class.h"
#include "register.h"

#ifndef FREEBSD
#include <malloc.h>
#endif

//#define BUFSIZE 1024
//define BUFSIZE 20480
#define BUFSIZE 4096		//block size?

extern Calltable *calltable;
extern int terminating;
extern int opt_manager_port;
extern char opt_manager_ip[32];
extern int opt_manager_nonblock_mode;
extern volatile int calls_counter;
extern volatile int registers_counter;
extern char opt_clientmanager[1024];
extern int opt_clientmanagerport;
extern char mac[32];
extern int verbosity;
extern char opt_php_path[1024];
extern int manager_socket_server;
extern int opt_nocdr;
extern int global_livesniffer;
extern map<unsigned int, octects_live_t*> ipacc_live;

extern map<unsigned int, livesnifferfilter_t*> usersniffer;
extern volatile int usersniffer_sync;

extern char ssh_host[1024];
extern int ssh_port;
extern char ssh_username[256];
extern char ssh_password[256];
extern char ssh_remote_listenhost[1024];
extern unsigned int ssh_remote_listenport;
extern int enable_bad_packet_order_warning;
extern ip_port opt_pcap_queue_send_to_ip_port;

extern cConfig CONFIG;
extern bool useNewCONFIG;
extern volatile bool cloud_activecheck_sshclose;

int opt_blocktarwrite = 0;
int opt_blockasyncprocess = 0;
int opt_blockprocesspacket = 0;
int opt_sleepprocesspacket = 0;
int opt_blockqfile = 0;
int opt_block_alloc_stack = 0;

using namespace std;

struct listening_worker_arg {
	Call *call;
};

static void updateLivesnifferfilters();
static bool cmpCallBy_destroy_call_at(Call* a, Call* b);
static bool cmpCallBy_first_packet_time(Call* a, Call* b);
static int sendFile(const char *fileName, int client, ssh_channel sshchannel, bool zip);
static int sendString(string *str, int client, ssh_channel sshchannel, bool zip);

livesnifferfilter_use_siptypes_s livesnifferfilterUseSipTypes;

ManagerClientThreads ClientThreads;

volatile int ssh_threads;
volatile int ssh_threads_break; 

class c_getfile_in_tar_completed {
public:
	c_getfile_in_tar_completed() {
		_sync = 0;
	}
	void add(const char *tar, const char *file, const char *key) {
		lock();
		data[string(tar) + "/" + file + "/" + key] = getTimeMS();
		unlock();
	}
	bool check(const char *tar, const char *file, const char *key) {
		lock();
		map<string, u_long>::iterator iter = data.find(string(tar) + "/" + file + "/" + key);
		bool rslt =  iter != data.end();
		unlock();
		cleanup();
		return(rslt);
	}
	void cleanup() {
		lock();
		u_long actTime = getTimeMS();
		map<string, u_long>::iterator iter = data.begin();
		while(iter != data.end()) {
			if(actTime - iter->second > 10000ul) {
				data.erase(iter++);
			} else {
				++iter;
			}
		}
		unlock();
	}
	void lock() {
		while(__sync_lock_test_and_set(&_sync, 1));
	}
	void unlock() {
		__sync_lock_release(&_sync);
	}
private:
	map<string, u_long> data;
	volatile int _sync;
} getfile_in_tar_completed;

class c_listening_clients {
public:
	struct s_client {
		s_client(const char *id, Call *call) {
			this->id = id;
			this->call = call;
			last_activity_time = getTimeS();
			spybuffer_start_pos = 0;
			spybuffer_last_send_pos = 0;
		}
		string id;
		Call *call;
		u_int32_t last_activity_time;
		u_int64_t spybuffer_start_pos;
		u_int64_t spybuffer_last_send_pos;
	};
public:
	c_listening_clients() {
		_sync = 0;
		_sync_map = 0;
	}
	~c_listening_clients() {
		lock_map();
		while(clients.size()) {
			map<string, s_client*>::iterator iter = clients.begin();
			delete iter->second;
			clients.erase(iter++);
		}
		unlock_map();
	}
	s_client *add(const char *id, Call *call) {
		s_client *client = new FILE_LINE(13001) s_client(id, call);
		string cid = string(id) + '/' + intToString((long long)call);
		lock_map();
		clients[cid] = client;
		unlock_map();
		return(client);
	}
	s_client *get(const char *id, Call *call) {
		string cid = string(id) + '/' + intToString((long long)call);
		lock_map();
		map<string, s_client*>::iterator iter = clients.find(cid);
		if(iter != clients.end()) {
			unlock_map();
			return(iter->second);
		} else {
			unlock_map();
			return(NULL);
		}
	}
	void remove(const char *id, Call *call) {
		string cid = string(id) + '/' + intToString((long long)call);
		lock_map();
		map<string, s_client*>::iterator iter = clients.find(cid);
		if(iter != clients.end()) {
			delete iter->second;
			clients.erase(iter);
		}
		unlock_map();
	}
	void remove(s_client *client) {
		remove(client->id.c_str(), client->call);
	}
	void cleanup() {
		lock_map();
		u_int64_t actTime = getTimeS();
		for(map<string, s_client*>::iterator iter = clients.begin(); iter != clients.end(); ) {
			if(iter->second->last_activity_time < actTime - 10) {
				delete iter->second;
				clients.erase(iter++);
			} else {
				iter++;
			}
		}
		unlock_map();
	}
	bool exists(Call *call) {
		bool exists = false;
		for(map<string, s_client*>::iterator iter = clients.begin(); iter != clients.end(); iter++) {
			if(iter->second->call == call) {
				exists = true;
				break;
			}
		}
		return(exists);
	}
	u_int64_t get_min_use_spybuffer_pos(Call *call) {
		u_int64_t min_pos = (u_int64_t)-1;
		lock_map();
		for(map<string, s_client*>::iterator iter = clients.begin(); iter != clients.end(); iter++) {
			if(iter->second->call == call &&
			   max(iter->second->spybuffer_start_pos, iter->second->spybuffer_last_send_pos) < min_pos) {
				min_pos = max(iter->second->spybuffer_start_pos, iter->second->spybuffer_last_send_pos);
			}
		}
		unlock_map();
		return(min_pos == (u_int64_t)-1 ? 0 : min_pos);
	}
	void lock() {
		while(__sync_lock_test_and_set(&_sync, 1));
	}
	void unlock() {
		__sync_lock_release(&_sync);
	}
	void lock_map() {
		while(__sync_lock_test_and_set(&_sync_map, 1));
	}
	void unlock_map() {
		__sync_lock_release(&_sync_map);
	}
private:
	map<string, s_client*> clients;
	volatile int _sync;
	volatile int _sync_map;
} listening_clients;

class c_listening_workers {
public:
	struct s_worker {
		s_worker(Call *call) {
			this->call = call;
			spybuffer = new FILE_LINE(13002) FifoBuffer((string("spybuffer for call ") + call->call_id).c_str());
			spybuffer->setMinItemBufferLength(1000);
			spybuffer->setMaxSize(10000000);
			thread = 0;
			running = false;
			stop = false;
		}
		~s_worker() {
			if(spybuffer) {
				delete spybuffer;
			}
		}
		Call *call;
		FifoBuffer *spybuffer;
		pthread_t thread;
		volatile bool running;
		volatile bool stop;
	};
	c_listening_workers() {
		_sync = 0;
		_sync_map = 0;
	}
	~c_listening_workers() {
		lock_map();
		while(workers.size()) {
			map<Call*, s_worker*>::iterator iter = workers.begin();
			delete iter->second;
			workers.erase(iter++);
		}
		unlock_map();
	}
	s_worker *add(Call *call) {
		s_worker *worker = new FILE_LINE(13003) s_worker(call);
		lock_map();
		workers[call] = worker;
		unlock_map();
		return(worker);
	}
	s_worker *get(Call *call) {
		lock_map();
		map<Call*, s_worker*>::iterator iter = workers.find(call);
		if(iter != workers.end()) {
			unlock_map();
			return(iter->second);
		} else {
			unlock_map();
			return(NULL);
		}
	}
	void remove(Call *call) {
		lock_map();
		map<Call*, s_worker*>::iterator iter = workers.find(call);
		if(iter != workers.end()) {
			iter->second->call->disableListeningBuffers();
			delete iter->second;
			workers.erase(iter);
		}
		unlock_map();
	}
	void remove(s_worker *worker) {
		remove(worker->call);
	}
	void run(s_worker *worker) {
		worker->call->createListeningBuffers();
		worker->running = true;
		worker->stop = false;
		vm_pthread_create_autodestroy("manager - listening worker",
					      &worker->thread, NULL, worker_thread_function, (void*)worker, __FILE__, __LINE__);
	}
	void stop(s_worker *worker) {
		worker->stop = true;
	}
	static void *worker_thread_function(void *arguments);
	void cleanup() {
		for(map<Call*, s_worker*>::iterator iter = workers.begin(); iter != workers.end(); ) {
			if(!listening_clients.exists(iter->second->call)) {
				stop(iter->second);
				while(iter->second->running) {
					usleep(100);
				}
			}
			if(!iter->second->running) {
				iter->second->call->disableListeningBuffers();
				delete iter->second;
				workers.erase(iter++);
			} else {
				iter++;
			}
		}
	}
	void lock() {
		while(__sync_lock_test_and_set(&_sync, 1));
	}
	void unlock() {
		__sync_lock_release(&_sync);
	}
	void lock_map() {
		while(__sync_lock_test_and_set(&_sync_map, 1));
	}
	void unlock_map() {
		__sync_lock_release(&_sync_map);
	}
private:
	map<Call*, s_worker*> workers;
	volatile int _sync;
	volatile int _sync_map;
} listening_workers;

/* 
 * this function runs as thread. It reads RTP audio data from call
 * and write it to output buffer 
 *
 * input parameter is structure where call 
 *
*/
void* c_listening_workers::worker_thread_function(void *arguments) {
 
	c_listening_workers::s_worker *worker = (c_listening_workers::s_worker*)arguments;
	Call *call = worker->call;
	worker->running = true;

	alaw_init();
	ulaw_init();

	// if call is hanged hup it will set listening_worker_run in its destructor to 0
	int listening_worker_run = 1;
	call->listening_worker_run = &listening_worker_run;
	pthread_mutex_lock(&call->listening_worker_run_lock);

	FILE *out = NULL;
	if(sverb.call_listening) {
		out = fopen("/tmp/test.raw", "w");
	}

	/*
	vorbis_desc ogg;
	ogg_header(out, &ogg);
	fclose(out);
	pthread_mutex_lock(&args->call->buflock);
	(&args->call->spybufferchar, &ogg);
	pthread_mutex_unlock(&args->call->buflock);
	*/

	unsigned long long begin_time_us = 0;
	unsigned long long end_time_us = 0;
	unsigned long long prev_process_time_us = 0;
        struct timeval tvwait;

	
	unsigned int period_msec = 50;
	unsigned int period_samples = 8000 * period_msec / 1000;
	u_char *spybufferchunk = new FILE_LINE(13004) u_char[period_samples * 2];
	u_int32_t len1, len2;
	short int r1, r2;
	char *s16char;
	
        while(listening_worker_run && !worker->stop) {

		/*
		while(max(call->audiobuffer1->size_get(), call->audiobuffer2->size_get()) < period_msec * 2) {
			usleep(period_msec * 1000);
		}
		*/
	 
		prev_process_time_us = end_time_us - begin_time_us;

		tvwait.tv_sec = 0;
		tvwait.tv_usec = 1000 * period_msec - prev_process_time_us;
		select(0, NULL, NULL, NULL, &tvwait);

		begin_time_us = getTimeUS();
		
		len1 = call->audiobuffer1->size_get();
		len2 = call->audiobuffer2->size_get();

		/*
		printf("codec_caller[%d] codec_called[%d] len1[%d] len2[%d]\n", 
		       worker->call->codec_caller, 
		       worker->call->codec_called,
		       len1, len2);
		*/
		
		if(len1 >= period_samples || len2 >= period_samples) {
			if(len1 >= period_samples && len2 >= period_samples) {
				len1 = period_samples;
				len2 = period_samples;
				unsigned char *read1 = call->audiobuffer1->pop(&len1);
				unsigned char *read2 = call->audiobuffer2->pop(&len2);
				for(unsigned int i = 0; i < len1; i++) {
					switch(call->codec_caller) {
					case 0:
						r1 = ULAW(read1[i]);
						break;
					case 8:
						r1 = ALAW(read1[i]);
						break;
					}
					switch(call->codec_caller) {
					case 0:
						r2 = ULAW(read2[i]);
						break;
					case 8:
						r2 = ALAW(read2[i]);
						break;
					}
					s16char = (char *)&r1;
					slinear_saturated_add((short int*)&r1, (short int*)&r2);
					if(sverb.call_listening) {
						fwrite(&r1, 1, 2, out);
					}
					spybufferchunk[i * 2] = s16char[0];
					spybufferchunk[i * 2 + 1] = s16char[1];
				}
				delete [] read1;
				delete [] read2;
			} else if(len2 >= period_samples) {
				len2 = period_samples;
				unsigned char *read2 = call->audiobuffer2->pop(&len2);
				for(unsigned int i = 0; i < len2; i++) {
					switch(call->codec_caller) {
					case 0:
						r2 = ULAW(read2[i]);
						break;
					case 8:
						r2 = ALAW(read2[i]);
						break;
					}
					if(sverb.call_listening) {
						fwrite(&r2, 1, 2, out);
					}
					s16char = (char *)&r2;
					spybufferchunk[i * 2] = s16char[0];
					spybufferchunk[i * 2 + 1] = s16char[1];
				}
				delete [] read2;
			} else if(len1 >= period_samples) {
				len1 = period_samples;
				unsigned char *read1 = call->audiobuffer1->pop(&len1);
				for(unsigned int i = 0; i < len1; i++) {
					switch(call->codec_caller) {
					case 0:
						r1 = ULAW(read1[i]);
						break;
					case 8:
						r1 = ALAW(read1[i]);
						break;
					}
					if(sverb.call_listening) {
						fwrite(&r1, 1, 2, out);
					}
					s16char = (char *)&r1;
					spybufferchunk[i * 2] = s16char[0];
					spybufferchunk[i * 2 + 1] = s16char[1];
				}
				delete [] read1;
			}
			worker->spybuffer->lock_master();
			worker->spybuffer->push(spybufferchunk, period_samples * 2);
			worker->spybuffer->unlock_master();
		}
		
		end_time_us = getTimeUS();
        }

	if(sverb.call_listening) {
		fclose(out);
	}
	
	/*
	//clean ogg
        ogg_stream_clear(&ogg.os);
        vorbis_block_clear(&ogg.vb);
        vorbis_dsp_clear(&ogg.vd);
        vorbis_comment_clear(&ogg.vc);
        vorbis_info_clear(&ogg.vi);
        */

	delete [] spybufferchunk;

	// reset pointer to NULL as we are leaving the stack here
	call->listening_worker_run = NULL;
	pthread_mutex_unlock(&call->listening_worker_run_lock);
	
	worker->running = false;
	
	return 0;
}

void listening_master_lock() {
	calltable->lock_calls_listMAP();
	listening_workers.lock();
	listening_clients.lock();
}

void listening_master_unlock() {
	listening_clients.unlock();
	listening_workers.unlock();
	calltable->unlock_calls_listMAP();
}

void listening_cleanup() {
	listening_master_lock();
	listening_clients.cleanup();
	listening_workers.cleanup();
	listening_master_unlock();
}

void listening_remove_worker(Call *call) {
	listening_master_lock();
	listening_workers.remove(call);
	listening_master_unlock();
}

#ifdef HAVE_LIBSSH
int sendssh(ssh_channel channel, const char *buf, int len) {
	int wr, i;
	wr = 0;
	do {   
		i = ssh_channel_write(channel, buf, len);
		if (i < 0) {
			fprintf(stderr, "libssh_channel_write: %d\n", i);
			return -1;
		}
		wr += i;
	} while(i > 0 && wr < len);
	return wr;
}
#else 
int sendssh(ssh_channel channel, const char *buf, int len) {
	return 0;
}
#endif

int sendvm(int socket, ssh_channel channel, const char *buf, size_t len, int /*mode*/) {
	int res;
	if(channel) {
		res = sendssh(channel, buf, len);
	} else {
		res = send(socket, buf, len, 0);
	}
	return res;
}

int _sendvm(int socket, void *channel, const char *buf, size_t len, int mode) {
	return(sendvm(socket, (ssh_channel)channel, buf, len, mode));
}

int sendvm_from_stdout_of_command(char *command, int socket, ssh_channel channel, char */*buf*/, size_t /*len*/, int /*mode*/) {
	SimpleBuffer out;
	if(vm_pexec(command, &out) && out.size()) {
		if(sendvm(socket, channel, (const char*)out.data(), out.size(), 0) == -1) {
			if (verbosity > 0) syslog(LOG_NOTICE, "sendvm_from_stdout_of_command: sending data problem");
			return -1;
		}
	}
	return 0;
	
	/* obsolete
 
//using pipe for reading from stdout of given command;
    int retch;
    long total = 0;

    FILE *inpipe;
    
    cout << command << endl;
    
    inpipe = popen(command, "r");

    if (!inpipe) {
        syslog(LOG_ERR, "sendvm_from_stdout_of_command: couldn't open pipe for command %s", command);
        return -1;
    }

//     while (retch = fread(buf, sizeof(char), len, inpipe) > 0) {
// 		total += retch;
// 		syslog(LOG_ERR, "CTU: buflen:%d nacetl jsem %li create command",buflen, total);
// 
// 		if (sendvm(socket, channel, buf, retch, 0) == -1) {
// 			if (verbosity > 1) syslog(LOG_NOTICE, "Pipe RET %li bytes, problem sending using sendvm", total);
// 			return -1;
// 		}
//     }

	int filler = 0;		//'offset' buf pointer
	retch = 0;

	//read char by char from a pipe
    while ((retch = fread(buf + filler, 1, 1, inpipe)) > 0) {
		total ++;
		filler ++;

		if (filler == BUFSIZE) {
			filler = 0;
			if (sendvm(socket, channel, buf, BUFSIZE, 0) == -1) 
			{
				if (verbosity > 0) syslog(LOG_NOTICE, "sendvm_from_stdout_of_command: Pipe RET %li bytes, but problem sending using sendvm1", total);
				return -1;
			}
		}
    }
	if (filler > 0) {
		if (sendvm(socket, channel, buf, filler, 0) == -1) {
			if (verbosity > 0) syslog(LOG_NOTICE, "sendvm_from_stdout_of_command: Pipe RET %li bytes, but problem sending using sendvm2", total);
			return -1;
		}
	}

	if (verbosity > 1) syslog(LOG_NOTICE, "sendvm_from_stdout_of_command: Read total %li chars.", total);
    pclose(inpipe);
    return 0; 
	*/
}

static volatile bool enable_parse_command = false;

void manager_parse_command_enable() {
	enable_parse_command = true;
}

void manager_parse_command_disable() {
	enable_parse_command = false;
}

int parse_command(char *buf, int size, int client, int eof, ManagerClientThread **managerClientThread = NULL, ssh_channel sshchannel = NULL) {
	if(!enable_parse_command) {
		return(0);
	}
 
	char buf_output[1024];
 
	char *pointerToEndSeparator = strstr(buf, "\r\n");
	if(pointerToEndSeparator) {
		*pointerToEndSeparator = 0;
	}
	if(sverb.manager) {
		cout << "manager command: " << buf << "|END" << endl;
	}
 
	char sendbuf[BUFSIZE];
	u_int32_t uid = 0;

	if(strstr(buf, "getversion") != NULL) {
		if ((size = sendvm(client, sshchannel, RTPSENSOR_VERSION, strlen(RTPSENSOR_VERSION), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "creategraph") != NULL) {
		checkRrdVersion(true);
		extern int vm_rrd_version;
		if(!vm_rrd_version) {
			if ((size = sendvm(client, sshchannel, "missing rrdtool", 15, 0)) == -1){
				cerr << "Error sending data to client" << endl;
				return -1;
			}
			return 0;
		}
	 
		extern pthread_mutex_t vm_rrd_lock;
		pthread_mutex_lock(&vm_rrd_lock);
		
		int res = 0;
		int manager_argc;
		char *manager_cmd_line = NULL;	//command line passed to voipmonitor manager
		char **manager_args = NULL;		//cuted voipmonitor manager commandline to separate arguments
	
		sendbuf[0] = 0;			//for reseting sendbuf

		if (( manager_argc = vm_rrd_countArgs(buf)) < 6) {	//few arguments passed
			if (verbosity > 0) syslog(LOG_NOTICE, "parse_command creategraph too few arguments, passed%d need at least 6!\n", manager_argc);
			snprintf(sendbuf, BUFSIZE, "Syntax: creategraph graph_type linuxTS_from linuxTS_to size_x_pixels size_y_pixels  [ slope-mode  [ icon-mode  [ color  [ dstfile ]]]]\n");
			if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
				cerr << "Error sending data to client 1" << endl;
			}
			pthread_mutex_unlock(&vm_rrd_lock);
			return -1;
		}
		if ((manager_cmd_line = new FILE_LINE(13005) char[strlen(buf) + 1]) == NULL) {
			syslog(LOG_ERR, "parse_command creategraph malloc error\n");
			pthread_mutex_unlock(&vm_rrd_lock);
			return -1;
		}
		if ((manager_args = new FILE_LINE(13006) char*[manager_argc + 1]) == NULL) {
			delete [] manager_cmd_line;
			syslog(LOG_ERR, "parse_command creategraph malloc error2\n");
			pthread_mutex_unlock(&vm_rrd_lock);
			return -1;
		}
		
		memcpy(manager_cmd_line, buf, strlen(buf));
		manager_cmd_line[strlen(buf)] = '\0';

		syslog(LOG_NOTICE, "creategraph VERBOSE ALL: %s", manager_cmd_line);
		if ((manager_argc = vm_rrd_createArgs(manager_cmd_line, manager_args))) {
			//Arguments:
			//0-creategraphs
			//1-graph type
			//2-at-style time from
			//3-at-style time to
			//4-total size x
			//5-total size y
			//[6-zaobleni hran(slope-mode)]
			//[7-discard graphs legend (for sizes bellow 600x240)]
			//[8-color]
			//[9-dstfile (if not defined PNG goes to stdout)]
			if (sverb.rrd_info) {
				syslog(LOG_NOTICE, "%d arguments detected. Showing them:\n", manager_argc);
				for (int i = 0; i < manager_argc; i++) {
					syslog (LOG_NOTICE, "%d.arg:%s",i, manager_args[i]);
				}
			}
		
			char *fromat, *toat;
			char filename[1000];
			int resx, resy;
			short slope, icon;
			char *dstfile;
			char *color;

			fromat = manager_args[2];
			toat = manager_args[3];
			resx = atoi(manager_args[4]);
			resy = atoi(manager_args[5]);
			if ((manager_argc > 6) && (manager_args[6][0] == '1')) slope = 1; else slope = 0;
			if ((manager_argc > 7) && (manager_args[7][0] == '1')) icon = 1; else icon = 0;
			if ((manager_argc > 8) && (manager_args[8][0] != '-')) color = manager_args[8]; else  color = NULL;
			if (manager_argc > 9) dstfile = manager_args[9]; else dstfile = NULL;			//set dstfile == NULL if not specified

			//limits check discarding graph's legend and axis/grid
			if ((resx < 400) or (resy < 200)) icon = 1;
			//Possible graph types: #PS,PSC,PSS,PSSM,PSSR,PSR,PSA,SQLq,SQLf,tCPU,drop,speed,heap,calls,tacCPU,loadadvg


			char sendcommand[2048];			//buffer for send command string;
			if (!strncmp(manager_args[1], "PSA",4 )) {
				sprintf(filename, "%s/rrd/2db-PS.rrd", getRrdDir());
				rrd_vm_create_graph_PSA_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "PSR", 4)) {
				sprintf(filename, "%s/rrd/2db-PS.rrd", getRrdDir());
				rrd_vm_create_graph_PSR_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "PSSR", 5)) {
				sprintf(filename, "%s/rrd/2db-PS.rrd", getRrdDir());
				rrd_vm_create_graph_PSSR_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "PSSM", 5)) {
				sprintf(filename, "%s/rrd/2db-PS.rrd", getRrdDir());
				rrd_vm_create_graph_PSSM_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "PSS", 4)) {
				sprintf(filename, "%s/rrd/2db-PS.rrd", getRrdDir());
				rrd_vm_create_graph_PSS_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "PSC", 4)) {
				sprintf(filename, "%s/rrd/2db-PS.rrd", getRrdDir());
				rrd_vm_create_graph_PSC_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "PS", 3)) {
				sprintf(filename, "%s/rrd/2db-PS.rrd", getRrdDir());
				rrd_vm_create_graph_PS_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "SQLq", 5)) {
				sprintf(filename, "%s/rrd/2db-SQL.rrd", getRrdDir());
				rrd_vm_create_graph_SQLq_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "SQLf", 5)) {
				sprintf(filename, "%s/rrd/2db-SQL.rrd", getRrdDir());
				rrd_vm_create_graph_SQLf_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "tCPU", 5)) {
				sprintf(filename, "%s/rrd/2db-tCPU.rrd", getRrdDir());
				rrd_vm_create_graph_tCPU_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "drop", 5)) {
				sprintf(filename, "%s/rrd/2db-drop.rrd", getRrdDir());
				rrd_vm_create_graph_drop_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "speed", 5)) {
				sprintf(filename, "%s/rrd/2db-speedmbs.rrd", getRrdDir());
				rrd_vm_create_graph_speed_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "heap", 5)) {
				sprintf(filename, "%s/rrd/2db-heap.rrd", getRrdDir());
				rrd_vm_create_graph_heap_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "calls", 6)) {
				sprintf(filename, "%s/rrd/3db-callscounter.rrd", getRrdDir());
				rrd_vm_create_graph_calls_command(filename, fromat, toat, color, resx ,resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "tacCPU", 7)) {
				sprintf(filename, "%s/rrd/2db-tacCPU.rrd", getRrdDir());
				rrd_vm_create_graph_tacCPU_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "memusage", 7)) {
				sprintf(filename, "%s/rrd/db-memusage.rrd", getRrdDir());
				rrd_vm_create_graph_memusage_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else if (!strncmp(manager_args[1], "loadavg", 7)) {
				sprintf(filename, "%s/rrd/db-LA.rrd", getRrdDir());
				rrd_vm_create_graph_LA_command(filename, fromat, toat, color, resx, resy, slope, icon, dstfile, sendcommand, sizeof(sendcommand));
			} else {
				snprintf(sendbuf, BUFSIZE, "Error: Graph type %s isn't known\n\tGraph types: PS PSC PSS PSSM PSSR PSR PSA SQLq SQLf tCPU drop speed heap calls tacCPU memusage\n", manager_args[1]);	
				if (verbosity > 0) {
					syslog(LOG_NOTICE, "creategraph Error: Unrecognized graph type %s", manager_args[1]);
					syslog(LOG_NOTICE, "    Graph types: PS PSC PSS PSSM PSSR PSR PSA SQLq SQLf tCPU drop speed heap calls tacCPU memusage loadavg");
				}
				res = -1;
			}
			if ((dstfile == NULL) && (res == 0)) {		//send from stdout of a command (binary data)
				if (sverb.rrd_info) syslog(LOG_NOTICE, "COMMAND for system pipe:%s", sendcommand);
				if (sendvm_from_stdout_of_command(sendcommand, client, sshchannel, sendbuf, sizeof(sendbuf), 0) == -1 ){
					cerr << "Error sending data to client 2" << endl;
					delete [] manager_cmd_line;
					delete [] manager_args;
					pthread_mutex_unlock(&vm_rrd_lock);
					return -1;
				}
			} else {									//send string data (text data or error response)
				if (sverb.rrd_info) syslog(LOG_NOTICE, "COMMAND for system:%s", sendcommand);
				res = system(sendcommand);
				if ((verbosity > 0) && (res > 0)) snprintf(sendbuf, BUFSIZE, "ERROR while creating graph of type %s from:%s to:%s resx:%i resy:%i slopemode=%s, iconmode=%s\n", manager_args[1], fromat, toat, resx, resy, slope?"yes":"no", icon?"yes":"no");
				if ((verbosity > 0) && (res == 0)) snprintf(sendbuf, BUFSIZE, "Created graph of type %s from:%s to:%s resx:%i resy:%i slopemode=%s, iconmode=%s in file %s\n", manager_args[1], fromat, toat, resx, resy, slope?"yes":"no", icon?"yes":"no", dstfile);
				if (strlen(sendbuf)) {
					if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
						cerr << "Error sending data to client 3" << endl;
						delete [] manager_cmd_line;
						delete [] manager_args;
						pthread_mutex_unlock(&vm_rrd_lock);
						return -1;
					}
				}
			}
		}
		delete [] manager_cmd_line;
		delete [] manager_args;
		pthread_mutex_unlock(&vm_rrd_lock);
		return res;

	} else if(strstr(buf, "reindexfiles") != NULL) {
		if(is_enable_cleanspool()) {
			char date[21];
			int hour;
			bool badParams = false;
			if(strstr(buf, "reindexfiles_datehour")) {
				if(sscanf(buf + strlen("reindexfiles_datehour") + 1, "%20s %i", date, &hour) != 2) {
					badParams = true;
				}
			} else if(strstr(buf, "reindexfiles_date")) {
				if(sscanf(buf + strlen("reindexfiles_date") + 1, "%20s", date) != 1) {
					badParams = true;
				}
			}
			if(badParams) {
				snprintf(sendbuf, BUFSIZE, "bad parameters");
				if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
					cerr << "Error sending data to client" << endl;
				}
				return -1;
			}
			snprintf(sendbuf, BUFSIZE, "starting reindexing please wait...");
			if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
				cerr << "Error sending data to client" << endl;
				return -1;
			}
			if(strstr(buf, "reindexfiles_datehour")) {
				CleanSpool::run_reindex_date_hour(date, hour);
			} else if(strstr(buf, "reindexfiles_date")) {
				CleanSpool::run_reindex_date(date);
			} else {
				CleanSpool::run_reindex_all("call from manager");
			}
			snprintf(sendbuf, BUFSIZE, "done\r\n");
		} else {
			strcpy(sendbuf, "cleanspool is disable\r\n");
		}
		if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "check_filesindex") != NULL) {
		if(is_enable_cleanspool()) {
			snprintf(sendbuf, BUFSIZE, "starting checking indexing please wait...");
			if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
				cerr << "Error sending data to client" << endl;
				return -1;
			}
			CleanSpool::run_check_filesindex();
			snprintf(sendbuf, BUFSIZE, "done\r\n");
		} else {
			strcpy(sendbuf, "cleanspool is disable\r\n");
		}
		if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "totalcalls") != NULL) {
		snprintf(sendbuf, BUFSIZE, "%d", calls_counter);
		if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "totalregisters") != NULL) {
		snprintf(sendbuf, BUFSIZE, "%d", registers_counter);
		if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "disablecdr") != NULL) {
		opt_nocdr = 1;
		if ((size = sendvm(client, sshchannel, "disabled", 8, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "enablecdr") != NULL) {
		opt_nocdr = 0;
		if ((size = sendvm(client, sshchannel, "enabled", 7, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "listcalls") != NULL) {
		if(calltable) {
		//list<Call*>::iterator call;
		map<string, Call*>::iterator callMAPIT;
		Call *call;
		char outbuf[2048];
		string rslt_data;
		/* headers */
		snprintf(outbuf, sizeof(outbuf), 
			 "%s",
			(string(
			"[["
			"\"callreference\", "
			"\"callid\", "
			"\"callercodec\", "
			"\"calledcodec\", "
			"\"caller\", "
			"\"callername\", "
			"\"callerdomain\", "
			"\"called\", "
			"\"calleddomain\", "
			"\"calldate\", "
			"\"duration\", "
			"\"connect_duration\", "
			"\"callerip\", "
			"\"calledip\", "
			"\"lastpackettime\", "
			"\"lastSIPresponseNum\", "
			"\"rtp_src\", "
			"\"rtp_dst\", "
			"\"src_mosf1\", "
			"\"src_mosf2\", "
			"\"src_mosAD\", "
			"\"src_jitter\", "
			"\"src_loss\", "
			"\"src_loss_last10sec\", "
			"\"dst_mosf1\", "
			"\"dst_mosf2\", "
			"\"dst_mosAD\", "
			"\"dst_jitter\", "
			"\"dst_loss\", "
			"\"dst_loss_last10sec\"") + 
			(is_receiver() ? ",\"id_sensor\"" : "") +
			"]"
			).c_str());
		rslt_data += outbuf;
		calltable->lock_calls_listMAP();
		unsigned int now = time(NULL);
		for (callMAPIT = calltable->calls_listMAP.begin(); callMAPIT != calltable->calls_listMAP.end(); ++callMAPIT) {
			call = (*callMAPIT).second;
			if(call->type == REGISTER or call->type == MESSAGE or 
			   (call->destroy_call_at and call->destroy_call_at < now) or 
			   (call->destroy_call_at_bye and call->destroy_call_at_bye < now) or 
			   (call->destroy_call_at_bye_confirmed and call->destroy_call_at_bye_confirmed < now)) {
				// skip register or message or calls which are scheduled to be closed
				continue;
			}
			/* 
			 * caller 
			 * callername
			 * called
			 * calldate
			 * duration
			 * callerip htonl(sipcallerip)
			 * sipcalledip htonl(sipcalledip)
			*/
			//XXX: escape " or replace it to '
			snprintf(outbuf, sizeof(outbuf),
				 ",[\"%p\", "
				 "\"%s\", "
				 "\"%d\", "
				 "\"%d\", "
				 "\"%s\", "
				 "\"%s\", "
				 "\"%s\", "
				 "\"%s\", "
				 "\"%s\", "
				 "\"%s\", "
				 "\"%d\", "
				 "\"%d\", "
				 "\"%u\", "
				 "\"%u\", "
				 "\"%u\", "
				 "\"%d\", " //lastSIPresponseNum
				 "\"%u\", " //rtp_src
				 "\"%u\", " //rtp_dst
				 "\"%d\", " //src_mosf1
				 "\"%d\", " //src_mosf1
				 "\"%d\", " //src_mosAD
				 "\"%d\", " //src_jitter
				 "\"%f\", " //src_loss
				 "\"%f\", " //src_loss_last10sec
				 "\"%d\", " //dst_mosf1
				 "\"%d\", " //dst_mosf1
				 "\"%d\", " //dst_mosAD
				 "\"%d\", " //dst_jitter
				 "\"%f\", " //dst_loss
				 "\"%f\"", //dst_loss_last10sec
				 call, 
				 json_encode(call->call_id).c_str(), 
				 call->last_callercodec, 
				 call->last_calledcodec, 
				 json_encode(call->caller).c_str(), 
				 json_encode(call->callername).c_str(), 
				 json_encode(call->caller_domain).c_str(),
				 json_encode(call->called).c_str(), 
				 json_encode(call->called_domain).c_str(),
				 sqlDateTimeString(call->calltime()).c_str(), 
				 call->duration_active(), 
				 call->connect_duration_active(), 
				 htonl(call->sipcallerip[0]), 
				 htonl(call->sipcalledip[0]), 
				 (unsigned int)call->get_last_packet_time(), 
				 call->lastSIPresponseNum,
				     //rtp stat 
				 (call->lastcallerrtp ? call->lastcallerrtp->saddr : 0),
				 (call->lastcalledrtp ? call->lastcalledrtp->saddr : 0),
				     //caller
				 (call->lastcallerrtp ? call->lastcallerrtp->last_interval_mosf1 : 45),
				 (call->lastcallerrtp ? call->lastcallerrtp->last_interval_mosf2 : 45),
				 (call->lastcallerrtp ? call->lastcallerrtp->last_interval_mosAD : 45),
				 (call->lastcallerrtp ? (int)(round(call->lastcallerrtp->jitter)) : 0),
				 (call->lastcallerrtp and call->lastcallerrtp->stats.received ? (float)((double)call->lastcallerrtp->stats.lost / ((double)call->lastcallerrtp->stats.received + (double)call->lastcallerrtp->stats.lost) * 100.0) : 0),
				 (call->lastcallerrtp ? (float)(call->lastcallerrtp->last_stat_loss_perc_mult10) : 0),
				     //called
				 (call->lastcalledrtp ? call->lastcalledrtp->last_interval_mosf1 : 45),
				 (call->lastcalledrtp ? call->lastcalledrtp->last_interval_mosf2 : 45),
				 (call->lastcalledrtp ? call->lastcalledrtp->last_interval_mosAD : 45),
				 (call->lastcalledrtp ? (int)round(call->lastcalledrtp->jitter) : 0),
				 (call->lastcalledrtp and call->lastcalledrtp->stats.received > 50 ? (float)((double)call->lastcalledrtp->stats.lost / ((double)call->lastcalledrtp->stats.received + (double)call->lastcalledrtp->stats.lost) * 100.0) : 0),
				 (call->lastcalledrtp ? (float)(call->lastcalledrtp->last_stat_loss_perc_mult10) : 0));
			rslt_data += outbuf;
			if(is_receiver()) {
				rslt_data += "," + intToString(call->useSensorId);
			}
			rslt_data += "]";
		}
		calltable->unlock_calls_listMAP();
		rslt_data += ",[\"encoded\"]]";
		if ((size = sendvm(client, sshchannel, rslt_data.c_str(), rslt_data.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		}
		return 0;
	} else if(strstr(buf, "is_register_new") != NULL) {
		extern int opt_sip_register;
		if ((size = sendvm(client, sshchannel, opt_sip_register == 1 ? "ok" : "no", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "listregisters") != NULL) {
		string rslt_data;
		char *pointer;
		if((pointer = strchr(buf, '\n')) != NULL) {
			*pointer = 0;
		}
		bool zip = false;
		extern Registers registers;
		rslt_data = registers.getDataTableJson(buf + strlen("listregisters") + 1, &zip);
		if(sendString(&rslt_data, client, sshchannel, zip) == -1) {
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "cleanupregisters") != NULL) {
		string rslt_data;
		char *pointer;
		if((pointer = strchr(buf, '\n')) != NULL) {
			*pointer = 0;
		}
		extern Registers registers;
		registers.cleanupByJson(buf + strlen("cleanupregisters") + 1);
		if ((size = sendvm(client, sshchannel, "ok", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "d_lc_for_destroy") != NULL) {
		ostringstream outStr;
		if(!calltable && !terminating) {
			outStr << "sniffer not initialized yet" << endl;
			if ((size = sendvm(client, sshchannel, outStr.str().c_str(), outStr.str().length(), 0)) == -1){
				cerr << "Error sending data to client" << endl;
				return -1;
			}
			return 0;
		}
		if(calltable->calls_queue.size()) {
			Call *call;
			vector<Call*> vectCall;
			calltable->lock_calls_queue();
			for(size_t i = 0; i < calltable->calls_queue.size(); ++i) {
				call = calltable->calls_queue[i];
				if(call->type != REGISTER && call->destroy_call_at) {
					vectCall.push_back(call);
				}
			}
			if(vectCall.size()) { 
				std::sort(vectCall.begin(), vectCall.end(), cmpCallBy_destroy_call_at);
				for(size_t i = 0; i < vectCall.size(); i++) {
					call = vectCall[i];
					outStr.width(15);
					outStr << call->caller << " -> ";
					outStr.width(15);
					outStr << call->called << "  "
					<< sqlDateTimeString(call->calltime()) << "  ";
					outStr.width(6);
					outStr << call->duration() << "s  "
					<< sqlDateTimeString(call->destroy_call_at) << "  "
					<< call->fbasename;
					outStr << endl;
				}
			}
			calltable->unlock_calls_queue();
		}
		outStr << "-----------" << endl;
		if ((size = sendvm(client, sshchannel, outStr.str().c_str(), outStr.str().length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "d_lc_bye") != NULL) {
		ostringstream outStr;
		if(!calltable && !terminating) {
			outStr << "sniffer not initialized yet" << endl;
			if ((size = sendvm(client, sshchannel, outStr.str().c_str(), outStr.str().length(), 0)) == -1){
				cerr << "Error sending data to client" << endl;
				return -1;
			}
			return 0;
		}
		map<string, Call*>::iterator callMAPIT;
		Call *call;
		vector<Call*> vectCall;
		calltable->lock_calls_listMAP();
		for (callMAPIT = calltable->calls_listMAP.begin(); callMAPIT != calltable->calls_listMAP.end(); ++callMAPIT) {
			call = (*callMAPIT).second;
			if(call->type != REGISTER && call->seenbye) {
				vectCall.push_back(call);
			}
		}
		if(vectCall.size()) { 
			std::sort(vectCall.begin(), vectCall.end(), cmpCallBy_destroy_call_at);
			for(size_t i = 0; i < vectCall.size(); i++) {
				call = vectCall[i];
				outStr.width(15);
				outStr << call->caller << " -> ";
				outStr.width(15);
				outStr << call->called << "  "
				<< sqlDateTimeString(call->calltime()) << "  ";
				outStr.width(6);
				outStr << call->duration() << "s  "
				<< (call->destroy_call_at ? sqlDateTimeString(call->destroy_call_at) : "    -  -     :  :  ")  << "  "
				<< call->fbasename;
				outStr << endl;
			}
		}
		calltable->unlock_calls_listMAP();
		outStr << "-----------" << endl;
		if ((size = sendvm(client, sshchannel, outStr.str().c_str(), outStr.str().length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "d_lc_all") != NULL) {
		ostringstream outStr;
		if(!calltable && !terminating) {
			outStr << "sniffer not initialized yet" << endl;
			if ((size = sendvm(client, sshchannel, outStr.str().c_str(), outStr.str().length(), 0)) == -1){
				cerr << "Error sending data to client" << endl;
				return -1;
			}
			return 0;
		}
		map<string, Call*>::iterator callMAPIT;
		Call *call;
		vector<Call*> vectCall;
		calltable->lock_calls_listMAP();
		for (callMAPIT = calltable->calls_listMAP.begin(); callMAPIT != calltable->calls_listMAP.end(); ++callMAPIT) {
			vectCall.push_back((*callMAPIT).second);
		}
		if(vectCall.size()) { 
			std::sort(vectCall.begin(), vectCall.end(), cmpCallBy_first_packet_time);
			for(size_t i = 0; i < vectCall.size(); i++) {
				call = vectCall[i];
				outStr.width(15);
				outStr << call->caller << " -> ";
				outStr.width(15);
				outStr << call->called << "  "
				<< sqlDateTimeString(call->calltime()) << "  ";
				outStr.width(6);
				outStr << call->duration() << "s  "
				<< (call->destroy_call_at ? sqlDateTimeString(call->destroy_call_at) : "    -  -     :  :  ")  << "  ";
				outStr.width(3);
				outStr << call->lastSIPresponseNum << "  "
				<< call->fbasename;
				outStr << endl;
			}
		}
		calltable->unlock_calls_listMAP();
		outStr << "-----------" << endl;
		if ((size = sendvm(client, sshchannel, outStr.str().c_str(), outStr.str().length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "d_close_call") != NULL) {
		char fbasename[100];
		sscanf(buf, "d_close_call %s", fbasename);
		string rslt = fbasename + string(" missing");
		map<string, Call*>::iterator callMAPIT;
		calltable->lock_calls_listMAP();
		for (callMAPIT = calltable->calls_listMAP.begin(); callMAPIT != calltable->calls_listMAP.end(); ++callMAPIT) {
			if(!strcmp((*callMAPIT).second->fbasename, fbasename)) {
				(*callMAPIT).second->force_close = true;
				rslt = fbasename + string(" close");
				break;
			}
		}
		calltable->unlock_calls_listMAP();
		if ((size = sendvm(client, sshchannel, (rslt + "\n").c_str(), rslt.length() + 1, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "cleanup_calls") != NULL) {
		calltable->cleanup_calls(0);
		if ((size = sendvm(client, sshchannel, "ok", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "cleanup_registers") != NULL) {
		calltable->cleanup_registers(0);
		if ((size = sendvm(client, sshchannel, "ok", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "expire_registers") != NULL) {
		extern int opt_sip_register;
		if(opt_sip_register == 1) {
			extern Registers registers;
			registers.cleanup(time(NULL), true);
		}
		if ((size = sendvm(client, sshchannel, "ok", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return(0);
	} else if(strstr(buf, "cleanup_tcpreassembly") != NULL) {
		extern TcpReassemblySip tcpReassemblySip;
		tcpReassemblySip.clean();
		if ((size = sendvm(client, sshchannel, "ok", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "destroy_close_calls") != NULL) {
		calltable->destroyCallsIfPcapsClosed();
		if ((size = sendvm(client, sshchannel, "ok", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "getipaccount") != NULL) {
		sscanf(buf, "getipaccount %u", &uid);
		map<unsigned int, octects_live_t*>::iterator it = ipacc_live.find(uid);
		if(it != ipacc_live.end()) {
			snprintf(sendbuf, BUFSIZE, "%d", 1);
		} else {
			snprintf(sendbuf, BUFSIZE, "%d", 0);
		}
		if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "ipaccountfilter set") != NULL) {
		
		string ipfilter;
		u_int32_t id = atol(buf + strlen("ipaccountfilter set "));
		char *pointToSeparatorBefereIpfilter = strchr(buf + strlen("ipaccountfilter set "), ' ');
		if(pointToSeparatorBefereIpfilter) {
			ipfilter = pointToSeparatorBefereIpfilter + 1;
		}
		if(!ipfilter.length() || ipfilter.find("ALL") != string::npos) {
			map<unsigned int, octects_live_t*>::iterator it = ipacc_live.find(id);
			octects_live_t* filter;
			if(it != ipacc_live.end()) {
				filter = it->second;
			} else {
				filter = new FILE_LINE(13007) octects_live_t;
				memset(filter, 0, sizeof(octects_live_t));
				filter->all = 1;
				filter->fetch_timestamp = time(NULL);
				ipacc_live[id] = filter;
				if(verbosity > 0) {
					cout << "START LIVE IPACC " << "id: " << id << " ipfilter: " << "ALL" << endl;
				}
			}
			return 0;
		} else {
			octects_live_t* filter;
			filter = new FILE_LINE(13008) octects_live_t;
			memset(filter, 0, sizeof(octects_live_t));
			filter->setFilter(ipfilter.c_str());
			filter->fetch_timestamp = time(NULL);
			ipacc_live[id] = filter;
			if(verbosity > 0) {
				cout << "START LIVE IPACC " << "id: " << id << " ipfilter: " << ipfilter << endl;
			}
		}
		return(0);
	} else if(strstr(buf, "stopipaccount")) {
		u_int32_t id = 0;
		sscanf(buf, "stopipaccount %u", &id);
		map<unsigned int, octects_live_t*>::iterator it = ipacc_live.find(id);
		if(it != ipacc_live.end()) {
			delete it->second;
			ipacc_live.erase(it);
			if(verbosity > 0) {
				cout << "STOP LIVE IPACC " << "id:" << id << endl;
			}
		}
		return 0;
	} else if(strstr(buf, "fetchipaccount")) {
		u_int32_t id = 0;
		sscanf(buf, "fetchipaccount %u", &id);
		map<unsigned int, octects_live_t*>::iterator it = ipacc_live.find(id);
		char sendbuf[1024];
		if(it == ipacc_live.end()) {
			strcpy(sendbuf, "stopped");
		} else {
			octects_live_t *data = it->second;
			snprintf(sendbuf, 1024, "%u;%llu;%u;%llu;%u;%llu;%u;%llu;%u;%llu;%u;%llu;%u", 
				(unsigned int)time(NULL),
				data->dst_octects, data->dst_numpackets, 
				data->src_octects, data->src_numpackets, 
				data->voipdst_octects, data->voipdst_numpackets, 
				data->voipsrc_octects, data->voipsrc_numpackets, 
				data->all_octects, data->all_numpackets,
				data->voipall_octects, data->voipall_numpackets);
			data->fetch_timestamp = time(NULL);
		}
		if((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1) {
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
///////////////////////////////////////////////////////////////
	} else if(strstr(buf, "getactivesniffers")) {
		while(__sync_lock_test_and_set(&usersniffer_sync, 1));
		string jsonResult = "[";
		map<unsigned int, livesnifferfilter_t*>::iterator usersnifferIT;
		int counter = 0;
		for(usersnifferIT = usersniffer.begin(); usersnifferIT != usersniffer.end(); usersnifferIT++) {
			if(counter) {
				jsonResult += ",";
			}
			char uid_str[10];
			sprintf(uid_str, "%i", usersnifferIT->first);
			jsonResult += "{\"uid\": \"" + string(uid_str) + "\"," +
					"\"state\":\"" + usersnifferIT->second->getStringState() + "\"}";
			++counter;
		}
		jsonResult += "]";
		__sync_lock_release(&usersniffer_sync);
		if((size = sendvm(client, sshchannel, jsonResult.c_str(), jsonResult.length(), 0)) == -1) {
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
        } else if(strstr(buf, "stoplivesniffer")) {
                sscanf(buf, "stoplivesniffer %u", &uid);
		while(__sync_lock_test_and_set(&usersniffer_sync, 1)) {};
                map<unsigned int, livesnifferfilter_t*>::iterator usersnifferIT = usersniffer.find(uid);
                if(usersnifferIT != usersniffer.end()) {
                        delete usersnifferIT->second;
                        usersniffer.erase(usersnifferIT);
			if(!usersniffer.size()) {
				global_livesniffer = 0;
			}
			updateLivesnifferfilters();
			if(verbosity > 0) {
				 syslog(LOG_NOTICE, "stop livesniffer - uid: %u", uid);
			}
                }
                __sync_lock_release(&usersniffer_sync);
                return 0;
	} else if(strstr(buf, "getlivesniffer") != NULL) {
		sscanf(buf, "getlivesniffer %u", &uid);
		while(__sync_lock_test_and_set(&usersniffer_sync, 1));
		map<unsigned int, livesnifferfilter_t*>::iterator usersnifferIT = usersniffer.find(uid);
		if(usersnifferIT != usersniffer.end()) {
			snprintf(sendbuf, BUFSIZE, "%d", 1);
		} else {
			snprintf(sendbuf, BUFSIZE, "%d", 0);
		}
		__sync_lock_release(&usersniffer_sync);
		if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "livefilter set") != NULL) {
		char search[1024] = "";
		char value[1024] = "";

		sscanf(buf, "livefilter set %u %s %[^\n\r]", &uid, search, value);
		if(verbosity > 0) {
			syslog(LOG_NOTICE, "set livesniffer - uid: %u search: %s value: %s", uid, search, value);
		}
		
		while(__sync_lock_test_and_set(&usersniffer_sync, 1));

		if(memmem(search, sizeof(search), "all", 3)) {
			global_livesniffer = 1;
			map<unsigned int, livesnifferfilter_t*>::iterator usersnifferIT = usersniffer.find(uid);
			livesnifferfilter_t* filter;
			if(usersnifferIT != usersniffer.end()) {
				filter = usersnifferIT->second;
			} else {
				filter = new FILE_LINE(13009) livesnifferfilter_t;
				memset(filter, 0, sizeof(livesnifferfilter_t));
				usersniffer[uid] = filter;
			}
			updateLivesnifferfilters();
			__sync_lock_release(&usersniffer_sync);
			return 0;
		}

		map<unsigned int, livesnifferfilter_t*>::iterator usersnifferIT = usersniffer.find(uid);
		livesnifferfilter_t* filter;
		if(usersnifferIT != usersniffer.end()) {
			filter = usersnifferIT->second;
		} else {
			filter = new FILE_LINE(13010) livesnifferfilter_t;
			memset(filter, 0, sizeof(livesnifferfilter_t));
			usersniffer[uid] = filter;
		}
		
		if(strstr(search, "srcaddr")) {
			int i = 0;
			//reset filters 
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_saddr[i] = 0;
			}
			stringstream  data(value);
			string val;
			// read all argumens lkivefilter set saddr 123 345 244
			i = 0;
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				//convert doted ip to unsigned int
				filter->lv_saddr[i] = ntohl((unsigned int)inet_addr(val.c_str()));
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "dstaddr")) {
			int i = 0;
			//reset filters 
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_daddr[i] = 0;
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set daddr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				//convert doted ip to unsigned int
				filter->lv_daddr[i] = ntohl((unsigned int)inet_addr(val.c_str()));
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "bothaddr")) {
			int i = 0;
			//reset filters 
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_bothaddr[i] = 0;
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set bothaddr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				//convert doted ip to unsigned int
				filter->lv_bothaddr[i] = ntohl((unsigned int)inet_addr(val.c_str()));
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "srcnum")) {
			int i = 0;
			//reset filters 
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_srcnum[i][0] = '\0';
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set srcaddr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				stringstream tmp;
				tmp << val;
				tmp >> filter->lv_srcnum[i];
				//cout << filter->lv_srcnum[i] << "\n";
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "dstnum")) {
			int i = 0;
			//reset filters 
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_dstnum[i][0] = '\0';
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set dstaddr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				stringstream tmp;
				tmp << val;
				tmp >> filter->lv_dstnum[i];
				//cout << filter->lv_dstnum[i] << "\n";
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "bothnum")) {
			int i = 0;
			//reset filters 
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_bothnum[i][0] = '\0';
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set bothaddr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				stringstream tmp;
				tmp << val;
				tmp >> filter->lv_bothnum[i];
				//cout << filter->lv_bothnum[i] << "\n";
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "fromhstr")) {
			int i = 0;
			//reset filters
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_fromhstr[i][0] = '\0';
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set fromhstr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				stringstream tmp;
				tmp << val;
				tmp >> filter->lv_fromhstr[i];
				//cout << filter->lv_fromhstr[i] << "\n";
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "tohstr")) {
			int i = 0;
			//reset filters
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_tohstr[i][0] = '\0';
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set tohstr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				stringstream tmp;
				tmp << val;
				tmp >> filter->lv_tohstr[i];
				//cout << filter->lv_tohstr[i] << "\n";
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "bothhstr")) {
			int i = 0;
			//reset filters
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_bothhstr[i][0] = '\0';
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set bothhstr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				stringstream tmp;
				tmp << val;
				tmp >> filter->lv_bothhstr[i];
				//cout << filter->lv_bothhstr[i] << "\n";
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "vlan")) {
			int i = 0;
			//reset filters
			for(i = 0; i < MAXLIVEFILTERS; i++) {
				filter->lv_vlan[i][0] = '\0';
			}
			stringstream  data(value);
			string val;
			i = 0;
			// read all argumens livefilter set bothhstr 123 345 244
			while(i < MAXLIVEFILTERS and getline(data, val,' ')){
				global_livesniffer = 1;
				stringstream tmp;
				tmp << val;
				tmp >> filter->lv_vlan[i];
				//cout << filter->lv_bothhstr[i] << "\n";
				i++;
			}
			updateLivesnifferfilters();
		} else if(strstr(search, "siptypes")) {
			//cout << "siptypes: " << value << "\n";
			for(size_t i = 0; i < strlen(value) && i < MAXLIVEFILTERS; i++) {
				filter->lv_siptypes[i] = value[i] == 'I' ? INVITE :
							 value[i] == 'R' ? REGISTER :
							 value[i] == 'O' ? OPTIONS :
							 value[i] == 'S' ? SUBSCRIBE :
							 value[i] == 'M' ? MESSAGE :
							 value[i] == 'N' ? NOTIFY :
									   0;
			}
			updateLivesnifferfilters();
		}
		
		__sync_lock_release(&usersniffer_sync);
		
		if ((size = sendvm(client, sshchannel, "ok", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "listen_stop") != NULL) {
		if(!calltable) {
			return(-1);
		}
		long long callreference = 0;
		char listen_id[20] = "";
		string error;
		sscanf(buf, "listen_stop %llu %s", &callreference, listen_id);
		if(!callreference) {
			listen_id[0] = 0;
			sscanf(buf, "listen_stop %llx %s", &callreference, listen_id);
		}
		listening_master_lock();
		c_listening_clients::s_client *l_client = listening_clients.get(listen_id, (Call*)callreference);
		if(l_client) {
			listening_clients.remove(l_client);
		}
		c_listening_workers::s_worker *l_worker = listening_workers.get((Call*)callreference);
		if(l_worker && !listening_clients.exists(l_worker->call)) {
			listening_workers.stop(l_worker);
			while(l_worker->running) {
				usleep(100);
			}
			listening_workers.remove(l_worker);
		}
		listening_master_unlock();
		return(0);
	} else if(strstr(buf, "listen") != NULL) {
		if(!calltable) {
			return(-1);
		}
		long long callreference = 0;
		char listen_id[20] = "";
		string error;
		int rslt = 0;
		sscanf(buf, "listen %llu %s", &callreference, listen_id);
		if(!callreference) {
			listen_id[0] = 0;
			sscanf(buf, "listen %llx %s", &callreference, listen_id);
		}
		listening_master_lock();
		Call *call = calltable->find_by_reference(callreference, false);
		if(call) {
			bool newWorker = false;
			string rslt = "success";
			c_listening_workers::s_worker *l_worker = listening_workers.get(call);
			if(l_worker) {
				rslt = "call already listening";
			} else {
				l_worker = listening_workers.add(call);
				listening_workers.run(l_worker);
				newWorker = true;
			}
			c_listening_clients::s_client *l_client = listening_clients.add(listen_id, call);
			if(!newWorker) {
				l_client->spybuffer_start_pos = l_worker->spybuffer->size_all_with_freed_pos();
			}
			if((size = sendvm(client, sshchannel, rslt.c_str(), rslt.length(), 0)) == -1) {
				cerr << "Error sending data to client" << endl;
				rslt = -1;
			}
		} else {
			error = "call not found";
		}
		listening_master_unlock();
		if(!error.empty()) {
			if((size = sendvm(client, sshchannel, error.c_str(), error.length(), 0)) == -1) {
				cerr << "Error sending data to client" << endl;
				rslt = -1;
			}
		}
		return(rslt);
	} else if(strstr(buf, "readaudio") != NULL) {
		if(!calltable) {
			return(-1);
		}
		long long callreference = 0;
		char listen_id[20] = "";
		string error;
		string information;
		int rslt = 0;
		sscanf(buf, "readaudio %llu %s", &callreference, listen_id);
		if(!callreference) {
			listen_id[0] = 0;
			sscanf(buf, "readaudio %llx %s", &callreference, listen_id);
		}
		listening_master_lock();
		Call *call = calltable->find_by_reference(callreference, false);
		if(call) {
			c_listening_workers::s_worker *l_worker = listening_workers.get(call);
			if(l_worker) {
				c_listening_clients::s_client *l_client = listening_clients.get(listen_id, call);
				if(l_client) {
					u_int32_t bsize = 0;
					u_int32_t from_pos = max(l_client->spybuffer_start_pos, l_client->spybuffer_last_send_pos);
					//cout << "pos: " << from_pos << " / " << l_worker->spybuffer->size_all_with_freed_pos() << endl;
					l_worker->spybuffer->lock_master();
					u_char *buff = l_worker->spybuffer->get_from_pos(&bsize, from_pos);
					if(buff) {
						//cout << "bsize: " << bsize << endl;
						l_client->spybuffer_last_send_pos = from_pos + bsize;
						u_int64_t min_use_spybuffer_sample = listening_clients.get_min_use_spybuffer_pos(l_client->call);
						if(min_use_spybuffer_sample) {
							l_worker->spybuffer->free_pos(min_use_spybuffer_sample);
						}
						l_worker->spybuffer->unlock_master();
						if((size = sendvm(client, sshchannel, (char*)buff, bsize, 0)) == -1) {
							cerr << "Error sending data to client" << endl;
							rslt = -1;
						}
						delete [] buff;
					} else {
						l_worker->spybuffer->unlock_master();
						information = "wait for data";
					}
					l_client->last_activity_time = getTimeS();
				} else {
					error = "client of worker not found";
				}
			} else {
				error = "worker not found";
			}
		} else {
			error = "call not found";
		}
		listening_master_unlock();
		if(!error.empty() || !information.empty()) {
			string data = !error.empty() ?
					"error: " + error :
					"information: " + information;
			if((size = sendvm(client, sshchannel, data.c_str(), data.length(), 0)) == -1) {
				cerr << "Error sending data to client" << endl;
				rslt = -1;
			}
		}
		return(rslt);
	} else if(strstr(buf, "reload") != NULL) {
		reload_capture_rules();
		if ((size = sendvm(client, sshchannel, "reload ok", 9, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "hot_restart") != NULL) {
		hot_restart();
		if ((size = sendvm(client, sshchannel, "hot restart ok", 14, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "get_json_config") != NULL) {
		string rslt = useNewCONFIG ? CONFIG.getJson() : "not supported";
		if ((size = sendvm(client, sshchannel, rslt.c_str(), rslt.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "set_json_config ") != NULL) {
		string rslt;
		if(useNewCONFIG) {
			hot_restart_with_json_config(buf + 16);
			rslt = "ok";
		} else {
			rslt = "not supported";
		}
		if ((size = sendvm(client, sshchannel, rslt.c_str(), rslt.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "fraud_refresh") != NULL) {
		refreshFraud();
		if ((size = sendvm(client, sshchannel, "reload ok", 9, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "send_call_info_refresh") != NULL) {
		refreshSendCallInfo();
		if ((size = sendvm(client, sshchannel, "reload ok", 9, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "custom_headers_refresh") != NULL) {
		extern CustomHeaders *custom_headers_cdr;
		extern CustomHeaders *custom_headers_message;
		extern NoHashMessageRules *no_hash_message_rules;
		if(custom_headers_cdr) {
			custom_headers_cdr->refresh();
		}
		if(custom_headers_message) {
			custom_headers_message->refresh();
		}
		if(no_hash_message_rules) {
			no_hash_message_rules->refresh();
		}
		if ((size = sendvm(client, sshchannel, "reload ok", 9, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "no_hash_message_rules_refresh") != NULL) {
		extern NoHashMessageRules *no_hash_message_rules;
		if(no_hash_message_rules) {
			no_hash_message_rules->refresh();
		}
		if ((size = sendvm(client, sshchannel, "reload ok", 9, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "country_detect_refresh") != NULL) {
		CountryDetectPrepareReload();
		if ((size = sendvm(client, sshchannel, "reload ok", 9, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "getfile_is_zip_support") != NULL) {
		if ((size = sendvm(client, sshchannel, "OK", 2, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "getfile_in_tar_check_complete") != NULL) {
		char tar_filename[2048];
		char filename[2048];
		char dateTimeKey[2048];
		
		sscanf(buf, "getfile_in_tar_check_complete %s %s %s", tar_filename, filename, dateTimeKey);
		
		const char *rslt = getfile_in_tar_completed.check(tar_filename, filename, dateTimeKey) ? "OK" : "uncomplete";
		
		if ((size = sendvm(client, sshchannel, rslt, strlen(rslt), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "getfile_in_tar") != NULL) {
		bool zip = strstr(buf, "getfile_in_tar_zip");
	 
		char tar_filename[2048];
		char filename[2048];
		char dateTimeKey[2048];
		u_int32_t recordId = 0;
		char tableType[100] = "";
		char *tarPosI = new FILE_LINE(13011) char[1000000];
		unsigned spool_index = 0;
		int type_spool_file = (int)tsf_na;
		*tarPosI = 0;

		sscanf(buf, zip ? "getfile_in_tar_zip %s %s %s %u %s %s %u %i" : "getfile_in_tar %s %s %s %u %s %s %u %i", tar_filename, filename, dateTimeKey, &recordId, tableType, tarPosI, &spool_index, &type_spool_file);
		if(type_spool_file == tsf_na) {
			type_spool_file = findTypeSpoolFile(spool_index, tar_filename);
		}
		
		Tar tar;
		if(!tar.tar_open(string(getSpoolDir((eTypeSpoolFile)type_spool_file, spool_index)) + '/' + tar_filename, O_RDONLY)) {
			string filename_conv = filename;
			prepare_string_to_filename((char*)filename_conv.c_str());
			tar.tar_read_send_parameters(client, sshchannel, zip);
			tar.tar_read((filename_conv + ".*").c_str(), filename, recordId, tableType, tarPosI);
			if(tar.isReadEnd()) {
				getfile_in_tar_completed.add(tar_filename, filename, dateTimeKey);
			}
		} else {
			snprintf(buf_output, sizeof(buf_output), "error: cannot open file [%s]", tar_filename);
			if ((size = sendvm(client, sshchannel, buf_output, strlen(buf_output), 0)) == -1){
				cerr << "Error sending data to client" << endl;
			}
			delete [] tarPosI;
			return -1;
		}
		delete [] tarPosI;
		return 0;
	} else if(strstr(buf, "getfile") != NULL) {
		bool zip = strstr(buf, "getfile_zip");
		
		char filename[2048];
		unsigned spool_index = 0;
		int type_spool_file = (int)tsf_na;
		
		sscanf(buf, zip ? "getfile_zip %s %u %i" : "getfile %s %u %i", filename, &spool_index, &type_spool_file);
		if(type_spool_file == tsf_na) {
			type_spool_file = findTypeSpoolFile(spool_index, filename);
		}

		return(sendFile((string(getSpoolDir((eTypeSpoolFile)type_spool_file, spool_index)) + '/' + filename).c_str(), client, sshchannel, zip));
	} else if(strstr(buf, "file_exists") != NULL) {
		if(opt_pcap_queue_send_to_ip_port) {
			sendvm(client, sshchannel, "mirror", 6, 0);
			return 0;
		}
	 
		char filename[2048];
		unsigned spool_index = 0;
		int type_spool_file = (int)tsf_na;
		u_int64_t size;
		string rslt;

		sscanf(buf, "file_exists %s %u %i", filename, &spool_index, &type_spool_file);
		if(type_spool_file == tsf_na) {
			type_spool_file = findTypeSpoolFile(spool_index, filename);
		}
		
		int error_code;
		if(file_exists(string(getSpoolDir((eTypeSpoolFile)type_spool_file, spool_index)) + '/' + filename, &error_code)) {
			size = file_size(string(getSpoolDir((eTypeSpoolFile)type_spool_file, spool_index)) + '/' + filename);
			rslt = intToString(size);
			if(size > 0 && strstr(filename, "tar")) {
				for(int i = 1; i <= 5; i++) {
					string nextfilename = filename;
					nextfilename += "." + intToString(i);
					u_int64_t nextsize = file_size(string(getSpoolDir((eTypeSpoolFile)type_spool_file, spool_index)) + '/' + nextfilename);
					if(nextsize > 0) {
						rslt += ";" + nextfilename + ":" + intToString(nextsize);
					} else {
						break;
					}
				}
			}
		} else {
			rslt = error_code == EACCES ? "permission_denied" : "not_exists";
		}
		sendvm(client, sshchannel, rslt.c_str(), rslt.length(), 0);
		return 0;
	} else if(strstr(buf, "fileexists") != NULL) {
		char filename[2048];
		unsigned int size;

		sscanf(buf, "fileexists %s", filename);
		size = file_size(filename);
		snprintf(buf_output, sizeof(buf_output), "%d", size);
		sendvm(client, sshchannel, buf_output, strlen(buf_output), 0);
		return 0;
	} else if(strstr(buf, "flush_tar") != NULL) {
		char filename[2048];
		sscanf(buf, "flush_tar %s", filename);
		flushTar(filename);
		sendvm(client, sshchannel, "OK", 2, 0);
		return 0;
	} else if(strstr(buf, "genwav") != NULL) {
		char filename[2048];
		unsigned int size;
		char wavfile[2048];
		char pcapfile[2048];
		char cmd[4092];
		int secondrun = 0;

		sscanf(buf, "genwav %s", filename);

		sprintf(pcapfile, "%s.pcap", filename);
		sprintf(wavfile, "%s.wav", filename);

getwav2:
		size = file_size(wavfile);
		if(size) {
			snprintf(buf_output, sizeof(buf_output), "%d", size);
			sendvm(client, sshchannel, buf_output, strlen(buf_output), 0);
			return 0;
		}
		if(secondrun > 0) {
			// wav does not exist 
			sendvm(client, sshchannel, "0", 1, 0);
			return -1;
		}

		// wav does not exists, check if exists pcap and try to create wav
		size = file_size(pcapfile);
		if(!size) {
			sendvm(client, sshchannel, "0", 1, 0);
			return -1;
		}
		sprintf(cmd, "PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/sbin:/usr/local/bin voipmonitor --rtp-firstleg -k -WRc -r \"%s.pcap\" -y -d %s 2>/dev/null >/dev/null", filename, getSpoolDir(tsf_main, 0));
		system(cmd);
		secondrun = 1;
		goto getwav2;
	} else if(strstr(buf, "getwav") != NULL) {
		char filename[2048];
		int fd;
		unsigned int size;
		char wavfile[2048];
		char pcapfile[2048];
		char cmd[4092];
		char rbuf[4096];
		int res;
		ssize_t nread;
		int secondrun = 0;

		sscanf(buf, "getwav %s", filename);

		sprintf(pcapfile, "%s.pcap", filename);
		sprintf(wavfile, "%s.wav", filename);

getwav:
		size = file_size(wavfile);
		if(size) {
			fd = open(wavfile, O_RDONLY);
			if(fd < 0) {
				snprintf(buf_output, sizeof(buf_output), "error: cannot open file [%s]", wavfile);
				if ((res = sendvm(client, sshchannel, buf_output, strlen(buf_output), 0)) == -1){
					cerr << "Error sending data to client" << endl;
				}
				return -1;
			}
			while(nread = read(fd, rbuf, sizeof rbuf), nread > 0) {
				if ((res = sendvm(client, sshchannel, rbuf, nread, 0)) == -1){
					close(fd);
					return -1;
				}
			}
			if(eof) {
				if ((res = sendvm(client, sshchannel, "EOF", 3, 0)) == -1){
					close(fd);
					return -1;
				}
			}
			close(fd);
			return 0;
		}
		if(secondrun > 0) {
			// wav does not exist 
			sendvm(client, sshchannel, "0", 1, 0);
			return -1;
		}

		// wav does not exists, check if exists pcap and try to create wav
		size = file_size(pcapfile);
		if(!size) {
			sendvm(client, sshchannel, "0", 1, 0);
			return -1;
		}
		sprintf(cmd, "PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/sbin:/usr/local/bin voipmonitor --rtp-firstleg -k -WRc -r \"%s.pcap\" -y 2>/dev/null >/dev/null", filename);
		system(cmd);
		secondrun = 1;
		goto getwav;
	} else if(strstr(buf, "getsiptshark") != NULL) {
		char filename[2048];
		int fd;
		unsigned int size;
		char tsharkfile[2048];
		char pcapfile[2048];
		char cmd[4092];
		char rbuf[4096];
		int res;
		ssize_t nread;

		sscanf(buf, "getsiptshark %s", filename);

		sprintf(tsharkfile, "%s.pcap2txt", filename);
		sprintf(pcapfile, "%s.pcap", filename);


		size = file_size(tsharkfile);
		if(size) {
			fd = open(tsharkfile, O_RDONLY);
			if(fd < 0) {
				snprintf(buf_output, sizeof(buf_output), "error: cannot open file [%s]", tsharkfile);
				if ((res = sendvm(client, sshchannel, buf_output, strlen(buf_output), 0)) == -1){
					cerr << "Error sending data to client" << endl;
				}
				return -1;
			}
			while(nread = read(fd, rbuf, sizeof rbuf), nread > 0) {
				if ((res = sendvm(client, sshchannel, rbuf, nread, 0)) == -1){
					close(fd);
					return -1;
				}
			}
			if(eof) {
				if ((res = sendvm(client, sshchannel, "EOF", 3, 0)) == -1){
					close(fd);
					return -1;
				}
			}
			close(fd);
			return 0;
		}

		size = file_size(pcapfile);
		if(!size) {
			sendvm(client, sshchannel, "0", 1, 0);
			return -1;
		}
	
		sprintf(cmd, "PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin tshark -r \"%s.pcap\" -R sip > \"%s.pcap2txt\" 2>/dev/null", filename, filename);
		system(cmd);
		sprintf(cmd, "echo ==== >> \"%s.pcap2txt\"", filename);
		system(cmd);
		sprintf(cmd, "PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin tshark -r \"%s.pcap\" -V -R sip >> \"%s.pcap2txt\" 2>/dev/null", filename, filename);
		system(cmd);

		size = file_size(tsharkfile);
		if(size) {
			fd = open(tsharkfile, O_RDONLY);
			if(fd < 0) {
				snprintf(buf_output, sizeof(buf_output), "error: cannot open file [%s]", filename);
				if ((res = sendvm(client, sshchannel, buf_output, strlen(buf_output), 0)) == -1){
					cerr << "Error sending data to client" << endl;
				}
				return -1;
			}
			while(nread = read(fd, rbuf, sizeof rbuf), nread > 0) {
				if ((res = sendvm(client, sshchannel, rbuf, nread, 0)) == -1){
					close(fd);
					return -1;
				}
			}
			if(eof) {
				if ((res = sendvm(client, sshchannel, "EOF", 3, 0)) == -1){
					close(fd);
					return -1;
				}
			}
			close(fd);
			return 0;
		}
		return 0;
	} else if(strstr(buf, "genhttppcap") != NULL) {
		char timestamp_from[100]; 
		char timestamp_to[100]; 
		char *ids = new FILE_LINE(13012) char [1000000];
		sscanf(buf, "genhttppcap %19[T0-9--: ] %19[T0-9--: ] %s", timestamp_from, timestamp_to, ids);
		/*
		cout << timestamp_from << endl
		     << timestamp_to << endl
		     << ids << endl;
		*/
		HttpPacketsDumper dumper;
		dumper.setTemplatePcapName();
		dumper.setUnlinkPcap();
		dumper.dumpData(timestamp_from, timestamp_to, ids);
		dumper.closePcapDumper();
		
		delete [] ids;
		
		if(!dumper.getPcapName().empty() &&
		   file_exists(dumper.getPcapName()) > 0) {
			return(sendFile(dumper.getPcapName().c_str(), client, sshchannel, false));
		} else {
			sendvm(client, sshchannel, "null", 4, 0);
			return(0);
		}
	} else if(strstr(buf, "quit") != NULL) {
		return 0;
	} else if(strstr(buf, "terminating") != NULL) {
		vm_terminate();
	} else if(strstr(buf, "coutstr") != NULL) {
		char *pointToSpaceSeparator = strchr(buf, ' ');
		if(pointToSpaceSeparator) {
			cout << (pointToSpaceSeparator + 1) << flush;
		}
	} else if(strstr(buf, "syslogstr") != NULL) {
		char *pointToSpaceSeparator = strchr(buf, ' ');
		if(pointToSpaceSeparator) {
			syslog(LOG_NOTICE, "%s", pointToSpaceSeparator + 1);
		}
	} else if(strstr(buf, "custipcache_get_cust_id") != NULL) {
		char ip[20];
		sscanf(buf, "custipcache_get_cust_id %s", ip);
		CustIpCache *custIpCache = getCustIpCache();
		if(custIpCache) {
			unsigned int cust_id = custIpCache->getCustByIp(inet_addr(ip));
			snprintf(sendbuf, BUFSIZE, "cust_id: %u\n", cust_id);
			if((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1) {
				cerr << "Error sending data to client" << endl;
				return -1;
			}
		}
		return 0;
	} else if(strstr(buf, "custipcache_refresh") != NULL) {
		int rslt = refreshCustIpCache();
		snprintf(sendbuf, BUFSIZE, "rslt: %i\n", rslt);
		if((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1) {
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "custipcache_vect_print") != NULL) {
		CustIpCache *custIpCache = getCustIpCache();
		if(custIpCache) {
			string rslt = custIpCache->printVect();
			if((size = sendvm(client, sshchannel, rslt.c_str(), rslt.length(), 0)) == -1) {
				cerr << "Error sending data to client" << endl;
				return -1;
			}
		}
		return 0;
	} else if(strstr(buf, "restart") != NULL ||
		  strstr(buf, "upgrade") != NULL) {
		bool upgrade = false;
		string version;
		string url;
		string md5_32;
		string md5_64;
		string md5_arm;
		string rsltForSend;
		if(strstr(buf, "upgrade") != NULL) {
			extern bool opt_upgrade_by_git;
			if(opt_upgrade_by_git) {
				rsltForSend = "upgrade from official binary source disabled - upgrade by git!";
			} else {
				upgrade = true;
				string command = buf;
				size_t pos = command.find("to: [");
				if(pos != string::npos) {
					size_t posEnd = command.find("]", pos);
					if(posEnd != string::npos) {
						version = command.substr(pos + 5, posEnd - pos - 5);
					}
				}
				if(pos != string::npos) {
					pos = command.find("url: [", pos);
					if(pos != string::npos) {
						size_t posEnd = command.find("]", pos);
						if(posEnd != string::npos) {
							url = command.substr(pos + 6, posEnd - pos - 6);
						}
					}
				}
				if(pos != string::npos) {
					pos = command.find("md5: [", pos);
					if(pos != string::npos) {
						size_t posEnd = command.find("]", pos);
						if(posEnd != string::npos) {
							md5_32 = command.substr(pos + 6, posEnd - pos - 6);
						}
						for(int i = 0; i < 2; i++) {
							pos = command.find(" / [", pos);
							if(pos != string::npos) {
								size_t posEnd = command.find("]", pos);
								if(posEnd != string::npos) {
									string md5 = command.substr(pos + 4, posEnd - pos - 4);
									if(i == 0) {
										md5_64 = md5;
									} else {
										md5_arm = md5;
									}
									pos = posEnd;
								} else {
									break;
								}
							} else {
								break;
							}
						}
					}
				}
				if(!version.length()) {
					rsltForSend = "missing version in command line";
				} else if(!url.length()) {
					rsltForSend = "missing url in command line";
				} else if(!md5_32.length() || !md5_64.length()) {
					rsltForSend = "missing md5 in command line";
				}
			}
		}
		bool ok = false;
		RestartUpgrade restart(upgrade, version.c_str(), url.c_str(), md5_32.c_str(), md5_64.c_str(), md5_arm.c_str());
		if(!rsltForSend.length()) {
			if(restart.createRestartScript() && restart.createSafeRunScript()) {
				if((!upgrade || restart.runUpgrade()) &&
				   restart.checkReadyRestart() &&
				   restart.isOk()) {
					ok = true;
				}
			}
			rsltForSend = restart.getRsltString();
		}
		if ((size = sendvm(client, sshchannel, rsltForSend.c_str(), rsltForSend.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		if(ok) {
			restart.runRestart(client, manager_socket_server);
		}
		return 0;
	} else if(strstr(buf, "gitUpgrade") != NULL) {
		char cmd[100];
		sscanf(buf, "gitUpgrade %s", cmd);
		RestartUpgrade upgrade;
		bool rslt = upgrade.runGitUpgrade(cmd);
		string rsltString;
		if(rslt) {
			rsltString = "OK";
		} else {
			rsltString = upgrade.getErrorString();
		}
		rsltString.append("\n");
		if ((size = sendvm(client, sshchannel, rsltString.c_str(), rsltString.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "sniffer_stat") != NULL) {
		extern vm_atomic<string> storingCdrLastWriteAt;
		extern vm_atomic<string> storingRegisterLastWriteAt;
		extern vm_atomic<string> pbStatString;
		extern vm_atomic<u_long> pbCountPacketDrop;
		extern bool opt_upgrade_by_git;
		extern bool packetbuffer_memory_is_full;
		extern vm_atomic<string> terminating_error;
		ostringstream outStrStat;
		extern int vm_rrd_version;
		checkRrdVersion(true);
		while(__sync_lock_test_and_set(&usersniffer_sync, 1));
		size_t countLiveSniffers = usersniffer.size();
		__sync_lock_release(&usersniffer_sync);
		outStrStat << "{";
		outStrStat << "\"version\": \"" << RTPSENSOR_VERSION << "\",";
		outStrStat << "\"rrd_version\": \"" << vm_rrd_version << "\",";
		outStrStat << "\"storingCdrLastWriteAt\": \"" << storingCdrLastWriteAt << "\",";
		outStrStat << "\"pbStatString\": \"" << pbStatString << "\",";
		outStrStat << "\"pbCountPacketDrop\": \"" << pbCountPacketDrop << "\",";
		outStrStat << "\"uptime\": \"" << getUptime() << "\",";
		outStrStat << "\"memory_is_full\": \"" << packetbuffer_memory_is_full << "\",";
		outStrStat << "\"count_live_sniffers\": \"" << countLiveSniffers << "\",";
		outStrStat << "\"upgrade_by_git\": \"" << opt_upgrade_by_git << "\",";
		outStrStat << "\"use_new_config\": \"" << useNewCONFIG << "\",";
		outStrStat << "\"terminating_error\": \"" << terminating_error << "\"";
		outStrStat << "}";
		outStrStat << endl;
		string outStrStatStr = outStrStat.str();
		if ((size = sendvm(client, sshchannel, outStrStatStr.c_str(), outStrStatStr.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "sniffer_threads") != NULL) {
		extern cThreadMonitor threadMonitor;
		string threads = threadMonitor.output();
		if ((size = sendvm(client, sshchannel, threads.c_str(), threads.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return 0;
	} else if(strstr(buf, "pcapstat") != NULL) {
		extern PcapQueue *pcapQueueStatInterface;
		string rslt;
		if(pcapQueueStatInterface) {
			rslt = pcapQueueStatInterface->pcapDropCountStat();
			if(!rslt.length()) {
				rslt = "ok";
			}
		} else {
			rslt = "no PcapQueue mode";
		}
		if ((size = sendvm(client, sshchannel, rslt.c_str(), rslt.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
		return(0);
	} else if(strstr(buf, "login_screen_popup") != NULL) {
		*managerClientThread =  new FILE_LINE(13013) ManagerClientThread_screen_popup(client, buf);
	} else if(strstr(buf, "ac_add_thread") != NULL) {
		extern AsyncClose *asyncClose;
		asyncClose->addThread();
		if ((size = sendvm(client, sshchannel, "ok\n", 3, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "ac_remove_thread") != NULL) {
		extern AsyncClose *asyncClose;
		asyncClose->removeThread();
		if ((size = sendvm(client, sshchannel, "ok\n", 3, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "t2sip_add_thread") != NULL) {
		PreProcessPacket::autoStartNextLevelPreProcessPacket();
		if ((size = sendvm(client, sshchannel, "ok\n", 3, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "t2sip_remove_thread") != NULL) {
		PreProcessPacket::autoStopLastLevelPreProcessPacket(true);
		if ((size = sendvm(client, sshchannel, "ok\n", 3, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "rtpread_add_thread") != NULL) {
		add_rtp_read_thread();
		if ((size = sendvm(client, sshchannel, "ok\n", 3, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "rtpread_remove_thread") != NULL) {
		set_remove_rtp_read_thread();
		if ((size = sendvm(client, sshchannel, "ok\n", 3, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "enable_bad_packet_order_warning") != NULL) {
		enable_bad_packet_order_warning = 1;
		if ((size = sendvm(client, sshchannel, "ok\n", 3, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "sipports") != NULL) {
		ostringstream outStrSipPorts;
		extern char *sipportmatrix;
		for(int i = 0; i < 65537; i++) {
			if(sipportmatrix[i]) {
				outStrSipPorts << i << ',';
			}
		}
		outStrSipPorts << endl;
		string strSipPorts = outStrSipPorts.str();
		if ((size = sendvm(client, sshchannel, strSipPorts.c_str(), strSipPorts.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "convertchars") != NULL) {
		ostringstream outStrConvertchar;
		extern char opt_convert_char[64];
		for(unsigned int i = 0; i < sizeof(opt_convert_char) && opt_convert_char[i]; i++) {
			outStrConvertchar << opt_convert_char[i] << ',';
		}
		outStrConvertchar << endl;
		string strConvertchar = outStrConvertchar.str();
		if ((size = sendvm(client, sshchannel, strConvertchar.c_str(), strConvertchar.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "sql_time_information") != NULL) {
		string timezone_name = "UTC";
		long timezone_offset = 0;
		extern bool opt_sql_time_utc;
		extern bool is_cloud;
		if(!opt_sql_time_utc && !is_cloud) {
			time_t t = time(NULL);
			struct tm lt;
			::localtime_r(&t, &lt);
			timezone_name = getSystemTimezone();
			if(timezone_name.empty()) {
				timezone_name = lt.tm_zone;
			}
			timezone_offset = lt.tm_gmtoff;
		}
		snprintf(sendbuf, BUFSIZE, "%s,%li,%s", 
			 timezone_name.c_str(),
			 timezone_offset,
			 sqlDateTimeString(time(NULL)).c_str());
		if ((size = sendvm(client, sshchannel, sendbuf, strlen(sendbuf), 0)) == -1) {
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "sqlexport") != NULL ||
		  strstr(buf, "sqlvmexport") != NULL) {
		bool sqlFormat = strstr(buf, "sqlexport") != NULL;
		extern MySqlStore *sqlStore;
		string rslt = sqlStore->exportToFile(NULL, "auto", sqlFormat, strstr(buf, "clean") != NULL);
		if ((size = sendvm(client, sshchannel, rslt.c_str(), rslt.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "memory_stat") != NULL) {
		string rsltMemoryStat = getMemoryStat();
		if ((size = sendvm(client, sshchannel, rsltMemoryStat.c_str(), rsltMemoryStat.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "jemalloc_stat") != NULL) {
		string jeMallocStat(bool full);
		string rsltMemoryStat = jeMallocStat(strstr(buf, "full"));
		if ((size = sendvm(client, sshchannel, rsltMemoryStat.c_str(), rsltMemoryStat.length(), 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	} else if(strstr(buf, "cloud_activecheck") != NULL) {
		cloud_activecheck_success();
	} else if(buf[0] == 'b' and strstr(buf, "blocktar") != NULL) {
		opt_blocktarwrite = 1;
	} else if(buf[0] == 'u' and strstr(buf, "unblocktar") != NULL) {
		opt_blocktarwrite = 0;
	} else if(buf[0] == 'b' and strstr(buf, "blockasync") != NULL) {
		opt_blockasyncprocess = 1;
	} else if(buf[0] == 'u' and strstr(buf, "unblockasync") != NULL) {
		opt_blockasyncprocess = 0;
	} else if(buf[0] == 'b' and strstr(buf, "blockprocesspacket") != NULL) {
		opt_blockprocesspacket = 1;
	} else if(buf[0] == 'u' and strstr(buf, "unblockprocesspacket") != NULL) {
		opt_blockprocesspacket = 0;
	} else if(buf[0] == 's' and strstr(buf, "sleepprocesspacket") != NULL) {
		opt_sleepprocesspacket = 1;
	} else if(buf[0] == 'u' and strstr(buf, "unsleepprocesspacket") != NULL) {
		opt_sleepprocesspacket = 0;
	} else if(buf[0] == 'b' and strstr(buf, "blockqfile") != NULL) {
		opt_blockqfile = 1;
	} else if(buf[0] == 'u' and strstr(buf, "unblockqfile") != NULL) {
		opt_blockqfile = 0;
	} else if(buf[0] == 'b' and strstr(buf, "block_alloc_stack") != NULL) {
		opt_block_alloc_stack = 1;
	} else if(buf[0] == 'u' and strstr(buf, "unblock_alloc_stack") != NULL) {
		opt_block_alloc_stack = 0;
#ifndef FREEBSD
	} else if(strstr(buf, "malloc_trim") != NULL) {
		malloc_trim(0);
#endif
	} else if(strstr(buf, "memcrash_test_1") != NULL) {
		char *test = new FILE_LINE(13014) char[10];
		test[10] = 1;
	} else if(strstr(buf, "memcrash_test_2") != NULL) {
		char *test = new FILE_LINE(13015) char[10];
		delete [] test;
		delete [] test;
	} else if(strstr(buf, "memcrash_test_3") != NULL) {
		char *test = new FILE_LINE(13016) char[10];
		delete [] test;
		test[0] = 1;
	} else if(strstr(buf, "memcrash_test_4") != NULL) {
		char *test[10];
		for(int i = 0; i < 10; i++) {
			test[i] = new FILE_LINE(13017) char[10];
		}
		memset(test[4] + 10, 0, 40);
	} else if(strstr(buf, "memcrash_test_5") != NULL) {
		char *test = NULL;
		*test = 0;
	} else if(strstr(buf, "set_pcap_stat_period") != NULL) {
		int new_pcap_stat_period = atoi(buf + 21);
		if(new_pcap_stat_period > 0 && new_pcap_stat_period < 600) {
			sverb.pcap_stat_period = new_pcap_stat_period;
		}
	} else {
		if ((size = sendvm(client, sshchannel, "command not found\n", 18, 0)) == -1){
			cerr << "Error sending data to client" << endl;
			return -1;
		}
	}
	return 1;
}


void *manager_client(void */*dummy*/) {
	u_int32_t host_ipl;
	struct sockaddr_in addr;
	int res;
	int client = 0;
	char buf[BUFSIZE];
	char sendbuf[BUFSIZE];
	int size;
	

	while(1) {
		host_ipl = gethostbyname_lock(opt_clientmanager);
		if (!host_ipl) { //Report lookup failure  
			syslog(LOG_ERR, "Cannot resolv: %s: host [%s] trying again...\n",  hstrerror(h_errno),  opt_clientmanager);  
			sleep(1);
			continue;  
		} 
		break;
	}
connect:
	client = socket(PF_INET, SOCK_STREAM, 0); /* create socket */
	memset(&addr, 0, sizeof(addr));    /* create & zero struct */
	addr.sin_family = AF_INET;    /* select internet protocol */
	addr.sin_port = htons(opt_clientmanagerport);         /* set the port # */
	addr.sin_addr.s_addr = host_ipl; /* set the addr */
	syslog(LOG_NOTICE, "Connecting to manager server [%s]\n", inet_ntostring(htonl(host_ipl)).c_str());
	while(1) {
		res = connect(client, (struct sockaddr *)&addr, sizeof(addr));         /* connect! */
		if(res == -1) {
			syslog(LOG_NOTICE, "Failed to connect to server [%s] error:[%s] trying again...\n", inet_ntostring(htonl(host_ipl)).c_str(), strerror(errno));
			sleep(1);
			continue;
		}
		break;
	}

	// send login
	snprintf(sendbuf, BUFSIZE, "login %s", mac);
	if ((size = send(client, sendbuf, strlen(sendbuf), 0)) == -1){
		perror("send()");
		sleep(1);
		goto connect;
	}

	// catch the reply
	size = recv(client, buf, BUFSIZE - 1, 0);
	buf[size] = '\0';

	while(1) {

		string buf_long;
		//cout << "New manager connect from: " << inet_ntoa((in_addr)clientInfo.sin_addr) << endl;
		size = recv(client, buf, BUFSIZE - 1, 0);
		if (size == -1 or size == 0) {
			//cerr << "Error in receiving data" << endl;
			perror("recv()");
			close(client);
			sleep(1);
			goto connect;
		}
		buf[size] = '\0';
//		if(verbosity > 0) syslog(LOG_NOTICE, "recv[%s]\n", buf);
		//res = parse_command(buf, size, client, 1, buf_long.c_str());
		res = parse_command(buf, size, client, 1);
	
#if 0	
		//cout << "New manager connect from: " << inet_ntoa((in_addr)clientInfo.sin_addr) << endl;
		size = recv(client, buf, BUFSIZE - 1, 0);
		if (size == -1 or size == 0) {
			//cerr << "Error in receiving data" << endl;
			perror("recv()");
			close(client);
			sleep(1);
			goto connect;
		} else {
			buf[size] = '\0';
			buf_long = buf;
			char buf_next[BUFSIZE];
			while((size = recv(client, buf_next, BUFSIZE - 1, 0)) > 0) {
				buf_next[size] = '\0';
				buf_long += buf_next;
			}
		}
		buf[size] = '\0';
		if(verbosity > 0) syslog(LOG_NOTICE, "recv[%s]\n", buf);
		res = parse_command(buf, size, client, 1, buf_long.c_str());
#endif
	}

	return 0;
}

/*
struct svi {
	volatile char command_type[100];
	volatile int i;
};
volatile svi vi[500];
extern pthread_mutex_t commmand_type_counter_sync;

bool _strncmp_v(volatile char a[], const char *b, unsigned length) {
	for(unsigned i = 0; i < length; i++) {
		if(a[i] != b[i]) {
			return(true);
		}
		if(!a[i] || !b[i]) {
			break;
		}
	}
	return(false);
}

bool _strncpy_v(volatile char dst[], const char *src, unsigned length) {
	for(unsigned i = 0; i < length; i++) {
		dst[i] = src[i];
		if(!src[i]) {
			break;
		}
	}
}

static bool addCommandType(string command_type) {
	bool rslt = false;
	pthread_mutex_lock(&commmand_type_counter_sync);
	for(unsigned i = 0; i < sizeof(vi) / sizeof(svi); i++) {
		if(!_strncmp_v(vi[i].command_type, command_type.c_str(), sizeof(vi[i].command_type))) {
			if(vi[i].i < 20) {
				++vi[i].i;
				rslt = true;
			}
			break;
		} else if(!vi[i].command_type[0]) {
			_strncpy_v(vi[i].command_type, command_type.c_str(), sizeof(vi[i].command_type));
			vi[i].i = 1;
			rslt = true;
			break;
		}
	}
	
// 	map<string, vi*>::iterator iter = commmand_type_counter.find(command_type);
// 	if(iter == commmand_type_counter.end()) {
// 		vi *_i = new vi;
// 		_i->i = 1;
// 		commmand_type_counter[command_type] = _i;
// 		rslt = true;
// 	} else {
// 		if(commmand_type_counter[command_type]->i < 20) {
// 			__sync_add_and_fetch(&commmand_type_counter[command_type]->i, 1);
// 			rslt = true;
// 		}
// 	}
	
	pthread_mutex_unlock(&commmand_type_counter_sync);
	return(rslt);
}

static void subCommandType(string command_type) {
	pthread_mutex_lock(&commmand_type_counter_sync);
	for(unsigned i = 0; i < sizeof(vi) / sizeof(svi); i++) {
		if(!_strncmp_v(vi[i].command_type, command_type.c_str(), sizeof(vi[i].command_type))) {
			if(vi[i].i > 0) {
				--vi[i].i;
			}
			break;
		}
	}
	
// 	if(commmand_type_counter[command_type]->i > 0) {
// 		__sync_sub_and_fetch(&commmand_type_counter[command_type]->i, 1);
// 	}
	
	pthread_mutex_unlock(&commmand_type_counter_sync);
}
*/

void *manager_read_thread(void * arg) {

	char buf[BUFSIZE];
	string buf_long;
	int size;
	unsigned int    client;
	client = *(unsigned int *)arg;
	delete (unsigned int*)arg;

	//cout << "New manager connect from: " << inet_ntoa((in_addr)clientInfo.sin_addr) << endl;
	if ((size = recv(client, buf, BUFSIZE - 1, 0)) == -1) {
		cerr << "Error in receiving data" << endl;
		close(client);
		return 0;
	} else {
		buf[size] = '\0';
		buf_long = buf;
		////cout << "DATA: " << buf << endl;
		if(!strstr(buf, "\r\n\r\n")) {
			char buf_next[BUFSIZE];
			////cout << "NEXT_RECV start" << endl;
			while(true) {
				fd_set rfds;
				struct timeval tv;
				FD_ZERO(&rfds);
				FD_SET(client, &rfds);
				tv.tv_sec = 0;
				tv.tv_usec = 250000;
				if(select(client + 1, &rfds, (fd_set *) 0, (fd_set *) 0, &tv) > 0 &&
				   (size = recv(client, buf_next, BUFSIZE - 1, 0)) > 0) {
					buf_next[size] = '\0';
					buf_long += buf_next;
					////cout << "NEXT DATA: " << buf_next << endl;
					////cout << "NEXT_RECV read" << endl;
					if(buf_long.find("\r\n\r\n") != string::npos) {
						break;
					}
				} else {
					break;
				}
			}
			////cout << "NEXT_RECV stop" << endl;
			size_t posEnd;
			if((posEnd = buf_long.find("\r\n\r\n")) != string::npos) {
				buf_long.resize(posEnd);
			}
		}
	}
	ManagerClientThread *managerClientThread = NULL;
	/*
	string command_type;
	size_t pos_separator = buf_long.find(' ');
	if(pos_separator == string::npos) {
		command_type = buf_long;
	} else {
		command_type = buf_long.substr(0, pos_separator);
	}
	if(addCommandType(command_type)) {
		parse_command((char*)buf_long.c_str(), size, client, 0, &managerClientThread);
		subCommandType(command_type);
	} else {
		syslog(LOG_NOTICE, "suppress run command %s", command_type.c_str());
	}
	*/
	parse_command((char*)buf_long.c_str(), size, client, 0, &managerClientThread);
	if(managerClientThread) {
		if(managerClientThread->parseCommand()) {
			ClientThreads.add(managerClientThread);
			managerClientThread->run();
		} else {
			delete managerClientThread;
			close(client);
		}
	} else {
		close(client);
	}

	return 0;
}

void perror_syslog(const char *msg) {
	char buf[1024];
	strerror_r(errno, buf, 1024);
	syslog(LOG_ERR, "%s:%s\n", msg, buf);
}

#ifdef HAVE_LIBSSH
void *manager_ssh_(void) {
	ssh_session session;
	int rc;
	// Open session and set options
	list<ssh_channel> ssh_chans;
	list<ssh_channel>::iterator it1;
	char buf[1024*1024]; 
	int len;
	session = ssh_new();
	if (session == NULL)
		exit(-1);
	ssh_options_set(session, SSH_OPTIONS_HOST, ssh_host);
	ssh_options_set(session, SSH_OPTIONS_PORT, &ssh_port);
	ssh_options_set(session, SSH_OPTIONS_COMPRESSION, "yes");
	ssh_options_set(session, SSH_OPTIONS_SSH_DIR, "/tmp");
	ssh_options_set(session, SSH_OPTIONS_USER, "root");
	// Connect to server
	rc = ssh_connect(session);
	if (rc != SSH_OK) {
		syslog(LOG_ERR, "Error connecting to %s: %s\n", ssh_host, ssh_get_error(session));
		ssh_free(session);
		return 0;
	}
/*
	// Verify the server's identity
	// For the source code of verify_knowhost(), check previous example
	if (verify_knownhost(session) < 0)
	{
		ssh_disconnect(session);
		ssh_free(session);
		exit(-1);
	}
*/
	// Authenticate ourselves
	rc = ssh_userauth_password(session, ssh_username, ssh_password);
	if (rc != SSH_AUTH_SUCCESS) {
		syslog(LOG_ERR, "Error authenticating with password: %s\n", ssh_get_error(session));
		ssh_disconnect(session);
		ssh_free(session);
		goto ssh_disconnect;
	}
	syslog(LOG_NOTICE, "Connected to ssh\n");

	int remote_listenport;
	rc = ssh_forward_listen(session, ssh_remote_listenhost, ssh_remote_listenport, &remote_listenport);
	if (rc != SSH_OK) {
		syslog(LOG_ERR, "Error opening remote port: %s\n", ssh_get_error(session));
		goto ssh_disconnect;
	}
	syslog(LOG_NOTICE, "connection established\n");

	pthread_attr_t attr;
	pthread_attr_init(&attr);

	cloud_activecheck_sshclose = false; //alow active checking operations from now
	/* set the thread detach state */
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	while(1) {
		if (cloud_activecheck_sshclose) goto ssh_disconnect;
		ssh_channel channel;
		//int port;
		//channel = ssh_channel_accept_forward(session, 0, &port);
		channel = ssh_forward_accept(session, 0);
		usleep(10000);
		if (channel == NULL) {
			if(!ssh_is_connected(session)) {
				break;
			}
		} else {
			ssh_chans.push_back(channel);
		}
		for (it1 = ssh_chans.begin(); it1 != ssh_chans.end();) {
			ssh_channel channel = *it1;
			if(ssh_channel_is_open(channel) && !ssh_channel_is_eof(channel)) {
				len = ssh_channel_read_nonblocking(channel, buf, sizeof(buf), 0);
				if(len == SSH_ERROR) {
					// read error 
					ssh_channel_free(channel);
					ssh_chans.erase(it1++);
					continue;
				}
				if (len <= 0) {
					++it1;
					continue;
				}
				buf[len] = '\0';
				parse_command(buf, len, 0, 0, NULL, channel);
				ssh_channel_send_eof(channel);
				ssh_channel_free(channel);
				ssh_chans.erase(it1++);
			} else {
				// channel is closed already, remove it
				ssh_channel_free(channel);
				ssh_chans.erase(it1++);
			}
		}
	}
ssh_disconnect:
	ssh_disconnect(session);
	ssh_free(session);
	return 0;
}
#endif

#ifdef HAVE_LIBSSH
void *manager_ssh(void */*arg*/) {
	while (ssh_host[0] == '\0') {	//wait until register.php POST done
		sleep(1);
	}

	ssh_threads_set_callbacks(ssh_threads_get_pthread());
	ssh_init();
//	ssh_set_log_level(SSH_LOG_WARNING | SSH_LOG_PROTOCOL | SSH_LOG_PACKET | SSH_LOG_FUNCTIONS);
	while(!is_terminating()) {
		syslog(LOG_NOTICE, "Starting reverse SSH connection service\n");
		manager_ssh_();
		syslog(LOG_NOTICE, "SSH service stopped.\n");
		sleep(1);
	}
	return 0;
}
#endif


void *manager_server(void */*dummy*/) {
 
	sockaddr_in sockName;
	sockaddr_in clientInfo;
	socklen_t addrlen;

	// Vytvorime soket - viz minuly dil
	if ((manager_socket_server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
		cerr << "Cannot create manager tcp socket" << endl;
		return 0;
	}
	sockName.sin_family = AF_INET;
	sockName.sin_port = htons(opt_manager_port);
	//sockName.sin_addr.s_addr = INADDR_ANY;
	sockName.sin_addr.s_addr = inet_addr(opt_manager_ip);
	int on = 1;
	setsockopt(manager_socket_server, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	if(opt_manager_nonblock_mode) {
		int flags = fcntl(manager_socket_server, F_GETFL, 0);
		if(flags >= 0) {
			fcntl(manager_socket_server, F_SETFL, flags | O_NONBLOCK);
		}
	}
tryagain:
	if (bind(manager_socket_server, (sockaddr *)&sockName, sizeof(sockName)) == -1) {
		syslog(LOG_ERR, "Cannot bind to port [%d] trying again after 5 seconds intervals\n", opt_manager_port);
		sleep(5);
		goto tryagain;
	}
	// create queue with 100 connections max 
	if (listen(manager_socket_server, 100) == -1) {
		cerr << "Cannot create manager queue" << endl;
		return 0;
	}
	pthread_t threads;
	pthread_attr_t attr;
	fd_set rfds;
	struct timeval tv;
	while(!is_terminating_without_error()) {
		FD_ZERO(&rfds);
		FD_SET(manager_socket_server, &rfds);
		tv.tv_sec = 10;
		tv.tv_usec = 0;
		if(!opt_manager_nonblock_mode ||
		   select(manager_socket_server + 1, &rfds, (fd_set *) 0, (fd_set *) 0, &tv) > 0) {
			addrlen = sizeof(clientInfo);
			int client = accept(manager_socket_server, (sockaddr*)&clientInfo, &addrlen);
			if(is_terminating_without_error()) {
				close(client);
				close(manager_socket_server);
				return 0;
			}
			if (client == -1) {
				//cerr << "Problem with accept client" <<endl;
				close(client);
				continue;
			}

			pthread_attr_init(&attr);
			unsigned int *_ids = new FILE_LINE(13018) unsigned int;
			*_ids = client;
			int rslt = pthread_create (		/* Create a child thread        */
				       &threads,		/* Thread ID (system assigned)  */    
				       &attr,			/* Default thread attributes    */
				       manager_read_thread,	/* Thread routine               */
				       _ids);			/* Arguments to be passed       */
			pthread_detach(threads);
			pthread_attr_destroy(&attr);
			if(rslt != 0) {
				syslog(LOG_ERR, "manager pthread_create failed with rslt code %i", rslt);
			}
		}
	}
	close(manager_socket_server);
	return 0;
}

void livesnifferfilter_s::updateState() {
	state_s new_state; 
	new_state.all_saddr = true;
	new_state.all_daddr = true;
	new_state.all_bothaddr = true;
	new_state.all_srcnum = true;
	new_state.all_dstnum = true;
	new_state.all_bothnum = true;
	new_state.all_fromhstr = true;
	new_state.all_tohstr = true;
	new_state.all_bothhstr = true;
	new_state.all_vlan = true;
	new_state.all_siptypes = true;
	for(int i = 0; i < MAXLIVEFILTERS; i++) {
		if(this->lv_saddr[i]) {
			new_state.all_saddr = false;
		}
		if(this->lv_daddr[i]) {
			new_state.all_daddr = false;
		}
		if(this->lv_bothaddr[i]) {
			new_state.all_bothaddr = false;
		}
		if(this->lv_srcnum[i][0]) {
			new_state.all_srcnum = false;
		}
		if(this->lv_dstnum[i][0]) {
			new_state.all_dstnum = false;
		}
		if(this->lv_bothnum[i][0]) {
			new_state.all_bothnum = false;
		}
		if(this->lv_fromhstr[i][0]) {
			new_state.all_fromhstr = false;
		}
		if(this->lv_tohstr[i][0]) {
			new_state.all_tohstr = false;
		}
		if(this->lv_bothhstr[i][0]) {
			new_state.all_bothhstr = false;
		}
		if(this->lv_vlan[i][0]) {
			new_state.all_vlan = false;
		}
		if(this->lv_siptypes[i]) {
			new_state.all_siptypes = false;
		}
	}
	new_state.all_addr = new_state.all_saddr && new_state.all_daddr && new_state.all_bothaddr;
	new_state.all_num = new_state.all_srcnum && new_state.all_dstnum && new_state.all_bothnum;
	new_state.all_hstr = new_state.all_fromhstr && new_state.all_tohstr && new_state.all_bothhstr;
	new_state.all_all = new_state.all_addr && new_state.all_num && new_state.all_hstr && new_state.all_vlan && new_state.all_siptypes;
	this->state = new_state;
}

string livesnifferfilter_s::getStringState() {
	ostringstream outStr;
	outStr << "sip type: ";
	if(this->state.all_siptypes) {
		outStr << "all";
	} else {
		int counter = 0;
		for(int i = 0; i < MAXLIVEFILTERS; i++) {
			if(this->lv_siptypes[i]) {
				if(counter) {
					outStr << ",";
				}
				outStr << (this->lv_siptypes[i] == INVITE ? 'I' :
					   this->lv_siptypes[i] == REGISTER ? 'R' :
					   this->lv_siptypes[i] == OPTIONS ? 'O' :
					   this->lv_siptypes[i] == SUBSCRIBE ? 'S' :
					   this->lv_siptypes[i] == MESSAGE ? 'M' :
					   this->lv_siptypes[i] == NOTIFY ? 'N' : '-');
				++counter;
			}
		}
	}
	outStr << " ;   ";
	for(int pass = 1; pass <= 3; pass++) {
		if(!(pass == 1 ? this->state.all_saddr :
		     pass == 2 ? this->state.all_daddr :
				 this->state.all_bothaddr)) {
			unsigned int *addr = pass == 1 ? this->lv_saddr :
					     pass == 2 ? this->lv_daddr :
							 this->lv_bothaddr;
			int counter = 0;
			for(int i = 0; i < MAXLIVEFILTERS; i++) {
				if(addr[i]) {
					if(counter) {
						outStr << ", ";
					} else {
						outStr << (pass == 1 ? "source address" :
							   pass == 2 ? "dest. address" :
							   pass == 3 ? "address" : 
								       "")
						       << ": ";
					}
					outStr << inet_ntostring(addr[i]);
					++counter;
				}
			}
			if(counter) {
				outStr << " ;   ";
			}
		}
	}
	for(int pass = 1; pass <= 3; pass++) {
		if(!(pass == 1 ? this->state.all_srcnum :
		     pass == 2 ? this->state.all_dstnum :
				 this->state.all_bothnum)) {
			char (*num)[MAXLIVEFILTERSCHARS] = pass == 1 ? this->lv_srcnum :
							   pass == 2 ? this->lv_dstnum :
								       this->lv_bothnum;
			int counter = 0;
			for(int i = 0; i < MAXLIVEFILTERS; i++) {
				if(num[i][0]) {
					if(counter) {
						outStr << ", ";
					} else {
						outStr << (pass == 1 ? "source number" :
							   pass == 2 ? "dest. number" :
							   pass == 3 ? "number" : 
								       "")
						       << ": ";
					}
					outStr << num[i];
					++counter;
				}
			}
			if(counter) {
				outStr << " ;   ";
			}
		}
	}
	for(int pass = 1; pass <= 3; pass++) {
		if(!(pass == 1 ? this->state.all_fromhstr :
		     pass == 2 ? this->state.all_tohstr :
				 this->state.all_bothhstr)) {
			char (*hstr)[MAXLIVEFILTERSCHARS] = pass == 1 ? this->lv_fromhstr :
							    pass == 2 ? this->lv_tohstr :
									this->lv_bothhstr;
			int counter = 0;
			for(int i = 0; i < MAXLIVEFILTERS; i++) {
				if(hstr[i][0]) {
					if(counter) {
						outStr << ", ";
					} else {
						outStr << (pass == 1 ? "from header" :
							   pass == 2 ? "to header" :
							   pass == 3 ? "from/to header" :
								       "")
						       << ": ";
					}
					outStr << hstr[i];
					++counter;
				}
			}
			if(counter) {
				outStr << " ;   ";
			}
		}
	}
	return(outStr.str());
}

void updateLivesnifferfilters() {
	livesnifferfilter_use_siptypes_s new_livesnifferfilterUseSipTypes;
	memset(&new_livesnifferfilterUseSipTypes, 0, sizeof(new_livesnifferfilterUseSipTypes));
	if(usersniffer.size()) {
		global_livesniffer = 1;
		map<unsigned int, livesnifferfilter_t*>::iterator usersnifferIT;
		for(usersnifferIT = usersniffer.begin(); usersnifferIT != usersniffer.end(); ++usersnifferIT) {
			usersnifferIT->second->updateState();
			if(usersnifferIT->second->state.all_siptypes) {
				new_livesnifferfilterUseSipTypes.u_invite = true;
				new_livesnifferfilterUseSipTypes.u_register = true;
				new_livesnifferfilterUseSipTypes.u_options = true;
				new_livesnifferfilterUseSipTypes.u_subscribe = true;
				new_livesnifferfilterUseSipTypes.u_message = true;
				new_livesnifferfilterUseSipTypes.u_notify = true;
			} else {
				for(int i = 0; i < MAXLIVEFILTERS; i++) {
					if(usersnifferIT->second->lv_siptypes[i]) {
						switch(usersnifferIT->second->lv_siptypes[i]) {
						case INVITE:
							new_livesnifferfilterUseSipTypes.u_invite = true;
							break;
						case REGISTER:
							new_livesnifferfilterUseSipTypes.u_register = true;
							break;
						case OPTIONS:
							new_livesnifferfilterUseSipTypes.u_options = true;
							break;
						case SUBSCRIBE:
							new_livesnifferfilterUseSipTypes.u_subscribe = true;
							break;
						case MESSAGE:
							new_livesnifferfilterUseSipTypes.u_message = true;
							break;
						case NOTIFY:
							new_livesnifferfilterUseSipTypes.u_notify = true;
							break;
						}
					}
				}
			}
		}
	} else {
		global_livesniffer = 0;
	}
	livesnifferfilterUseSipTypes = new_livesnifferfilterUseSipTypes;
	/*
	cout << "livesnifferfilterUseSipTypes" << endl;
	if(livesnifferfilterUseSipTypes.u_invite) cout << "INVITE" << endl;
	if(livesnifferfilterUseSipTypes.u_register) cout << "REGISTER" << endl;
	if(livesnifferfilterUseSipTypes.u_options) cout << "OPTIONS" << endl;
	if(livesnifferfilterUseSipTypes.u_subscribe) cout << "SUBSCRIBE" << endl;
	if(livesnifferfilterUseSipTypes.u_message) cout << "MESSAGE" << endl;
	if(livesnifferfilterUseSipTypes.u_notify) cout << "NOTIFY" << endl;
	*/
}

bool cmpCallBy_destroy_call_at(Call* a, Call* b) {
	return(a->destroy_call_at < b->destroy_call_at);   
}
bool cmpCallBy_first_packet_time(Call* a, Call* b) {
	return(a->first_packet_time < b->first_packet_time);   
}


ManagerClientThread::ManagerClientThread(int client, const char *type, const char *command, int commandLength) {
	this->client = client;
	this->type = type;
	if(commandLength) {
		this->command = string(command, commandLength);
	} else {
		this->command = command;
	}
	this->finished = false;
	this->_sync_responses = 0;
}

void ManagerClientThread::run() {
	unsigned int counter = 0;
	bool disconnect = false;
	int flag = 0;
	setsockopt(client, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int));
	int flushBuffLength = 1000;
	char *flushBuff = new FILE_LINE(13019) char[flushBuffLength];
	memset(flushBuff, '_', flushBuffLength - 1);
	flushBuff[flushBuffLength - 1] = '\n';
	while(true && !is_terminating_without_error() && !disconnect) {
		string rsltString;
		this->lock_responses();
		if(this->responses.size()) {
			rsltString = this->responses.front();
			this->responses.pop();
		}
		this->unlock_responses();
		if(!rsltString.empty()) {
			if(send(client, rsltString.c_str(), rsltString.length(), 0) == -1) {
				disconnect = true;
			} else {
				send(client, flushBuff, flushBuffLength, 0);
			}
		}
		++counter;
		if((counter % 5) == 0 && !disconnect) {
			if(send(client, "ping\n", 5, 0) == -1) {
				disconnect = true;
			}
		}
		usleep(100000);
	}
	close(client);
	finished = true;
	delete [] flushBuff;
}

ManagerClientThread_screen_popup::ManagerClientThread_screen_popup(int client, const char *command, int commandLength) 
 : ManagerClientThread(client, "screen_popup", command, commandLength) {
	auto_popup = false;
	non_numeric_caller_id = false;
}

bool ManagerClientThread_screen_popup::parseCommand() {
	ClientThreads.cleanup();
	return(this->parseUserPassword());
}

void ManagerClientThread_screen_popup::onCall(int sipResponseNum, const char *callerName, const char *callerNum, const char *calledNum,
					      unsigned int sipSaddr, unsigned int sipDaddr,
					      const char *screenPopupFieldsString) {
	/*
	cout << "** call 01" << endl;
	cout << "** - called num : " << calledNum << endl;
	struct in_addr _in;
	_in.s_addr = sipSaddr;
	cout << "** - src ip : " << inet_ntoa(_in) << endl;
	cout << "** - reg_match : " << reg_match(calledNum, this->dest_number.empty() ? this->username.c_str() : this->dest_number.c_str(), __FILE__, __LINE__) << endl;
	cout << "** - check ip : " << this->src_ip.checkIP(htonl(sipSaddr)) << endl;
	*/
	if(!(reg_match(calledNum, this->dest_number.empty() ? this->username.c_str() : this->dest_number.c_str(), __FILE__, __LINE__) &&
	     (this->non_numeric_caller_id ||
	      this->isNumericId(calledNum)) &&
	     this->src_ip.checkIP(htonl(sipSaddr)))) {
		return;
	}
	if(this->regex_check_calling_number.size()) {
		bool callerNumOk = false;
		for(size_t i = 0; i < this->regex_check_calling_number.size(); i++) {
			if(reg_match(callerNum, this->regex_check_calling_number[i].c_str(), __FILE__, __LINE__)) {
				callerNumOk = true;
				break;
			}
		}
		if(!callerNumOk) {
			return;
		}
	}
	char rsltString[4096];
	char sipSaddrIP[18];
	char sipDaddrIP[18];
	struct in_addr in;
	in.s_addr = sipSaddr;
	strcpy(sipSaddrIP, inet_ntoa(in));
	in.s_addr = sipDaddr;
	strcpy(sipDaddrIP, inet_ntoa(in));
	string callerNumStr = callerNum;
	for(size_t i = 0; i < this->regex_replace_calling_number.size(); i++) {
		string temp = reg_replace(callerNumStr.c_str(), 
					  this->regex_replace_calling_number[i].pattern.c_str(), 
					  this->regex_replace_calling_number[i].replace.c_str(),
					  __FILE__, __LINE__);
		if(!temp.empty()) {
			callerNumStr = temp;
		}
	}
	sprintf(rsltString,
		"call_data: "
		"sipresponse:[[%i]] "
		"callername:[[%s]] "
		"caller:[[%s]] "
		"called:[[%s]] "
		"sipcallerip:[[%s]] "
		"sipcalledip:[[%s]] "
		"fields:[[%s]]\n",
		sipResponseNum,
		callerName,
		callerNumStr.c_str(),
		calledNum,
		sipSaddrIP,
		sipDaddrIP,
		screenPopupFieldsString);
	this->lock_responses();
	this->responses.push(rsltString);
	this->unlock_responses();
}

bool ManagerClientThread_screen_popup::parseUserPassword() {
	char user[128];
	char password[128];
	char key[128];
	sscanf(command.c_str(), "login_screen_popup %s %s %s", user, password, key);
	string password_md5 = GetStringMD5(password);
	SqlDb *sqlDb = createSqlObject();
	sqlDb->query(
		string(
		"select u.username,\
			u.name,\
			u.dest_number,\
			u.allow_change_settings,\
			p.name as profile_name,\
			p.auto_popup,\
			p.show_ip,\
			p.popup_on,\
			p.non_numeric_caller_id,\
			p.regex_calling_number,\
			p.src_ip_whitelist,\
			p.src_ip_blacklist,\
			p.app_launch,\
			p.app_launch_args_or_url,\
			p.popup_title\
		 from screen_popup_users u\
		 join screen_popup_profile p on (p.id=u.profile_id)\
		 where username=") +
		sqlEscapeStringBorder(user) +
		" and password=" + 
		sqlEscapeStringBorder(password_md5));
	SqlDb_row row = sqlDb->fetchRow();
	char rsltString[4096];
	bool rslt;
	if(row) {
		rslt = true;
		username = row["username"];
		name = row["name"];
		dest_number = row["dest_number"];
		allow_change_settings = atoi(row["allow_change_settings"].c_str());
		profile_name = row["profile_name"];
		auto_popup = atoi(row["auto_popup"].c_str());
		show_ip = atoi(row["show_ip"].c_str());
		popup_on = row["popup_on"];
		non_numeric_caller_id = atoi(row["non_numeric_caller_id"].c_str());
		if(!row["regex_calling_number"].empty()) {
			vector<string> items = split(row["regex_calling_number"].c_str(), split("\r|\n", "|"), true);
			for(size_t i = 0; i < items.size(); i++) {
				vector<string> itemItems = split(items[i].c_str(), "|", true);
				if(itemItems.size() == 2) {
					this->regex_replace_calling_number.push_back(RegexReplace(itemItems[0].c_str(), itemItems[1].c_str()));
				} else {
					this->regex_check_calling_number.push_back(itemItems[0]);
				}
			}
		}
		src_ip.addWhite(row["src_ip_whitelist"].c_str());
		src_ip.addBlack(row["src_ip_blacklist"].c_str());
		app_launch = row["app_launch"];
		app_launch_args_or_url = row["app_launch_args_or_url"];
		popup_title = row["popup_title"];
		if(!opt_php_path[0]) {
			rslt = false;
			strcpy(rsltString, "login_failed error:[[Please set php_path parameter in voipmonitor.conf.]]\n");
		} else {
			string cmd = string("php ") + opt_php_path + "/php/run.php checkScreenPopupLicense -k " + key;
			FILE *fp = popen(cmd.c_str(), "r");
			if(fp == NULL) {
				rslt = false;
				strcpy(rsltString, "login_failed error:[[Failed to run php checkScreenPopupLicense.]]\n");
			} else {
				char rsltFromPhp[1024];
				if(!fgets(rsltFromPhp, sizeof(rsltFromPhp) - 1, fp)) {
					rslt = false;
					strcpy(rsltString, "login_failed error:[[License check failed please contact support.]]\n");
				} else if(!strncmp(rsltFromPhp, "error: ", 7)) {
					rslt = false;
					strcpy(rsltString, (string("login_failed error:[[") + (rsltFromPhp + 7) + "]]\n").c_str());
				} else {
					char key[1024];
					int maxClients;
					if(sscanf(rsltFromPhp, "key: %s max_clients: %i", key, &maxClients) == 2) {
						if(maxClients && ClientThreads.getCount() >= maxClients) {
							rslt = false;
							strcpy(rsltString, "login_failed error:[[Maximum connection limit reached.]]\n");
						} else {
							sprintf(rsltString, 
								"login_ok "
								"auto_popup:[[%i]] "
								"popup_on_200:[[%i]] "
								"popup_on_18:[[%i]] "
								"show_ip:[[%i]] "
								"app_launch:[[%s]] "
								"args_or_url:[[%s]] "
								"key:[[%s]] "
								"allow_change_settings:[[%i]] "
								"popup_title:[[%s]]\n", 
								auto_popup, 
								popup_on == "200" || popup_on == "183/180_200",
								popup_on == "183/180" || popup_on == "183/180_200",
								show_ip, 
								app_launch.c_str(), 
								app_launch_args_or_url.c_str(), 
								key, 
								allow_change_settings,
								popup_title.c_str());
						}
					} else {
						rslt = false;
							strcpy(rsltString, "login_failed error:[[License is invalid.]]\n");
					}
				}
				pclose(fp);
			}
		}
	} else {
		rslt = false;
		strcpy(rsltString, "login_failed error:[[Invalid user or password.]]\n");
	}
	delete sqlDb;
	send(client, rsltString, strlen(rsltString), 0);
	return(rslt);
}

bool ManagerClientThread_screen_popup::isNumericId(const char *id) {
	while(*id) {
		if(!isdigit(*id) &&
		   *id != ' ' &&
		   *id != '+') {
			return(false);
		}
		++id;
	}
	return(true);
}

ManagerClientThreads::ManagerClientThreads() {
	_sync_client_threads = 0;
}
	
void ManagerClientThreads::add(ManagerClientThread *clientThread) {
	this->lock_client_threads();
	clientThreads.push_back(clientThread);
	this->unlock_client_threads();
	this->cleanup();
}

void ManagerClientThreads::onCall(int sipResponseNum, const char *callerName, const char *callerNum, const char *calledNum,
				  unsigned int sipSaddr, unsigned int sipDaddr,
				  const char *screenPopupFieldsString) {
	this->lock_client_threads();
	vector<ManagerClientThread*>::iterator iter;
	for(iter = this->clientThreads.begin(); iter != this->clientThreads.end(); ++iter) {
		(*iter)->onCall(sipResponseNum, callerName, callerNum, calledNum, 
				sipSaddr, sipDaddr, 
				screenPopupFieldsString);
	}
	this->unlock_client_threads();
}

void ManagerClientThreads::cleanup() {
	this->lock_client_threads();
	for(int i = this->clientThreads.size() - 1; i >=0; i--) {
		ManagerClientThread *ct = this->clientThreads[i];
		if(ct->isFinished()) {
			delete ct;
			this->clientThreads.erase(this->clientThreads.begin() + i);
			
		}
	}
	this->unlock_client_threads();
}

int ManagerClientThreads::getCount() {
	this->lock_client_threads();
	int count = this->clientThreads.size();
	this->unlock_client_threads();
	return(count);
}

int sendFile(const char *fileName, int client, ssh_channel sshchannel, bool zip) {
	int fd = open(fileName, O_RDONLY);
	if(fd < 0) {
		char buf[1000];
		sprintf(buf, "error: cannot open file [%s]", fileName);
		if(sendvm(client, sshchannel, buf, strlen(buf), 0) == -1){
			cerr << "Error sending data to client" << endl;
		}
		return -1;
	}
	RecompressStream *recompressStream = new FILE_LINE(0) RecompressStream(RecompressStream::compress_na, zip ? RecompressStream::gzip : RecompressStream::compress_na);
	recompressStream->setSendParameters(client, sshchannel);
	ssize_t nread;
	size_t read_size = 0;
	char rbuf[4096];
	while(nread = read(fd, rbuf, sizeof(rbuf)), nread > 0) {
		if(!read_size) {
			if(nread >= 2 &&
			   (unsigned char)rbuf[0] == 0x1f && 
			   (unsigned char)rbuf[1] == 0x8b) {
				if(zip) {
					recompressStream->setTypeCompress(RecompressStream::compress_na);
					recompressStream->setTypeDecompress(RecompressStream::compress_na);
				}
			} else if(nread >= 3 &&
				  rbuf[0] == 'L' && rbuf[1] == 'Z' && rbuf[2] == 'O') {
				recompressStream->setTypeDecompress(RecompressStream::lzo, true);
			}
		}
		read_size += nread;
		recompressStream->processData(rbuf, nread);
		if(recompressStream->isError()) {
			close(fd);
			return -1;
		}
	}
	close(fd);
	delete recompressStream;
	return(0);
}

int sendString(string *str, int client, ssh_channel sshchannel, bool zip) {
	if(str->empty()) {
		return(0);
	}
	CompressStream *compressStream = NULL;
	if(zip &&
	   ((*str)[0] != 0x1f || (str->length() > 1 && (unsigned char)(*str)[1] != 0x8b))) {
		compressStream = new FILE_LINE(13021) CompressStream(CompressStream::gzip, 1024, 0);
		compressStream->setSendParameters(client, sshchannel);
	}
	unsigned chunkLength = 4096;
	unsigned processedLength = 0;
	while(processedLength < str->length()) {
		unsigned processLength = MIN(chunkLength, str->length() - processedLength);
		if(compressStream) {
			compressStream->compress((char*)str->c_str() + processedLength, processLength, false, compressStream);
			if(compressStream->isError()) {
				return -1;
			}
		} else {
			if(sendvm(client, sshchannel, (char*)str->c_str() + processedLength, processLength, 0) == -1){
				return -1;
			}
		}
		processedLength += processLength;
	}
	if(compressStream) {
		compressStream->compress(NULL, 0, true, compressStream);
		delete compressStream;
	}
	
	return(0);
}
