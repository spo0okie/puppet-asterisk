/*
 * buildopts.h 
 * Automatically generated
 */

#define DONT_OPTIMIZE 1
#define LOADABLE_MODULES 1
#define AST_BUILDOPT_SUM "361d7bb937402d51e4658efb5b4d76e4"
