The vast majority of the Asterisk project documentation has been moved to the
project wiki:
    
    http://wiki.asterisk.org/

Asterisk release tarballs contain an export of the wiki in PDF and plain text
form, which you can find in:

    doc/AST.pdf
    doc/AST.txt
