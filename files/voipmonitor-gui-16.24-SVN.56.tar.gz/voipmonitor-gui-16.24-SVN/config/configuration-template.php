<?PHP

define("SNIFFER_NAME", "voipmonitor"); // mysql || mssql || odbc
define("SQL_DRIVER", "mysql"); // mysql || mssql || odbc
define("SQL_CDRTABLE", "cdr");
define("SQL_CDR_RTP_TABLE", "cdr_rtp");
define("SQL_CDR_NEXT_TABLE", "cdr_next");
define("SQL_CDR_PHONE_NUMBER_TABLE", "cdr_phone_number");
define("SQL_CDR_NAME_TABLE", "cdr_name");
define("SQL_CDR_DOMAIN_TABLE", "cdr_domain");
define("SQL_CDR_UA_TABLE", "cdr_ua");
define("SQL_CDR_SIP_RESPONSE_TABLE", "cdr_sip_response");


define("MYSQL_HOST", "127.0.0.1");
define("MYSQL_DB", "voipmonitor");
define("MYSQL_USER", "root");
define("MYSQL_PASS", "");

define("MSSQL_HOST", "127.0.0.1");
define("MSSQL_DB", "voipmonitor");
define("MSSQL_USER", "root");
define("MSSQL_PASS", "");



define("ODBC_DSN", "voipmonitor");
define("ODBC_USER", "root");
define("ODBC_PASS", "");
define("ODBC_DRIVER", "mssql");

define("SPOOLDIR", "/var/spool/voipmonitor");

define("VPMANAGERHOST", "127.0.0.1");
/* define manager port for call monitoring */
define("VPMANAGERPORT", "5029");

# this is for rare cases when wav cannot be decoded 
#define("NORTPFIRSTLEG", true);

define("TIMEZONE", "Europe/Prague");
define("NATIONAL_PREFIX", "+420");
define("NATIONAL_PREFIX_2", "00420");
define("NATIONAL_PREFIX_3", NULL);
define("NATIONAL_NUMBER_LENGTH_MAX", 9);
define("DATE_FORMAT", "Y-m-d");
define("TIME_FORMAT", "G:i:s");

define("DEFAULT_CDR_INTERVAL", 0);

define("ENABLE_GROUPS_CDR", true);
define("ENABLE_FILTER_CDR_BY_IP_GROUPS", true);
define("ENABLE_GROUP_CDR_BY_IP_GROUPS", true);
define("ENABLE_SQL_IP_REVERSE_LOOKUP", false);
define("ENABLE_IP_REVERSE_LOOKUP", false);
define("ENABLE_DIG_REVERSE_RESOLVE", false);
define("ENABLE_SQL_CUSTOMER_PREFIX_LOOKUP", false);
define("ENABLE_TEST_SIP_USERS", false);
define("ENABLE_NETWORK", false);
define("USE_IP_TYPE_FOR_CDR_GROUP", "caller"); // caller || called || both

// if true, user is not checked against valid session when downloading WAV. Suitable for downloading WAV outside voipmonitor GUI. If you need to secure it, you can set WAV_API_KEY below.
define("DISABLE_WAV_SECURITY", false);

// if you set DISABLE_WAV_SECURITY and set WAV_API_KEY, you have to pass &key=puthereSomeKey to WAV /php/wav.php?id=226587&key=puthereSomeKey. If you do not set WAV_API_KEY you do not need to pass that key (but still have to set true to DISABLE_WAV_SECURITY
#define("WAV_API_KEY", "puthereSomeKey");

// disable showing domains in CDR
define("DISABLE_SHOW_DOMAIN", false);

// disable play in live view globally
define("DISABLE_LIVEPLAY", false);

// disable play in CDR globally
define("DISABLE_CDRPLAY", false);

// define configuration file used for uploading files
define("UPLOADPCAP_SNIFFERCONF", "/etc/voipmonitor.conf");

?>
