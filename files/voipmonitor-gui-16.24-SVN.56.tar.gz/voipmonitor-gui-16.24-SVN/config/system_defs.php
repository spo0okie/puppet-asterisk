<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPyvJZ0PSk7GfVkOP9SY0CZ1MxOifJ7UDhiSkbetk6mWNJDgQemleUreBmZCcyOblj2wQxlhJ
bH9ZPkoWwZsTh6JaY6AIQqcvIwsmRHN5l+N4Yu5IZg0376/melzvfaDQPDlsCTkwU7Y/nuFz34sc
UREpRubbopjgl6omc9vZ0Ba/ykPdZm57odSuifoEcl6QAKFS16GRsZCsLVjIwqiqJ/wWJTtqpMjT
r90QuBNRTmM3ry9aJikbWGzBUcEbcWmM0gklgwWndfcwoHxtuSVEYkEWQCk6oU5EWTiirvBG6BE4
TdDBPJIs2J72JWRrjuuC2Qn/UQ5d3pqIs9nbWBl1zkx2JgLIHuJUyUW+8vT+FcN4WSPY7Z8kGOGC
rsdSmAWt+44354Vv6KFTsrg7ar/OGCXpQWnyriF5o24lYgijSf64bIX2195giOs/4AVm3L88a146
pT+PMmS2rfCSlk4RsFr8s3ibMdDdmljHYscDikx9V5N3Yj+hQ0tRuTTOI4W3H/dL/9vwCQLe16ft
oZhhsUrt46Eay/riUJ1nHuHn15ArqTkfWqajPslvXWrbwVyfb6BnPPHButPgXYgZ3/4rTbov693Z
lnMakwGWzkLKH6qJXQi4wj9kltS54Ya+DTvZisgCfMTnZmP+1WFSR8EurmW1srqSHiNNFqGaNldD
MdiF+EWoMCNQCpAZyf+9wb5d/nSX3qE1Q4Bdlgjp2JQCcnrx0SqcvCFIRmkcht6l4jm8UQcGNJAB
X2ZR+aVMM60XdoDOk6rdjm01W/yJeOaRX0DL6cEug0A17pJmaClHZTA1woOuZONp9q0Nf8FB+vd8
KiwBGPg4vZj1RbH5HgOoO037xjYdK8Fy+Lc4V/BLS8hDNlSa7eK5avtNwFyb3XoICKDRMVjxJrWN
RXA68dw309sD/qI2azb80DaczLp6r6r5WdBkNvqA2cRAH5rmxxOr2mQbiYQusRLLg1iVIogf8CAf
rSMotxZIkzxe1nuf6yQG6KqxAFLbg3ywjFIzhUutbT+L2v+NFwaPruRzDPDKomi8jE8FkvqHmfoB
/4AoPJRKSy2fAg6zgyzdVkexOJPvJJrCzIpkton3zey3iGlDZyMOW7TTImkI6EZbbr0EB2d/J2Sx
Q4XDJk+z2J4q0kXo7IFC5H3we7VAcBsS5eUvlx9srbZBop7dzXH+6BAgmkOnfY0i02IzNVJkj6aC
dmk6m/YPuaGasOTyr8xYo3hbUNnOIxd3At3MHNfH4LyaJd1w491tut56Nj6lrWfrJLs4pKE+yGSK
d6PX+Mp5AKVg1uBy34EFS9auLFpX46lT+5f/kcPxSJ68J/kUbH0nmhaB/XTtB/ro35nRW0iWxttR
+gvw3gtJq9JLUNqn65C/7LucWoSb/D9/FG53dVXEJFDPElmDJHeQcLjcby/iGDkVQdY2s1DYkC6S
aQj1n7+nfInO0ikNjX450HB/fr4vdFemo2PgSqs5W4mO1rAV6Q6i7zuWGAPFAp9knO6r6Q5gTG==