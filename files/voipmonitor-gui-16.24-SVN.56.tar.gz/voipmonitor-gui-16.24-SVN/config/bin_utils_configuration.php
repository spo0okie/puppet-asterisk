<?PHP

define('TSHARK_VERSION', '2.3.0.3');
define('MERGECAP_VERSION', '2.3.0.3');
define('T38_DECODE_VERSION', '2');
define('PHANTOMJS_VERSION', '2.1.1');

?>
