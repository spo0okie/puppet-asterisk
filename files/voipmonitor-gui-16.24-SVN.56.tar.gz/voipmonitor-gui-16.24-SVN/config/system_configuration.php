<?PHP

// define('DISABLE_LIVE_SNIFFER', true);
// define('DISABLE_ISSUE_TRACKER', true);
// define('DISABLE_REGISTER', true);
// define('DISABLE_CDR_SHARE', true);

// define('WIKI_URL', 'http://voipmonitor.org');
// define('WIKI_URL', false);

// define('APP_WEB', 'http://voipmonitor.org');
// define('DOWNLOAD_WEB', 'http://download.voipmonitor.org');

// define('CALL_RECORDER', false);

define('UPGRADE_VERSIONS_URL', 'http://download.voipmonitor.org/senzor/list.txt');

?>
