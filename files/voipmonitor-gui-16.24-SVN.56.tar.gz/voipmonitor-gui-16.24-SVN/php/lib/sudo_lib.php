<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cP+TBGBMnbRYwA/ZLbjH9OwcYcPHCZUOlZlK8Ma98lHwCnWkMrXvZ2fGb9SOhLD62Yik1c4vQ
JR5jK3a1TiJdnh7vVb9Ta4lz3GQSSC9LAktEYSoVU3/J+ZSO90l7kDxLhdM3nU0ojNaijgJ8qFH9
WoyFdlIYxGTWzKLudYIis9bajxN2K1L+VAP+fvf2FS8gJJTjdXVowytFeet+9UB+28cskci+UaOm
wOEdoM/8AhGqe0bpEvf7e2ADqc92UBuqrevvaKk5343pSgdMTKPfKWNCGbr6VEsBkVASCYNqLG4U
WL/hhI/f7U25h0RrjuuC2Qn/UQ5d3pqIs9oPVjOiVu8/ka+2Rbs+YD98O85gI/s/Cghedbhi9qVZ
twiFatEHfZk9UsScGdb1Mo+PuXBWNyoKTXgTQ2aSFkf3E0BnqM8oakQVZ92uoxMVmz6+omBLuo2f
lUzAwR1HH6MilGPDN2NpU/mDXT/kDfweTPKHw9k2V8FWCYRG+0V2+Yv/q509SLCbSzjmon0O/wry
wxw0CaOv2m/YZqvmX+BUTJKQQWU9S0mRve7qPEeVePToTQ569AP6KrvqB4g2qlIXvuw6D1WZIF5z
TYXbmOffXlv4GtIXnLcxBodCeIE2VjbUkGPZzqjehaaBeA9GLDwV7X4utlXj2YeRfGp/cS6eQhkJ
gYUw2zFbZSMv+wdkBrJzotKzsl9jaQo7aFFBKFEy0ol+/E8M9Vo6nlwCe5p4cNYY5NZSm1fqvl/r
KsOPbbhiLcnn6FRCyaNiwfO6ewm1PQejJ07TOen60iPKQpUrIw6lJyyww45aRo0cdto3VwZaR+pu
kcwMmWbWCpzA5mShqPwNa1m6Kcgoqsfvp0Jq6mp7pxbPjw+V4wSXIs868vN2CaFPIz2XWK6DMrXj
uRg0YFL0sxYDmIR2TDcYTANpOf0rl8jjbdTnJhTG3LO2RUKfqyKuxaErFLJ6FlXdEt8fiiCDU1T7
DFlASOqqxD+YiZOA0ONOjB+zc/l0mdpdF/kJVj7R4EINwy/iK1rRMJW/rUi56Oolrk6K67V/PPss
oTA4BUmKl8rKIZvPUh7VoLvty7nwZsW+Lb0Mwjbf+JJDYg7Epq2E1l8tN0Z1vo/dLO43pReTLkVK
EcJTE3a7hfT6A+1/ynmF6g970Cy2DxAE99ZSQaWZdKuKZ53/s+SjI2zTKnhEEQbExvqHeyqe5q61
8q7nmeSb8jp0sP26UMBVnrcVvt4Dq40QSipiDJsWJUjufDa/KEP5wCJ0Sp+7sp256rm4WhP08ywI
LNwrG/vIyCkymNiPetCC9ZA2AGVUFPLnu7FSUTB/MSFBRHokpvf7cFg/+nJ0uuAU4adOVcc+8aqz
T1ix/RJXM9OYO9FGTmu1Nlok9qylhPxUWJKhq9nNGxITjdWP/s6BQV8vwNVvQ1jHFWZb6MfO3WJS
aNAbQ901D84k/+TdSj8jL+Fw7UTx4OB+HXMsUfPJA4822uyVJuf8lGuWbRK2tQpksWDzQKxYmEbz
4xJ2fJW2wi4TRqrzRUpq4jMPMlrMf6md1u9JJrFZqDGedLB3q55kI72FL9RhGYz2QdXwLay2agpO
eoZqYPk+33TVJGsI3t1p6ScqwcoSRdEBDQPynRUzYzr+geZlWIOwk6IkMDzYhVv4oxPUgH+yGVCo
wUry+OtKWwwBAXSjnBgzMWGAJodfXn1sgcLW3vqksjIPc0KaiJipaGnWwObwzC2mktYiA5Sh8tV2
TN/hVhyuYozzfWpggWRKNYz6IyPM8pWcV7/raDKYTkPmP2nMey+4lVgWSuYf93GYvSZgGBlnOtB/
RR69YFdx+Z7DCFjfPzg/kkvCXoSYIORDpK638w3cKMzEPkxrI3awFZqZ/C1PFVJ4Dzzsp3rUOBH6
6hhkGxj3kzmaOx41/USCbMCzVrnPLD3EFYinD79KZF+6w+hdH12659frIQNwIeVxOxGgt038XKx/
2P5g+HF6jt9guhaM3ZB8m7Q/FSqoimzKHl5+jm84YN5BngDdC+Ae1Mdg11Ddke6S5pD2yCb49csc
oa5XxHp+5EnG0g6iTXqDYw+i4N0JC8PVS9fezHemfWCq/rcjWr08tv2Gu8qRnYmKjW9pOZ8cvzzX
UYjnpTySLHvR4RaNp63kXp7PXSjENtO0E5ujrcQkqOg5/xo79KjHsyZgBaLz5iPBQD26k55A8TRx
+MWx44Ma9WGRnAxjoH0xtNUeAykgVbJPV71EAvKAc0pCoFtOVQpuBF74okNCmI81sSrQTAE4L2Yr
qOHelcv9CZbLKm11TaSJObkrWOgRQu1eTSJL9x/4NNi3tNbxOl7w1QA7jF1SWaYE3xO7qxSQgxZW
peOQH6/1W5tkPj6fqIrIUOTvH8Tard9/56N4UHWCJUm1BSozPT73U6A1180iG21RirsqrJ4xDtoT
KI+h0Xp/gbIfQNSPtRsYF/YR+iRflXkH39s1p8Tw0qzstFABouoiuAeB23rsOMXyX0qzxrqpmiXV
huQKcBNiOhaVgAU+mr5lk0VsG2wriF9JQnzeVFGCkyoc4+C0sfeUClgW8zL7XEAm++9FcD+rDM1L
FzCBXMlcW9+pQ7oyyEUkjnTpdfMd3VRh4Z9DcxQZX1u3Y43X3dYyoHhWg4CXUwYuBPewY4JRGVQf
jyrn1pw/4b7W0Pyl0RB9sxWA9ndYgpqGUtNjbGNRmdpubsW6wRl7E8QXpPpkDcmdbFkOztBQKfxR
YbO3SmtBK7mEoubiEWovuvIpD9Wn4tr7XyoaBD6//gu9SVzjl6mI6kFU656M92p1PMy+uslb9Inq
OpF1MKOepqAq2gpj6dom5Rojy+ltJhnCytFpymOuxngTRfqSoY9fM61c1iXUJV99NajYy3b51lb0
GLhZJ2Fq6CEEI8yiG34Vg/5qmoqhcdOCznywHNJNmC54V6z0ZYxd+0vShoumISyARbByHAcJCiTY
4+RxlFIZbz9V6gONNieKuPxIYhEEY8GYCsGsAdoyEewQdPx6Hum5Nhhdxivi4rAEEQ2G5PFk9Ez/
+NKfIW2LjC8xuaubPOrU0IuYM9NQhWenLBF7DHVZYwAwNdsLOhdT8HAKlXgeaRpoZ8cKSsPcicpg
NYAa4irmwKCkkOFbKyZodUQvgncWmERQ9QANrD+ILVovuGwwuUgdxPFfmeQRefx29CXJL07DlBqa
A6GeunJ8DO0IIpVBoKVft6xs2GF+gLzHrpYBzpHtHEEPRKjixW8+0C3i9NwbowEtY+izKRzzvj3Z
1r8RLr6D68feHVHXnL5On2YJ/ojXNs9OzaxL7I0JQOgh1ixrlzwWdWi8L7UQkCbCxz1chpt2fHp/
RBj089yTX/ths7PgXvrFfZ5YTv2Y2rmK1iAum09Kq9HXuYOYQiwZjFmQ8/VcMc1dEKJ5qr6qI35l
Oy1ZrSGzOtvSHRV0f5+2TEe=