<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPsAHglZ/jaal/nnULJ/RNTW79/iT6d2txxhV+pMI0nYE9tOCKVLhqsAkWKmFBEJeAuFWZEW8
qyu9vma8Cde6viqCmwMc/bUOCcw6B5gBIiBZUgnCr0y4UlVuy7MYLgrvRk5A7/qRz5rwoTaE+XR5
anlGfyWLR+MgPgudCfdb8bHNXj3okqJ8jsLmzrscML9jy9mfN+Iau9VA6ClOHqnjG0IBOs9vM6LQ
FJGLwd6Fyk2wZcaZOEj7v9LMYk4amUJIaZSXZi/FBkj+eToeszoSiBot2NHmy15QbC5JjwCwv/Ug
O4vjSOlK7J4a1lMtZWm9h7zveMSFFHBOd42028qvOaNg42peuDwncpzHgkdrly/mv/n8TnSR5ZiN
q5DF/25m+Nhr/4WiFm4byjOoMB74E5HXbnHEB0RrsoExeRyvNnAN9dCmkdnqJ2X2j4iAGkuD+unI
9NOjurKpdz9CcHLGEHhza5f5OdZHQa3niSMv7ZO4/vuqVJFfPF2ygk6ebYURN9TVQRtd80R7NJ58
/Ir4Jsyh3+1O6pTztRI0GnnyGK8bJzES5N1v6VVNGjgKICz9ojIO8REnaR4pL5fleeKDXPm5LBRX
hrPdWgxxZZy5zzgcxosdN6TVISYGLwGnQE/LOmLFXmwLFKeD2h/m/aHiFZCrZuBi6oHkMJXtw3L2
DELmcJBnjtKq4Y52WzPqg43/lFXB/7XD/AkuoJwdI7ZuwoFbNGxS0sTa+SHwsK1sAvxfVbO0LK0r
XVzRQ4WVrMLpKqydHzI/IVvmVjd38w+gGSjZEj2fdym2901NPVrfQUL11ieSANPdaLY5Rxypxo6v
cq2byWXOD4dBhDHNNr15oXIUy5pM1+dxtdVc9L44TijtO2oqcP1IORM3a9ObENpy+OFDFRTfEYyC
+tWSzwJATNgnp63mHgQRezPDXT7mNvRfjcc0Ala/ajReQDn4un7GfCfDw845uLdQE79+yVnJ9o/v
ffKx4SkBo8A2x8zJiznlbAwXShNG0u00KIZ9E+KoxwH1sxz+9gWQUZFsrlPuKJ+Z+RlD3vvjZQRe
Hzdua3jksUacBxv8vCgrPq31C1QnJX5uNFhvlaRXTkhQTq/0efVtHez3uarFugzsJUJtxvIHZ7Q/
YQjeD/acuoV8qCFtIRu6NUSQR1uYjAQTc7bSL2hJ/ScvIpIPyKaSHfMMHuf4G2EUX2l+wqPRMI1l
Cjs9Olp+tNsnKNwaUQc/v46/5vGWtis/npPcTdVIPt9JWAfpox3UbOoiJQYvFna0b9CxtorCtECx
riNP4yAk7+rMqVQWNZlvbs0zqYiRSW+LTLz9Gw77DW3gNvvKiRdtaBRXBlWGzgCAvqoHJUsXRSYA
2z6zYq9DQZ5bepUTqwGk7+YTEpu6/oy3yGVajt/jcaHdRxaM14rvj9QlaQURoGoG0vgHHVwXRZbS
gj7MdsK7cJQfxysW3wKzhjH+S1e3+WvfXlwTTRULUPTUIYBu4jNxGCDfSV7shqZRuce1U58crv6h
5RPDFmFy11kzX0jRFNJR2cPjGmOhXfEpDFDKqnjq1idcJjp8JRw0MvMVjAAaLe3tm3XK7Nc4f/UC
JKHdFUukUco9xjnDk+FFJ47T+zglViEeQq8MjzJqVUz+6CUrW9sdH0EC3/KinjePFgtVv1m5AyYd
MT0JAYe8PNxZ9Jdt/YS4xBXmw+tCGamGrvVFawRpP0FYmkxTBxBwZpVuFltex9qp0p7/gtTNGgSi
Sndwf6QlTBR3ZtZOtOuDAicZcSgYbhepornqu7Wf/2OzUYOQkl1bsgT795CuByVyz0Rt9jzuvmEp
AW59NQFB8xbJBpwyO8hX8dioeMHt37qzEiCKi17WTqga2rkFE31vtJNMJhNTaOlFwAbZiJ1hj4we
YYqkmWtLUzfC/BwBULEV3pbvuHhskh3qYe3SHbj6XCtLXZAtDiZ6DmZX1/Stkc6ZzXjLb8rlnzlq
Pt+BtgQK36poPFmeOm9qum0RTLw/6rMzEtD0A7gIKIVTWqafVmr6/c/5yPC2ZbqNs8amOdGA6yAa
CnTLQN7y0egKHcLUWdCF0vU0+xpf6XmiqtOeDIguLypEqg81PC3zW4X0l/j/VhSLHDhcccTJujs5
x1E4X9TzAhl0Pcf5TxAWcylOETi4C+Q6S5md7aXGm/kdFKDhOw2e1cbt21dGaGMDmglcwaPuh+PT
9ob4H+r1wLOPBwkHtKUbGUFYZnyv2x36gvS0VGpc6lfRDqnVLgxuvp+Ebz8MGKF6tJkPZsbTf2IL
g3ED/GaC9KBjC5nV/Rf5PCCmsSFoT88m+ufLO3tN/a252bAv1iTMQ+8PsmsIABH2HgJvr9Ju09Xj
DPJwVHlWa0xEx1rL7queYUlxO3LKjYZQcQh/1o28R8PFCUZEBwqcKdJp8jSpoknvVOBOGvGLOmNd
K0ujZEbWCk38hg17SOTJud0QsO7kNe01CVgd0VHukzj89osOsTBpVw/EG0ljGNiQ9hQEfqKuZJcV
XmLH59lKePLjVc221dt1Skky4NtvureeJqqbqOkX412ShgQkT+gnlfMTDfjVSSoSrIiwfsA0IWBw
k3G6QxQKp/sHnV2HGUAToP/y33dMikcPibCFK1IY+t6iHGROuGA07u5XDDJI2wGWhLmLNP2L73YY
TlY37dWBp1PGa1gzgQRXRTH+iN3siyHZSujN/XTymq7zZDnCHB88lu5ZmHOlMg4jEzLmkp1xTKwN
9VtR5wgPQFG2pRQk9lqFCxyXHDf2vI6/qCKPrMt/017npyOXRPn7dAnAujEDEE8+4ObdgIaAq+J0
1w0rRS6/JketpsPh+2M0e7t9JwvdzfQrzAjcXqlEK/ZHjhNRpNDz5NtG2Fwytb+4AQkMjY+I+Gjx
X1UzuRhzl8F07OJzZkiwt4DocKv68lf/82vmPhvj3AeZ3qTG5QuchUOO1gdGAchmo928ia3HoUoy
ujjN+ykZNjhirvBb9BOi7Il5xhpqVq6rczw7RvQxLPfLylDEdUkXW259kKtab/sNzGUwIcCnVmDZ
wgDH/pHFG61zJtlPKkjODVs2NCJUytmey64gEQczeUZ6/ve9U7ypIeuNsVAGXO5YQ2moKIwB+KrU
QGRjEyOFGfk9JXENCk9aNxcYkAiFmNEgtx7XGhRL693xOdOYKAnoflg5Ebvc0alKsXksNXD8ZsOq
vpEsL//AGx5BDVnddty8mNNXrlxkxa/5zULItWunhbQ5Q255vL1ZYNC6K6lo5nJYu6bnzMrD0NgX
nDQqQfwlaKIzqFt2oH83yW/vfgtBYiL6X6DvpWcSLDQZ3jutEGZzxT7I/Ss5ihk2lPE754vGyOLb
tAKllmV7AWDqgeJG7FvojyHB1CCRak3DDTzdIHzbf82ygdum0sm4Erkc87Gs2sPzlj27Zgeiv3hy
rkdQe8m7RVGbVF8lXki7PZsKl2uHWnXweLE8oSMaKccCmUNV3Ly8+f/p0Vy6fi+Bqf3ERiAsmJxn
+d7Gat8ieXQedd1qz3THdJXX3aboScUPuOGX8uV0M0KH1Hh7TJ6nhzgAGXe5/oR/UlVV8FsvoO9a
agCiUvcWpSrRQ5WuwPSGjveuaNZW6vl1T3ffdZXz16AK9fiJoIF/8v/5dHCUSXK4dqSKPY5joHfe
SsNoDHHC1u6mweMQM9/+CkebJTJr6TT8l15hINWIR8peHItlu3tqkHvv+k4ET6N5NrQYoY+0Ikye
81/rNbg4O5ExkLxNLTohmvs0ExJO9YiYshNamtZZ9V9QyFChWaihAXMfB8mKrgOgVErV6cRlxp8S
vUrWVGk8CG04Ib63K5F/nOabKg4gLaKNL/Fgt095uYNd5quoeRGYQ1KrZ/4IuBBiub4msOsijtDo
0GETZz0v7cZ71L8Ysb1EawV9WioMmjfZ+n9cG5JA3ogWLUR6XmEEAA6ufuAbPFNBQNxYWDou/JJE
5s1HMkCqkWFI+Lr0FOIR4AH6N5Dr6Tfyt46gxmTxLGMhiz7siYpk1FLlQWgYCqe6hVRZN1L8kvUc
NnfcZwYTcU9UZP/wAVoQ80uv7dQnPFxWVrREGLc8+TQ0cNN8sO/lC63+bcU3mvkkgDbZ0CEuIU1I
iSl1Ap75pOVaUWlBZHbL8OTOk7f72zFGaAiAhJ8NyCTp2gUBe8bE6ktdIX9V6Bu7Ia8dRx5oNNKc
P1sMR8kARnTltCRY5RfsJlN5EP14VbTrU4EWYNxPICjMvn5FLMXHBXk6YuQKUmAnxJiF3vI2i2Ru
RxubZVVQLsuNZQ/AavDFgzWeMUhlHkyPNMhmu8j9MWx7p6mEcNcIN8EOcabc1C17wr7N6e9FOEc8
QD8Io2GAbzqTSqREDFjAo3DuQ788Bn0fhcwqSjdu9YoZpgb4IGCW8ceSJFPy3m1cuD3czUuVYO3g
rjRycyRN6XD0WYkrdHlnrBkSzJqVVxEu4mIpskQ61XthNJMAK7kn7RzPyPzIJsiCQrNOLBq0cIW1
WgwkKQemrFdePi6TwdO8MeLW7l74H59U/xfCPHuFfyx7V1nMZRF6aKhVxEVDl+/qDakG9sh09n/Z
JNkWYba5n4UCNpWgnJ3YXcRRVOvUboQFfSkJ5x0uHej23OUtCBPublFYiBaeHWWFU6HVGioM4spI
jLDV5S3URCLB+SH9LwzZbJX3iLRiKWsQpKsDxiX+d3DdD+u1Onnrlrc8Wq98+x5+TNrLVSRpVDN+
SB1MLlpKJ8dDUNfwrd3ipvhO8FP2TTYAYfX9wbK2q7tzxykMkvw/A9pMCHsPvOUeFGjFqjepVVMa
mVRzBKvvkettOrlPmL7ZOmUD+XHr4oJ9SVdNorf+J52sguKrQ67k+vh2WNc2WfOF13q+MIspCn7H
EAT61MFeZ1y43//YZtm2Qq8jKm53FNV72fzKp9rTTD5NsNXKIya7pngioxrBHHLpewjjnlSRaVEV
aSICLVuqIUxSTBr+jLeit98iU4OPzpVex3+B/ROSrZkUJLXp7Hwj/qAvvMxXWuYMDnGANyY6aYOa
9kzk6zXddnPOK6I5KWeusbqQbSsMg3gDv2+rReDP4fqVoGK3QCkA0OiYvGEo42mNtWhR7/8i3krm
gKIHuAwDCZbBx1EcXMXHXr8q7d0pg7/WvjC1eOaMfGJDSbxwLb7La8P3SEeoxyY66dB5nUei0wLL
9tyzEVUheWHByA3fjxf8mt8MsXjG1A2OoYEzIV/CrF0exXeHNmqXZKGEnk3jNuWj3r0EAvPr2C7g
QRevg9qDg+EKIAWKgWERcUowIz+6QwFr4i7gSi5uk7Gt3vWpYxWAofuLMOzZHV57Bmjk7xWJwM5g
qJGsdulMfedLZg+wnGvdKl/SiklP1aw/pEBw5gBOzjYJk15aV1cdfAs3B0zJyz/urCBTkyeHygl5
4ofRRpMcVuOxDMkIcM4B44usJLyn4WVGrjGejG7ylFN61WJnig30pFJQwvAUUQnx9nfQsyx//mFw
mUUywjARV2eW35UDjlYT0wYX04rDjD2a82w1V3SwXz6NPQ8n/pAnfc+7wL4lkDNsgQMi9JV1ZT48
MUdbs7HZ/Me07zlYw8JZqHX/qkfcmo0+2z4peaAU/NplAFNAYSOc4iJmgpSikBqhRKBr4oW7BjkM
MXJWRixHP9Bxls18VSVgI6L9eQI16aWelTrGgIC3pslkY2SJGHL7EdxhiDp9rsIgqQfBTz3Cj8u8
B4tIPZROMu4UtXyUaZu5oJB62fXzUFmp74n4wUf8paxvt8YgxXBPNi/6qd0fayrfOzCvrLFtowBR
we6xBEjL1aWamFBAQk/qcgB/1gzZoZBhWY50OWfMLJXXBqm7khbF+gHNf9wxpwAv8YwEYyREkPTB
m0nSdCnNH3AiURORRQOAu3hE+Euqov5b505iBBDi4WWROW8E6FqFVNINQljd5lzydKI2TNglOUjq
FYLUO6Mnz8rDevxWS50xmgkc7ZawE+6FJ9JwbXfw7zGMRIyUzp0k7mWCoDf3LBmSHEO1Wi8h+XCn
2gdiSo8mW6A6Yoq5eUHi4Ik+alGzWJb0f/DK7XE8fIPZ9NBZhoOz0rqeY+qKdCxmUWh1b1GZZxuN
6mCnWsVOaVjb1+cbT33/9GGEBkGTX3xCtedbBXCRvUl6O7xwkswSkeYugwfDksgN6aiea/4XqN2F
a9eI6q3a2dXSJ3sXFO+wRFbzI4o/HMabh/jO5hsg6zSb2DnMHsQM3CqI0fjr+nBR7BN9Y2vifbpq
eEsEBgsUlm3aQoyR9R7nd7p6UMDC0mBKApMb5xO4OqU8V38I5wVwlVKisq9IL6rPwONsc71NkANo
hXd+RHHrx74Zxxdv8dzh755bu2/tFmhTLMOZ/fZ5xtR7Zj0e4KpiOGtucI7QFxOPtSm6OWM2eV27
LjYyEdcOSuySKDiu3FPu6Q+VHvDpD8tEMj2o+nDsj/E5BQtR3tLB+rJmOPQhEWacWFT+E/eXGU4T
dU8zYSEojhEbsF8nVAak6HG+Mfo5+qfDDbORKS60CFD+4APqPeC4GYChNtIAE86dK399EEZENeVy
AvIwoXU9CKpYeQDFoaE/4PZwrevMS43/GOIlvNbH2EGRmCa3vXBDLNyTg2naDiHkyPSCXje1Zk0X
WZFpn9D+7Nv+dMe2RaYnaL1RUrAsA90KxSOKhmyuMxeC5UNEbkh7rSUpeOGSC263aSHh2JqmO7Kr
vM8v9UHKo3LqumFETd3bWYLZmIAvZnkGFWyk89C/aoszprnpGNuipz/fVYciYaS3I8lbIkzApO+/
+XL34m9O9LlGAXvB3trOAB2dPWpI