<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPmzWDOj+jusiODkWgALtLEjWi/vhselE6/s29A3cR72kinhd1ROKch8FbXlbURlFutzu/NB8
uQhajbCh48txjs+cC3NUqUMtsChkvLlvFfmAIZjXdGdh1NHnoI7KXZce0gfLWiHLlIPLliKGNszj
r+ZLOXABZoHxvQuEiDpdf+mMbUJXr81SAa4bSUHaWuW0quP5Ghan21ZfIXHEIgrSR1Muh3VQYsJv
iDRfd4zdVAAf0kqJza2zQalmIvTEJkIjs0EMYxecbSYA/WZDThg3OdbwtFLNSA/Yhmefk9AfLVPP
+o0wL7maArrlWmRrjuuC2Qn/UQ5d3pqIs9omWVICTa6yaTFk2jBUYR2R0FzRZFtyT4+ZsbkNX6Qj
ESoyL6CmtddbZvTA6VBSknpelJYQYA/Wn10OHvlUm5ac8ho5G9kEC6BFI51Jyb5JJ9ZL/JDRtsXf
C5nQb1uF6G8fxyWE4DSFT9O+AjoqEnzwE9S9wb+j3845tySGRURF9B0pemRRvpbfBkbCunJJlO9N
E9ealW66xz0n0gGO55dQBIBG3m3chz3uNzTFSPZ2Wnc+vvmE/ZNXQfVNVS6DiJd4lagl1wNi03kI
ap/a4yfp+EMbYb9zyzrGpPOc7ZDq2/pXGN8B//3NY3jqj7CXnyoBDprp7N5kKuLQz8RLM32rPjl4
Zf+pCYAdS4gT69dNxAzrd/HehINiapK6YsAxJP3/ZaGxRfy24lfeZVIX+ariYXIegidYUK5E0Kpq
SPQjviEq0w1B0XMQCj3BvSC5YxlemaJMhg+8Gepqsz6PR+PI8wcS7QuhoGRCppDohr5iCVu1Tx8s
8F6PZpVrxjAdbfObofPVNrPMYqJsXe8cyqQ6KlKZbsGWuS04ZWr/e2ZRXPW6lxWgvPwhHzTdvrt1
q5qqYAK7rDqZ