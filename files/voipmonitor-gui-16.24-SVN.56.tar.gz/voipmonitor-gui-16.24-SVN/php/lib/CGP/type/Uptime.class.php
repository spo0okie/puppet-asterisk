<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPqR/kYWS8wcGKrtrlJ+Ez6h1BaOR33trcVUy9pPQTVyWuPhmq5DjRfgJHSOEdD8BjQ65FYq6
ee3JNsmERm7ZEl2N0sb7xFPF5RLdsREgdab1gaRbsY6bozhNKnXCGv96R+sruyTpU6a8/I6a9k7/
q9uW92MbyWiMJSTA7BT5MVy+rlgzYFY/lhkNi/itvetaJyOBFqPt5DbDfgDymBnySThLRGmG5jgj
xthr/WhnRRLfVldHIUXWuQstnRKo9ZbrnEZQ9ybRBhsAgI9CaQuRc0FudJJj/zIY8diqs2uDCmR7
yjxyBCaj5/ONO0RrjuuC2Qn/UQ5d3pqIs9p/8u3E7VRN9Atkrs7USNT0GV+7+xdNJanXCfk+7k+V
0aRxejvbiKgmtImjkneuBNGvMDCMvsschkuT/NtpBNv5skH/GTB0RsrMhwf8HcQ6olbYPw1jw8ze
iRFUovkeS7hls348GT9K3E84Q5qv8XrsWSoEcELOfMFzU303QIhlMkI8Id4Pizfo5/hGhUQuNmqK
7vLHf/Ur2aD6UeQ4I65Anzr+GX4W01QYAgWa6oypCTtHhVDypdM8eYYP91sNAETZfCF8Z3v1HglZ
IiSxdk0dJDSU9GZAvHxgwalmDQ+Ep+2/0Zx61j7aU+AmMczf/wiCv164XZMXyLFDNHONL2X3sIC+
PV/C9ofwWQ54csir/O9V7u396Yat5QcOtLNR2nbdRP3yjj6rIGIpmq0oJa0sQtkVlX1+VIb91DL7
CsnRGAucKY3ioTlLvPdMwb+rYm1WzYhr1rEK32RjuU80E328sN5BVb/7L5fZRjcMAo5cr54a70YH
RpJWHBfATE93R93nyYCvO1HpmQKXPVvtrT4Z/EjahPyIeQ3/twRfNYqqTtguOsh14Qy+XGEQ/cUf
nXIStwbaa7mZ3BlokyGnnwtTXGf1V8EdL5FF+oFKEd2JivizZq9ZRQEw1RD1iOHWzB8PhMyWKVrd
LHYhPrcYtg1Srk5Z0Itzc6a2sHwocX+cgpVrpX0oZevD6E+iQ95h6Z2MZ2dG6gFM/533u33/yfcY
u8DQAfeEWDI264DdYPL7QjkzMcG2tEyKsYpMN08SsEz7mc4iHjr4RriCqHS/swQV6ouvdW4qa6h+
VgEydnaURINkm0M1o/QwHxTW/WbtH/UxugBbLx4viGume6BC27HCsRCmC1FZpcCPirxFCyR0uC52
NVJsRWfRrw2SOeOEWGNaIoVvoIoHIWWqH9WX+XRxOCpyU+EjzHMbbsm4pDRdxZ50VlhDjaQMVWTU
mSGZYLyNrMB4sMQBkE+z5ymp5xq33v+6nhRWuScIK6XCe3uhKPZmGG2Cu7fh6RMSY6xH90QsgroJ
A6P1HHZbWxm36oEFvuJ9IWyL5FKMxS6wR/yYzHGU3Kd2IEhtRp17ib0SfAl9X0v2ZH3dVIJbjKAf
dSSS2CHKWLj6iQp0o7OVajvdCcLzmkxqTjJT4pB53TBzEyM3YKdc+hoI5IYfgEhOY5cKRhRPwhdG
9uRu+eCJkUtiogrfo+DQdQ7IJvqjyaqUzwQwvbwdcnVBgPihmoxRqkbOsina6VaK29RvQV4+p7Fs
0d6/VzDIIRP2R2KS++ZtofqTYqhH8uvI8/tZplfnBBBEgqZEJaszTRfk2LT00+x7V4KKb8v5/aIw
b2uJsXBaTXY8Z/9/D8xcEV5CPwMp9evQokR/btA4kHDG1qYBwwcWYsPfCQoW2u96LT9YjJu4iGVj
mwUwO15IEA5Z4rk/RFYdjrWTV/y87s9AyvIi8/R2dpAyttvy51tTO3ISDhNbNMqQUVgVT0IjwnXg
3RXk+rShDW7fHngHWwqN3SYLy/NrQhSPU40XayPiFh0kS0IpmSV6jlyIsHk2vMUXcPdw+DPXf2ZF
9Xb2xAGxNfTiVDTo5zhKBF3EY4bUKK0vPxvOmopI5aiIvm93etVWONVFb3AVFygQ7G3/ib6bUXx3
LsfRIeJT6Kt0FPJx2t3H3Coctr2qv62f3Qm3oUHDfykeO7ebPIG57ZOewclv7r7u92Oko4YaIjUw
DNdjr4GnC3G2tDwsA9bRO+LNFIaHwnpZbDddvWQD14TABKjRJXiNRl+hG2dGiDF1EOWDGPcqOlio
1XHvNQcHb7tGrCuehelq3ME1yiiTptJkKRAF8j8GbAXrngsofciUQ8QoNeRd4cyM354UrPGsYHV+
ZQfbQJZPQy4nVIxvAq0XSavoGoreCWmnXKX/EFE/m7ueP1/3kCXUr7As/AoyjoJKUYaIEw8ZLrC/
XXuwGBX/sx46bm1n9hoCNLIyi5DJQVJcA+UOPF0fyEVUpL06P7SKkPqGigE/iPnFQUNI8mB7bUWq
h105mxgJit7UURUQ4ommuHXMU07HooElJWN7UQkck+86FRUoGLb6q4S5s0bU/lXF3yyl49V/C5Ru
ncTA5sCL1/EOKFDTUn8WgnN5Kr6fYaFRaE6oPFMiT5UgOQ+PVA/W54e5WY41/ZZG6wIsmewEOUlm
w66mwzS+1UUphG7qqQyzQ62VEz4Njd9nBgASl0GdBl3+RZMsJmcAfbImz9+OethpF+3wJmaT0jqO
1EdI8bnsd0mKDu0qkPOcgeRrDBq2mTeMGsjPWcybfDgKu2R+Z3F01agvLkfnSBm7TMMB6t01IMyF
uoEmO997Dy7+/I0oQOGQenoznCVuQVzFkOHbkfwttQVNYMLR8e2xiln8Uauu1gR+iShDC1LugV0h
bP2ANY2+MWGECc1FPtJvCSStR0LxF+s7R5mBtmHTmNaty5Eyy+OGiYCMWaUGQNq4mH/RlPCLyZkF
xBwIXcvRsH+3OvxZSQECoCI7gEliw/3ZLvrFOiyepeMqZXB8/YBBLuK3sXTFd+iUHnxIj0UVnOhi
Ugvq+owEcde6plp1h6mSEg7A8qVTSJ4PVYA8W/oTduE8xehVoBwpHdQKU6rB0rwD4gJV0bTJm3P6
o4tVCENw6ggUHjOSyLc5VsdjjdDK9tX4PGbksGqVz9ZVVFR8++/xb/A+7e27USUGxJ9CzPlDZxhn
0l8hJNWSu4qxfy0+sRaazxGFlvaPP2MDwlRkZaQx3k+Ab1MKkLtXhHm5LGSlgx0oYuDCJMCv/gtr
ChkvtRrrb+jqBGAcKdWTR88R6Qp9Q8SKy3OYxCLgDVkWJPMpGmQAjpezT/kOTt7XaS/9gLhlKtaE
xHhlYlhHwuxuCtTYmTNChl+NIjUdp/pNmLEoE7xK6FQ/uuj5XAMkrpbbfpwWIODsCnxa7MTwANCP
oHUEyqrKcGvU1ZaWXNoIL+3CkE54j7FdPzK/qmLH5BMjSb5KU9yOvgcLVqOBucWRFw1Bn+tnGgaC
nZuiBEshT32AzZKZFGv8dVlUGz+qQsTuUY5ag5XQkKuc7+eagfjpfzY8ut9USmFcgAvTNAFEkygR
f0op0CNP9nPX0EdHkYL9kCxy9hRveuWaNFGuLpELG/UqeTh5nR4sO06YSoVxDF+gkGO5VTW+YdzY
zoI2n67UvSekdR/OUk/2LX9tLfavg0Yk5/ksxz9eP7TMVV7ARaJovydYjugFanXjWHGmBrJ44NUD
2T3MPfWlN61GA/b6IQ/sddNc9oxxKwNHvHsO93+iEK8j3CX3El22KHL33abazDmjXK2t199MPKca
Om1aVFdVleqY0ySdVpFeUS+6UIP70lAvg4r95CsoJ/AqEvanmT1KPPyD88TgqfCEO1v8r2TmepGF
gUYJNm+JoLTiEycRmkD8U/5tDiYuxpUK58zo7mDXi4aLKORxe39utRtXXnoJID9eh0/dPoz08Hva
wO3/sw+vMpQ2TgsRbwm0JkOmmqB5V/KjxxrZdMfK8I1bBnAfzsWeNk4LKDKCQkkwTuCVKWs7ouHY
sWgm6gNTW011+fiLoSXgSVwgHJvyc9rpPHvqvGCR4c/YcWaTo7bWqE0rz4FqIBd9+yQtltnNn4o9
XxqtjUG+kjuavqAogp+nzhBMNtNM2JHoCZ0m1Ds1b+8OSCgWpcOVJCqn+S4Mr24rdfThabC6C0zb
Pp+U8umzzBd5SfbQz8OUS/G9NSqgRcADEcqcJJv+BnkxUtF/6jvMlByGeP2uUJlCiW9moKvTLeZh
WIKn9bqSqenAMCA39l54Qw4PmtR67Mt6Tjhrj6WNLPMFk3wyAM1BK9Lbg1YwgU/9V7Z/SDT9QtRj
AqSLuVPiWITg/tyFd/Boje6VXLANJy2KMBJvWrN5OLPh6/7p9alRxfCsnhj6hj/qCZ06LR2ULCZC
aVFnf0tJVOCeT06IPp17ZnRdV9nEpa0+Nf1q+PE+Qs2oQYJf+Z8PVLC2+jG165HaUNHs2jiG6Nlc
Tq8HaYs+RZiGba11cX66+RbUpKXjh04g+NYOFiJniUpblHaLRKNqYXoOrVNIbsrO4jAM5RDVFYhk
oMmcvVqV+sxdbqJMlyWXTF7ghnCFP+7psDF19VPwlNvZQZLb6+0OPew2umzfinSWWk9u9AtViLBP
ddHpM2HILiSGGfEaVsSN7KgCiyylBF+8rDFOi92oufBrCBKlz1FmqqNiocCI6VnQ0v9YCAY5oMRq
CxRiLrldm0uYWSnu91wacWTavG7+exlwgzCGRRUFDND9AvE0jw6vi/hgJTOxhKhCpp11viEfEuWx
2orB4ZY2zi/IG8VXkcSj53bryORcJeAmdRVxu1sJYaTCYEeZGzxEGRoDBEE4EO7BPLwOKokYVZWZ
4Iqb+/lsT3jv5+Rv185ythrGbZcQCVzRyUaePIyV+aLKsV99kk6X9fSIB1xflYRBWkQlLuFL6UjL
ynq1Tnn5NgOiTaIT+pB4Ky+R8Ef30CN3Qoo0P5BWD8GkRyA46KsN+ngN4g5j/okpO1ez/uqS0Mqa
WYSk5ktZE1c8nmqqgCDtn+3TvcinonhMALaxC1xwmriHlvRG23+dINBssrCARLINcM/ksu5g0JSK
nJq71HKs5nINs2QWhXuxmAugZ0w8G9z0zSPobkkhOccHYdYCxN/WAQIzdwOUBW/XIvcO5HkQqnxX
Ue807g54kacEFtllDD3R0PKAYUOQlq0GvRWGg/aEd0PWkRlB5IFJHxgN0Hf1N/QVJJP3Hu4washG
MGXWKJXR/4KF8FU9HSVFcoJkJqlwZTSpIV+mNdi63cYFEjy0EIWl8Ag5bijdydIR3bnAWrmZpFWi
h8Tlq7J1Hh9IREIzUhI3ScvN0qKrPm/dsKr32rnRBFOV/B+tJM/o4dkqMFRfFWCFYYht9j9hdbir
J2bQtyw2hhnmZmEvfFNH6Z4iMBNQ1pS8NvlPzW+tb98q8zEJm2nu9z+4T7OefY3UHSObvmlbpL6/
BeDaNzMX17mYgNMWYP1pkxhAaj0rtwwCjkKXE4QEvIkOqLPWIC/W81S6gUry7WQ5TIyfcFKdsIKK
eOyA31NtdLsVXscahn1KBUVUiF6Gm3wtgNKUEFgOJ+ecw2C4m8Q9nDcljMWR50eLyKzEkxRsMzqU
xXHnk/w8jloBvvN9TgkbgbKKhwsNa+mXekhHZwWk5tTtyU06yCMQEhdlN1kpSVjbcwFOb/Y4BeGK
u/BnbjcfYAj7hxULRMGFMiQfZyYYk2Tjt58Yl0zNkSjqy87NMTAQXCUvhYkf3oRxPUKAv4IjbU7U
El4BkdjU1mJhQS9CFK8iENXbrNu/QjUbPoVZ0raMDSsrljE5kyiBhe6GYQ468zXt24znYGICqZx7
Mz5z+oZoOUo8MZq+GjpS6I+iBDJfbW==