<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPt88xFiFtzJyiSDvs5SXDa/Yc/dEfp/WgDrBwjXKnZYGGnxiOr6Sa4F7anOlSFfHGMAJ+nvR
QHU58HIpbwCPmBezOBhAGbNh1tJjKAlYQBH7Md0EsIjNw1PZVZ39FcGYemmG/Y0Z+p/uDphPIebV
+AaPeOe6Ps7lMfrKir+uCHq0Zh7UqMUFepAQKzmue1ft4DOTpFM62guQRt3F1wfy5dU6lK15L4si
KqTCV5D1LcWCxsUZTBh4Mo3qaCUHTgvkFYSusabsL5WeEKKIZq7e+7m3AZ7yIhzxbqKG32HhwStR
egorDWKKGIDuOUq6zRUE30ciVtcXPmyz4jYSZdMMUkamrkzsZ1o2td5tG4t/8z+A0hM88bmhoZ06
YBkj9wJn2978fOsC8wB1H6kGSVMuEma2NaOauXgPD/5a6ZMU7IFutc1hx3Y5PtCFV+a3NfKdcvcp
iyP3DxMVGxLoDWIg+BOqR9gvxzDLKp8eM7nzDWI785OnOyzSPA0kzBQdaOkw1ZWAakoEGpdr3Nsq
dkgVweg1SOf+ydbocwwgDfYM6k0Lq8w08wDh1B31ZrTcBz8I/uB0tj0ATzE8+tOethBdCrqIZGNG
l3TLbXOKRolGPz25139wEvU/lR3DasP8/onUjrjlWC6sVvC/Q85VH+Jn66lMeq1x70dVZ/KmIxDZ
XL5ClKSAlDzLfNgSFvlj4ly7D05fAPC81DlXa0VbW6IyAJgEovUfHD+TJrUtOVL/VqNkrSGBVTXZ
33FKr661Z2Ps84DiSw2Nooej6gtytjNopkGM1QwpdVT9flfWj+MrKKNXtAQt/jW27lNnacG7nY/u
Rm+zffnduwk5LxeCRmuOOSdB3pUS3iiq1fwnw+/Omu589cMKVsEXGsnIxjZdSLCQnctnGKPf9+yN
+AjOEvupfgsZyLx7ka/phJEz5W1TaPoXEyNQsA/r/V7L0WDyx9XVI0Ws3WFo81SbMmjZN/LaGfnC
pVKsCzN6zxkv5faAQQcVQrnOc7bldrnoKpFzcg7hDQcbrHjenSNYS7bgJkKV/wASu9LUaqg0El2F
vU0nkXXdLYhjk2shQavlZyprpsP2MvxT2FhcUHYHfmjTpdlLI/6+A5c8dthrhKLsW0akTk7I6Oce
re6HRNQDjaREY3zFYY3+ZEX4ENOGkF9P5Z5vActGCHbv8ZBCyzAuOSIin1H3JROtrBoCrcU5tPB6
afJ1Ek12BxSBy/7AQ4X5kxvrCCM3S3NWGgXDWD/DOXavNO4C77egGib1hcq/8UJQqZ5jK71BLE6r
KBBz1GR/w7gs6wY632NdniiQrRQnbuda7/vEwTDYIjBWnQEy1Y0iRRetaa7tl3k+TtfA+OeelSnV
U1QbqvqGv+vRvmkPre7H5t18BMqOiXsh72uiJpZRA6MSl7wobxr/FdmDoZ3vdOqAuE6+vHc0hjZq
XQi+SFiZKIsjlGyp1/P0EmIyYt6qJAn54VTIllIeClgra3fkjhdVXD8VflQobXUOBzgWuy+eNkKi
RFBObJQ+FyVumrLwZSh/sEAi+fG7UJRh1zVSnf6HpO0H2gEv9ex5OvtTe+c6dYxQ3LeSN8+o1fl9
U5De+O+TcLSiSXQIzhRskmBPu7wUSQru34u6OmI5moJLGbbcomVCiSt3yU2Ola7jTEORxdk9fWHg
5v3q6ZFi/JxQPS4J6TTtMF4HhEYHmliKPGqzEaG134BEtrAeItHoNfFcCPD9NJgpPFyJQIdEb/Gs
y6YIEPY+0eO9wAcuIrViGi551hF2pETrf765Xb/2YYbVoGyxbmswjA8T9UQl25s9nnk2v6F9PChP
saMZQbfdrx/7uNJTsXxJH2+pTeVG5BYePwBqBbLtGBK1K+KURepsVc4tnSXz/sXw2pxhbcP3xLyN
cGmYk9VZK/ekewVv3c4B0oOeyf9hT4c4jzK9vslDkyV5dpDzLMefmGb+Y2gftLxAnIWHNSzxKNdQ
QJjPyuddAnGJybmvwdNJV6t59XEk0lF8hHql1QJwQ5+v9oLZM03UUQMNCR4ST/DwG08GutR2BSoS
/CKLHDBzrkU0BVm4PC71y521u5KKkhm0hS15QFJCqxbjLHz1kvyvME2AwRsB7VOeQu3zlaNYthuC
p+9G1MyWElJ3y5jvFsOkfrNWaayUKacpiPMsxY376A9kcUYNoDkeCzDQZqfwDpXG6MrUnWnRJ18M
56admp5OU6Zsl2tWEYSrWVdLvJ4xeK5JsKagTQyVdaxGawkkHjhe3s6WtxMS4oDoxQbWwpkF30dd
qZUNnXfW9i0ZPxCSgxUHpVc1KC0wmJZhQF74E94AuCude4ZYV9Gg1qHerTVMmzfRHb/rk+/qssd7
4dmQCWb/0KhLg2PTVaGdGZR2D/tR4wCHno0e5sqcbFia9xA0LtUsFaQIFwsGgd4jLHp/1Wt/CbL9
i5CmsB/h80bGnYrC/5JIwX7NpEoJAHI3VP9TvxwGxQsu/2alJxSEvkhrIeBFYIZhPHXeOHFoedqD
i/Q6QTEGAEyES2kFO5NjRZMAxxyEt88f8GoDk/Ay+2sm2100hBs/1cpseUJcNZGfWlt0pDcz4gEh
UFNjVqu67gK2qL3YkpfPuxPw8ZLrEpGsrIsGjsrh40g0/jPbS2toWE13cXYWkNSefF2ngQF55d26
catqZL/nvWcDH5Uo6XQAW+1PvC/NDctSBKApYoZCePqJIsB2trtz+KS+wNsXzP4Whbu+7qlewwXj
rTEFlEAs/tg7OkiwqbMDsxzbyZ2ePx+G1i2io7vbrE7tKQMpnW52rb5tfKQLvfytvgqLuRerKrx3
SbEHgiZSGSsjAC6mf+lcESZA4krmeiTsewZS2ksYGZatNqMY+kEWaln4tDaIhx7Vx9/HxXcaft+y
2K7SqB6rTyJmySMMdTZvK8MAMoXqaIAQG+Fgr4R+k+vI6r+w66AEjtXkP0tPac7/Z1rJYTjNdf8O
0O+/cjVpp9YpK0sTCp1v1J6EN5wbBa9ubtjmv/9EJVV3qYzuUibL3No7ZcU8Ezw60r0+3N1pnZyi
wfdqSuUkJEuuib69swtsxEDMB5Dyti2tHT5CQRyWZ85/Hbg1ocWVuou1xhkdWtbcQSmMvo4iweqq
Cy3xAQZKy4y9c2n4yT8DTjgj6a5eYoUE3ee3042EezaC0n+CIeS0Jwdnp7eh60GZxCynh9JKRSls
57/W6pUVugjD+qw02Xo0C3jnSNAf6ESj4x9Ljya0zeEJWj9lv/TDpSAYID7vQPQvBxO6stQeopau
nwr8QTfik6CQ2u71AoJV3fxJIeLsH+BKs/V6dYspcf1gIL7FK+M3Cawrzwnqe7anJdw2oyQYLdGJ
+YtBDl699LY5J+f5ybZr/ny0aIQn0CFMl6GuAtf21i24xdKEKYdA2Sc1ftn6FxxYJlxO8VU17RiF
ji9E1tGpY9/oFrYYav8iVK3hSfEQe9n8kwvYHbiAlcxhIV0WzYIZMKCX3UR8Tp6pDfTJtA+hz7ik
n31xv4mAzgToQu2gtOmhfiFS5zvoZ6eOHYriSP1R6YYgPilFXq4rQZ7wuYPu34MuivMH3q0B2QI6
07IAwbfig1Rf31ux5yQ8LZd/2fqxCQ2L8ICiAnhOHAvt7JfpD6SvBrdcjOZu87lekZNNmhBsqedr
umc/bShEBwYcW2t/1gcb+Poybih7+tsAVBt/rQ+zFnGjIQXGr+nPCObsxzMo9ZcNYME0rcXlxVVE
JZuYZIeKFi++L2llGhtWhrJlzWiHqZRZGRGIQ+vUNaa6V1uaREuIqeuAVXFoOmj0VJi6VmhdhrId
t4vtSgubVsMfUevhO5iK+rxscEAj1QyE3F8oHoJxA6+QqLtUgxPIA7P4LNJlQk09GEqOo+JkL1eN
o6U31jz+DlKG0yl6xB4kMykjprZQQDB6gYdwTS2vxho+yk7FcbBUM2s7gRvSOfwtfCJ439yDHvaw
o3kakmD6RerEwRBn9bxg+zijVh7r8mk5zkiFax2G8E7rUSoRHZGfdBlGy0AqYwkLgNNyZvkgDsSG
IU4lCXO+jc+dZGGpVNRZXWyTE0pf753bSVAPU4M+kBOch7OP2noL1JbLxcUDhLdeIneaOm6rCCtw
kbiJx+H1a1l3UMDx5NxFhvgpyxxAgQZInn69li1zvowHFXwjZi9RSX/Env+JG+68FQ4KHzLVvUQ0
BC0KEAAFAYEmB87YYMzMTEv7dvC8KN8ixe7VvttWLVUN7zAsyAxnvtJTg26cPm3XfI/7qW8rHn51
+zFWk3xBGxh/mBaGaEmY5SYWyMJpT7oTSP2/B0VkBN/n5Qq7jSMro9kPK3PLkdV6u79HDs03aa8D
aEiKMmTasLroUL/0rIcnWZvoW5F0SsD1Ir1o8n0ZJNXZ6K7lebvU7sEGDGrLOQCu2BXMvLTfZHFz
MjAWUzQKJd+g89Wh8nigUTB6zDyt5ms+OyAlh3UyNqLAlKRafVgwqd9JbkX7Oyspd4MFcMbm4Loi
eCemg1GraPIHbqYgRBzfd5VDjcwcHYDs0W5vP7/lAUerMLWZLYjbkB+TqQl/k96xfODvdcdGqILp
2QAcWEo4v1RVe6RWC4pvNOQ1Zx3iOdjNGHKhhi7XY1B/9QvEYt+mLBWf/iXCSxEvDjJ2BLX2W69Y
PjaEATV4x5p2OQQM8y75I3KtMhAyOEf/No581UlGktBwAs/h0KRVsdrY9+gPlLVHKdp6HDGzz+ck
QOyJ2XbQsCXvcrGce6on1WBWRbRx64S7C6S5RP/pmw4rnUGlNEaliU0AMmU21UH4lUnaOfTOAZ7R
wDvFCIpYdK3VA4rP5afrGjksZY1P8sDIqlR1R3W2NeBVN+EBf12m1/Hv6aupfVweOOid61KNggn6
stZqhrBCdJKDQBiRSfvj0NEI6ZJ5XxgkgvDgmG/7UIIGuBW+ty2X9DIVL5UYYq/AbfbeWEQE0tgd
MdZLSxVSZAKRvXh0c/Row9wnQKGTgyjG+fyiK0YuB4GYp6Aktrvnbd7BOo79Awrf/vh1RvUDyaqh
y7wbORUNdZUDBByatdbJO2ulWQGzB5pnz/imIhGdTT8Zl46yP3Li+cYP1ygZu1dTvS0Y3vT8MYER
O2k2aSi1jMC8dSm8HWU26BB3zQ3XvMh+yCk6EogBYV9t56HRzwzAWPvEkcMMqSVH8bQ1sQW8297J
WyvJphzHNC9KHUhApwdax65ru4gvfxb4VXW+HOWakTKnUNLa7J07cWk0tuG1e+DhoEcXuVkI8eDB
SDdpgQDPltfG3M9IjC5qO1JmfCZBYw8jGXfLEBWhHMx2UrdnXhHKqfwl7hazWM+hGWMbogFQjlKO
9+Uu7xieRuxdK1J4PyJylrYc8dpXW2FtI27BxK876MF+RF/AEjeJOUgeVqMShxwFSOHy8tvCOuk5
20YMIN/MZSekYoU7vFCG4Ga0sCIFgsQVGC2ShTgUNRg0IG1qx+1CvxvkLKj3B417xK8ZVlgjzWn1
53Z0UpDuwzgQc8PP4UqNMuIxViI0c4Gqbv2toG3CgqsLnjmiJGYGQef1m8jqtyDKGJ9R32xdTa/g
prtNKSTLXKO+if5IoYbaTnaVkYeYwoIS83q0fh6iLj3aHEW2DDJnMVZbrEvXLKKAk5a0YVgo8XDX
DWM4Wi3CdpjABdRkhHB0tIb1Y7EO/dqT8UdVwGRcUINxI0VWlYmGzU7qkJ3ARTMgvt7YhHl7Fxua
Lb6NfNrT1O7bkAYVOOBnPwE5ClbZUzv7iB64eNa/2HOzYeOCawtAxR4bxuiNSvHZls5Bh46oka49
ynWacIAE/o44drspHncvcOPMjAuksMwJGBS0b+RHviBIAEvSptVVijVhs7ymdYUTrMyd+g6TulUY
6hENEYEf5gG7+hS9lBAhAqjk996AaU0Y45UH3+mC2VKBNLP/HcmFyW6K/UTH8pictvgPMvt1+SHW
4MD+i0obyG3fVmZmLnjbmvs8Fqbk/jLQI3h0p9eKo1A6eJ6wki9gjadrY5v3E1KFnVnRSJhkSVrC
UfYEy0EYA9qE0tgTV5jKx6lAbLh6cBwNKFJ3KmHjJr6itC5+nGWg8/MKcP/xHz8A0u0gqD9L47hk
H+ApUxebpYuiGGMemGc0P9wEjge1eNxS+8H75cIDm1iB0tMolUdau1nFwdoriYIHnyz+jB/TAHWY
4j47sFvzal+eEgKOmzSmPmgyAAoud+tC