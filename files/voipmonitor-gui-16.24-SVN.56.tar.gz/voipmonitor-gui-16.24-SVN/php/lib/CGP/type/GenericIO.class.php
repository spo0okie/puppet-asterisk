<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPtbSkoJ92W0ByvWk1wKo12gX99X3X/qLf8lVokXvKp1T0XaMbZ//p4J8mndWpn/xuih9fiHP
ASUwHhhv2ezuwIT1TPixHEsuNMu9v27IKGPaizdo6KybeRuJntQNqPLtDokJN5BmqPCRQ1szpCTd
oHBdX5snkUWSuLaNmwMccGZahMHB5ho5U2X4Ahuwo1u/rfjUZE63cyikZ6XKoVmnR6ejCuz4uBY9
Cx1v+ye2akMFOIycWg3iPeDeuHkoO4UFYODw3j83AV/sJsNtb6e4BI9omsxsdlkA8I85IZW0pvjH
RSV3jLG0Gzeh1lMtZWm9h7zveMSFFHBOd1vuQoICct1eEPY4qjuHRZvfAqZyi1xsIDt9kpKFJuY1
5xCAe7yVJx1R+d8ZOlP7yRI9/p5p7g53Wz2K66g9T1U8+rqmVOpTTqk7ItzxaYCcPur+yPO/bf3V
Yu6UwmQzHhIO/gAs46Aiijdqg/z5PiLbaR9AvD2poHibTkia7v6/sRtEjcNVtIDrKQMKCPFNDY0L
cXlMgtdtCXstePho7mraAlPdoEVVHB+04ou87AFClBkwyjHmhk/tG5+E4WmnCAaIaJk7Rj1GrfUx
54fqWliUObN0znjgcVMzmQNqAEnrr1uxohaGT7UulQRQuEBXp3BvUi7XKxRzuS5fuiiC5W9bUoiK
/IHlnSQnHhagdaKjp6iO5t1XeI92ORytn5lDS0l8WDZo733VnSfxwKQcIWL5yEsSsnBkiD20bJtE
9zxoVEpE+XXfTSmarri2+Jeo0tAtuzqla1+6iexRWbmjSbbak72f7WXvjyeKFHfrUd3ItqbjnPwZ
SxcjIKt/mXIjlfLJxbNz8qJ9FjDNJFc+DmgdhmHy4sBuqrz1u06WMhtiKSvr0JIrJNM/pqi39ddz
2GldYnjF1lXSdSQVJt1TN4UsbZ9QqGRqDvO3/YKc7/NsY8qPT4dS7FfMf7bhgmvcD+UylZ4b04ji
H3GBzuo5qbBWp9IGmBD4I8cU5E/gjB56exI84SkygCGP4r4meaWRUUko4VtIDIqOEiby+buuH7f2
LaUDaih3RD+3aAhYbawT4LwQvAq8Ifj+y5AHZpdrab7wOcrYFdhYgebbkVU/MOKsN5463ba6IwV1
CETV9/jY2TtYXe8SDPYwNeKCRE4QSXkSf0LWV5NN8hKWiPsS9H/tZ1+63/clsbha6bXNqqUYFtSU
+MT6q5l4xOH26OJ43BTn6svsw/qjN+KB7dVbM1D+KkpCANMAlYbvM/G416jG14KJRl4XcYTQ/gLq
TauJOhwEi9hGIkOw1Tp22qI7f35m7GwGVuWdGgHfrSnHu/68JFEPMsEgvAsDACMhVNRaguBmPAJA
iLBMVGEVgD/bMWnk0Pg6rd2POeYEPNdBOAmKu79RK8rM9OW2QCrERIRVtAHUnsMuhrCYmXcPCYAB
w98dJRGOJ1rE/Stgosjs8VWlMjMa5mlcpNS4xbnGCK6iQs4hvyVVN6MvHe837ALW4QJqS6V8cmWM
GRQH7QCGLPamKNG2dJ2eClu8XYAI9Wr8LlMPXM963WJ4z0zJGJYmNcEGbRFiOx4DhbkMYDMB5I1D
e3DT+3/2S+Hwbhjx9NWENlnVxts6jPEEIBQW3+cBv7mZ6TNl/0f68Sbutc3S2k34IiQRSWP3AZSM
MNw8UNOOImQlCHqPzkXk0b7c5PkqJwFWmWhPNx+aEd8NT1UKbgCxUxsISCDV4guiwlD4XeEHr11B
14YNAupd6uR0L0BuH4Z/t1baLzboWUC13R89DOVG8iEtmktpuYvBEUm0Y5Ksd7zNLJEGhPX51CVV
muyo84HlpGSujZvRwWBw8ZOvcIp4WqqMCLfvgJ0UsFrYeq4lCtuE1/L6x56+cvJgzFaZlD2KpbjV
8COsnoaq74qz0vyeu/ESGmMjFoZwNSe2skkQMVvpxHpKIwoe0k2F0BWCN6CWeAvMfWnkpYTu1brg
egop0Cl406BEdTd6O3h90V7lqBKKW118AVCXx1WGUDMISwVET82BhApp84oUxGfNaT994ABtyGVo
0mtrpV2R1AoLxQATboBwrQ5FQfyjRpXfW0WbC4IV5r1BzfdJNGWcRLde1F/11ud6xBZl94pRxUNY
Iq2sPf/FXV64CX1riOfO2e8ohILZaollSriXPyMeW6XaTZAs0PMF4qXe0IR6ppTrEO3qqsg5BHWe
Yj29elhNkWXc6VSl1lxNLP9tnYTjUrMPZ/C09uLzSMEv7kWo9TnPFxeGUCoUqzFIf6csDou9blBQ
Hy0LtIiBIWWsB7PZsJ4gc7jkrDUZ21uxqPYlIeGE8B5M2f7ua8z0T72DXdkJqyzfUqNi9Fmn4yM5
xKui4sGujml34uKxjAaXUHNwYMBSxOEvKs64kk2l816JykcbOZB7tSWsd2rVdVK09T5ba1Ydy5X0
3Imm+eqi9pF6kRJZ7bSY/vWOECj3H/rlJBKNDZwqiK8oERA2Zy+ZeaXNBQ+KDewuoy9eHuRO0VdH
OYB1nUvNyGtHHcOYp06ky8WhxRc/mg3cDGtKstdgyMQ4WpUjPB5ZNL4QOc3hqFv4qF0KUHqaTubu
3o6GmT0RN99y//8PMpF0Aqq4uYpofBZhI8+dK/qBrTE33nY+LohH7dWKW05aYAlp90Csh7NCXyZ9
FPV+Disn5Vf3ZS9TcKeciQc7fKBvTCIm226PxO2wahkrnAPB3492aoz9gkVE2QqNc9K2jGN4ehgQ
9dsP9dWfRN2x9wA46tqRtIdmBMZ1R6yi2WnRNDJO7wxEcL7qxZuCkQqC3fIZNjlB4H9JiYBH9qPj
+QWlV9cQsPcOPSlfqq/KW01CX7JcfZaZof221W7IV0slXux/tO6wdPKoPbzGzlcE+4BQoe0QyYyi
Dpq/5K6mHMefzf/spMoPT++0e69A6aCKTH/ZV/YpHNeCr/O1qbphUsyQjXsYzbYrLfD95/CUwVcL
Zw1IkEIoXNqQw3cE2cpHosPkByzgMZ4Qmp7O3TgYE4WkGiws5Kgo3mltRDIHQ4j7JmAS852mWtoE
JMTJ/PHw5wEFL94rcjf5Lv5F0ENx9CwOfgLba+xBdFam87dq1CgUiY8YBiBghsoke/NxNZclAHi3
EVEjugb1m+9EhGo7NJvC0iudk17LYWSqnjmGJNjLaoEuVHSiUrMB69p6cx4gK/LOpXYBe1I0ue1i
HnY0GsfDtMpmkDAdOQCuIidgosiAwPyRg+AgNOtTChegd54BfHwmqVsYPvjxeXY1xUyRZqFzpmu2
tUMBf90A+jryi9H5KCBqokHNb5vcIf0wvSN5x6LD9+egrzp45z6PbTBnHk+o2FwTFs2cgqvTEXiI
EYBlqaGnd/BEfJIFstm30kaqUbNy7c9RxUO1YJ4TaypM0mGUHaOQwXEvbb2n1xRSZiVsULFqvS0D
zTbdwbCVaTX1ARuScHjyeIlVEpCzN0MS1ighLbDOwrBjq4yx4FgJtgEzvZtfjnk/Efz2D7srZquo
TE9NnrAJZ31H1HuxMrfvK/af+K6rH/Q8K5VDMGHCw2PjeMYn2+zmDF11uSZxM/Rh/QMRO27RMTYW
3bUx9UkFSNzJRG43ws7Vc2JzqflcTQrjzYtxEFsgIsXFzFhMPpUnVMGNKFc2DXSQtJjWLMnbJCB7
BsdmyBI/LfGwLnNipW1HzL0DjC12/BRp6E5f865PLiENg75hsBO1O9JFPxs0VsprasoNbOjdDqfO
hgmqjL5WQ1T2x50fTayWGqvGeIOd1v+dQwhRrCn4AcAEfOWczVpmord6hypDWJZkZ6U2IsKNlQNH
uIXtGjqz9t8EJZzKINVgD5iURP7yQWX/NRWdLoHa/opMAgdJWbPfuDxEwAr+vJr3M1F4QJt5HZ6A
n/wjW68bce6U0r0XoGhntsF6RGdJaI9e3OjcEP4YD8+Jnl3Gny59sqzcW9vx8XxeJOVEnxTwDKwc
QbjX3pH8tlqIT2aYUHQOJg7Eor/cj/lY+HSArlr/4zhgDmzOhTgWX1yigeIu7AGKUm2gU0AT2vIJ
JzdgPhGsLsQZkdB7GB0ADQ/XzJfsiMz9G4pVyN03tdWf6stezZl/AnRpyoQGp8jrczQchU7IJ3rC
/YLyBfTOpnYJzzasE2Tr7DycdU4Hba8hHqIRBMoIIMrTWtI8jXg9BrAMilSLPLqu+21mYGoxowI5
dmggeHUpcYfqtrIl2FB9MLqHkYr6UouSqa4tid62jpysQ0DQNQHrypqkuGOLS9wZKVDvQk9kZann
4jjqos+5XAF0RSUNO0UKGpshzPet6JJ1b3W00x1PpBLMywcZ/Fff026fwRWYdp4kXMhHTv1o30Ac
e6X/Sf+4wN3LoCk9LjJzixi/Zx41qtvzRjK4LCKKeNyk3cokUN55LVwhfhvy+XVoBq95pgc/tlAx
zkUAfprK+Dqq2X1Xi3yzfKlpQVBtcopMtMbSlWEzIldyBUniVY4eVXJMAgfdb0MlMr/73VsSpLtb
uM/yjlRjdztXga45cTXZufELh9yric5r9k9GGlcZZC18Dly6E+9XmwhVhemaJ+ohU5R7I36KCpUA
fXIv+Hx99u763iWqcFj+EpCALfq3sHaLo/ZE+lU8Fad0AEVfN49309pC/73jMEaJ4CVMxAjZ5SV6
iDB/ly3kXZ+N8DoKpcWsAJ2r/+XuUUBiFGSjOMKwRBtqQDS/9ymUNTeL6TXLCdwus7tlKRumiLIN
9kYTjFfG/lapqkgY4a3/6EAFJJzs5VlEUEQ5vRK+afphgSAN2By02NIF+rB6ERx/dvVXxzYDyTwO
5PP4X/ql6rI4QCUre2gwPejft2ZiXb4p7+OXbdopSwiBssw3Q1yg/sqNkHrbpz7yYfqq714DmqNN
MNnQbyXkz4Gt4qINr6qlnX3T2lwgwp/6xqfhqEcgIzPzYUpQuldzh0yHaIscW/JOBVdS9L8Mliqn
S52NnU58vTKsTCMzn05vQ+GkJ74E/xO5telDCP9/ATRJnf/L5VAsYinx4wSoPYeeqhXusTjOQDZP
m2KHRKunOi+gCMLiPC+thxhU+aBIR4HhTcmnvSUQhotU/p6716QLm4oGePA6H9Hj4ycNPInv8s3s
bwtzFp5hI1h8tMnbV/7hPJcUGNj1bJX57vdYzTahFouVKJMHSRJX/daF+Ku0A/CTjMwwfGmA+qkU
hatlkJ1KwUJkgy7DI/grWcIS8q3ukxMEfdKA54T6sjOinUjcsKq9PMhXMqyU4v1iZQqqkhmxckcU
zbJrR9P/PfmIYuFYkbeEfF0HLpEcz0K7b+Vy2mtEn2dDGgTk1gIdvqAL52UaLnbxNqTbvrP/XPnv
mmwq/ss/x4T+XYxbDdEvn2TRw5CjNYINWBcYWSLHytw719Wgd0NS+6gsAqNL/JEKQH0vDcyZ+Il5
vkhmvEvRv+Cmr+4SUWH8WZf8tAjIVh5f8Bnws5/jq3xegBMoQOgsUPQGtZxBiWMT4bbfqOXFNPsP
GR8P//lR9iyN7PIPLJf5uxOKhaXD3hGBT9ZWDE8BVybSS0RUbFomYFpK0jTHe1FPJIo1pqJTr8Aj
rsP/9uvraakwpbZAvRjqGtfDGzxnXwXgNFpOjlc9Qk23+vkoNNFvfwofRxFqEWHgcQ18mTtYS1i9
GjDJ7RQhkSZEttVEgxByjDZp0N5stlvCVhfdijA3rdo0QS/gzGjsB0eazyckbqZ5G7dFLymdNWH3
Ocmic5UKAZJ1dZiz6A/+QWQB/F1XMFaXv8CgR8J0Ju+p1zl5wmCJ/JGm67J4QKnmi/+8I1tOJWXD
rNCjnfqKHfWbTmaul5M5emYJ3C7A4uAZww04pZBwIlQXB7411JFpVeMigfFAqBKPyNpdNj4d69NH
h/9RCCnxXNL6r5fGYYtKZoUc0Ne5JXaLfP+Zh9ieYa9mKz75x2pA/pfsi5o34rLF/xhOdIZaujXO
0yx+dcSeQVFcMRA8v6yQoe6f+QofJchDGXNBcIXQd9qEuKX0YLRRMs1840HWT83Qu2UX1OJS2ohY
7fXooxzTD3BSdqEGKSO9La9+irnf8la7sZkcjUVjudOnc4T17gJOW6aoS0drfzGo7V819G6Beyje
oHhZUMRDBqUuFnD95OArNHqD5xSdXuwTc7XvHn1TPjI7MpPXHYDEFNgqutHfGCJxvpxKXBDXvrFe
X1aFDG+XyAubLb17CccibCwypCME0IpqbctlOfc8xFDLTI+vp6hw4V+9OqjoOMvXqjWe1t5TZJC3
Pl6kOKmzoaqYDlM0dmhCLad/sHoiG09PjyKhdMJD2m596t0L0xIqv1ZdujlTit8l4VMlwEQc7uXy
JaRneL/33Uq84Sf/xMR4Y3rvmnp9LaUCyNh1YdY1g8+uPKHrTc4/gXBGAingvhg/rpGmkGHNpfC3
j0yauIJnCTmWiMQcy6v3VXuYdtQzYN1/+XTjlc0ftBtC48nyrY8fmniPJfiFbBSMFqRSFdbqD5uv
YkcUMs6grGmJZmJOdl8r1Mbrf9I6Rvp73Kmi2Bh+FehpkHh75J50ap9XQ1oLxPr4JtYawVpfQfSz
NYwf/2FLXt/ClsRfuze+XqEYi20dyUWXnaAMmZbpg09HboC8kR5lWNliRiRplbyVhLu=