<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPstz2ZSgMeyuL4YV5ALZzlT6XP29fPEkNlcCzIpM0IjOO78w7gnKiopj9c3zz8/tFf6AYpUh
6C4wYE9qAcf2VmO/wisvqvzkJ25ApnjKY1nhONXTHxwIR2sDgGuWnQYxX4UV6whkO/oS9TTP0pXQ
Kl7khlj7As0qleRiDrxmalj2DoSxnMK1nhMIsyheHA4Qr8O/R6RIUygvirB65PxZLAPfOngm8aYL
KYZYnmCfesSL0OxfoYzYHDYQUjTtTjQnPkwxDwQGGHQhQJUeN4whHQ1q8cj3DQpMDm91aNJxrC17
ZVBVDQ7AOWe1u0RrjuuC2Qn/UQ5d3pqIs9mLURw2K1L6Ifr4UwVUqUq+GJRUXsk0GkcN3T4w+ZYB
gvuMGck9S6kV03CiWI2oUPAraiRxRoZFhLXllpfPExQd27Vz0KDqZkE1NHL4bDpD6YLTCumATElr
f2ZEmAvppCSjyxoKkzr79qHRHk55YbO3LFYceL7/7MMAvWE0xW6luM2GznfuMXILUdwPPaHbmbUL
Urc3dS/kLnc1FkaM+0O4Nnp1bH61QCi9vknI/84T1W99QhGScGgBNIWpgqA0Wki3HVtl5BkDaHTG
YdWQ28yMetCpNN6E5KNvivVnucxfzUMNrf7wDkl5xojOOkKZ9x4J8t0BYrB4aXpuktyWDuEhJdvt
JfWXXOK5+lBTSToyyYU+kQG3WovE+QG35r+i6om0iaE6D2C4rc1Ksse8rIUpcF7bZeqTuR1Mysrk
98itp8wiHXH7W8x9eTLCWPFqq+jBEe7YWvjeA12xepd1qhhNUFLTsrlYozkXiWQJ2jGjZXpP/vNT
H0gs06DS4W1j0V7lE/HxfmTtTlCMUM87nfsxffWad0SNZbig4NKPycbxyVKV6E/qW3XcPLCUDVW/
hcDfwrW59M5PgW88zZqM566lCxaImh94gXVhr+swLUUJtXjIYCf7Mcu7QCnIJl3Rs3zVlizlqNOw
HlbwnxgmA+Sqh6chA/9M2BI+OO2fl8cioV+nXD/uygANC34J941Grr+SQuxSOWKVXhwJ0YKfJfKv
qP62g7USAyNcxk7OXj092N6z3zs1jLdTm+ytOaD4ZkLMwL1XpDU5/Z25lzIE+CFxDL0aiJMZRc4+
B8KlW2a45SJe30qUpp5borIBG+94b6UFtxwlXxqU7pdaaJe32+ePjykAVLVImVDxLRMqSrK5s8EO
8CB4uo9HBajFUEXO+momQagiGQ+YhwynNFipaD0CCs4tlfth5CBbpvOAvUtE2q4dTxY3/Z1fciJo
2YGdvP1o24+24bgDCUw188V6W2K8N79ixA4L8HLhQD24Br1oJgzaXINLW08WyOAzreC+i4Sa4LTz
QdMvsCS+Et9pYlaSUxftgCltrNvzPyIOSZBiSBNCFsB4vgWoT16FGGTeD8BX26cRrgnqniOqscL2
fcL/LpbgQ4uBYtmmM8fqC5UxNI7WnkFB5sg1TuzrGHUSv0MRBRRxPYEDu3+jdVJWdhJT0kPRWEIR
a2fIpYyofZBvQkhLj9RQJf+h4rxeW1iZ5U7z3F20wtRMn7JPYIK3pkl9qNLJq+xQr3v+4Hng73Gn
XtXjGX5j9it/qrcxWK/opfyNwYv1cqZqa7p7QQJ+R2eP8KnRMZ2zGCPqOPoNJxbuuGFkc5+/o350
iiZbsBa=