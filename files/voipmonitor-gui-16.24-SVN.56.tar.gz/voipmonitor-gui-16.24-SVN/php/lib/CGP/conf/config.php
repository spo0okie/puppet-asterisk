<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPo6MBSjgDvRi55kuw7sqJHaGIGD7+QiVWiGeTukDLvHcCjNXBNbuQY358GL+lgKrvE5MuzuX
p//EYYQHGhuc9sQSG+GNZgbZlMp1zu864AT1e0RgsQyRgcOXS/ZAFYBJZv/fTrmziMVabF61hb2t
DgPd8lhIB6w01U0ZIumzbMu4ZdPOLOTfZgvfAboL9/xg3lJ2EkxCfz4/2QE8Y5zQv3JoOSwx/2yj
5sdnijpHe7TC0y8ILXih8AXfNBvuwG4bBTyIKkgHKlrK8OgC3sRqQ9wZUE4Urn8p1+hRgbdbeVmH
OuusVApKSULfEick1lMtZWm9h7zveMSFFHBOd99xZTiXJHqnSUAaQjx1vpvNIQD47ZBFT+O21nLN
KBn+MgFpokNRblM8TSt8vN4nRg93mes96ZByL+aCOJ/BOG2+9OL0uhpSCTvT/2ClN2zhRUAIO8ZV
FpxV6lQN09W0aW1kCCFrEAupRDPeP/j3wmkCcvWFykgUECDGvnZ7lwXWnp2c39K8p+3I3jgFXDsD
Gl18v8v/Te8T/iPR+l05qg550KJjZF87QFFMlqD3NWmDuTF89V9ZJVTex+ZlJKqY7C2xQWsJ1FQS
dkXiZGcxXzBkGCjsXAVF+9GK5dN/K6jVXLqQzF/BwenMLEJ40zC/7RJVqf7XqBWm63T1z2bMfnqr
+ZTwBZ+en4nKUK9t7pzc5wYVfUGiMCKICNOIMJklGfEWrwFvQo8LIygK0Kfm43QdXVaDdv1/6Gox
QrXkl8IsAuDt8Z9KhGM2L186UeAR35d4q17E8+V+iDm0ReydJVuPTOe4il0a3HF0t5UqwBW4qkaU
Tuj2KNXMjK4pBpUpxue9Q85Uv9RgkPFXSpqanAYoaSWAY9EQOHUIKxtgD8UeuQwvyqRItA7Y+otx
65q6k6O4g/DX9qrGg5ZFdaOaWXCtV5Lf8z3taYFpJLe3aR4XKWByFNCYoyZREVUkvwK+ZtZ8ZN4X
wW4Ue5odmEwZ8L8ruKNon+H80/RGDV+Ztvr3Ad47jtMrBPACxdQMAZysfEeSZW7cE2bkZlhK+Oyu
/z8e0VNho04bjZHR8XlcgrGYthmOTBxRhEqKLMSapbnxMAAJyYZLPX62cMI/WGN+hUR9LzbvVJzO
8BmLNRgRdV/UHDOKXwqdRQnj+T+FaEKGXoq7a+C+K4NLhNIn5NVv3Up2Z7JbDHRbSWnSCzB/G7c6
00I24oQOEw2qla0AnHe7RdBFQJY/J0lzdWHpXqGTQlUsJNgvKwsaWFKRXyD66SKPSV2WjOTJ4Vy5
BkJX2zZaAbZvS8sxRtRs4PGn3CUZyGrKPkJMhfMcOt1Zv+0ofhssPztPXZW+LrIrsWnNra/KikQu
kD7qo2acXaTqu9MU9YL12pJ2CUDS0aWcwwF7IGtWk7IExS7YzFGxjBbhtDQw0DBCON/l+bxoGXbD
WT6mKWyFg3u0AK6Bc+xd0gcjqjfgQM65qF+vDHO2Ikn9+XY+N5lIjEQnSs7nOH8Rgaim7lLgsVzX
PHQC+7vbSo2e+39Dw0KZPVqVGAFHYtV8t65pwvsUK3wmvvh6O6Vt7YgR6C8wMfyO0RCsS6/qE7bJ
XXbbewB7s6482H+KAucmcy/gTvMUgcowDJiuhnEfb/cqQWThaxIotvmCvYmzrnf5N9+cDSZSJW3H
7dSPRhrxW1AuBgyiK3OY+2usfKw7Euvq4+wDcbaUkKv1A9uKCRf0en4u7dWS0RMkiBCevmlxo/V5
AdNcL7BlWgMWlLWQ9b4Nr9Sdk8fN9ZJqHi8VN2mwkZxRqDKA5bOuUgldc/ylpixd4ocicy536rr/
o+occzpcuhpaUvKgWocC8KhSOv1988X/4WFLaeI8Syw3tx+gM0EI2w12MGfnSLyfV4L5LG09MdbL
C2QHUEIKEKzU6PwVOBZeShubKE4OdqBV8f92tiCX8hriKWslEToM+EIPSXtkfOOIJS1DP+I+AfUM
G0EQngVFsAwBJbuoozos8TjFuYG9tv5NAL+NKjjM3p1SBn/g2rreBzpZLIfbxOyzSIqzlR33ps3q
v3wNM+R+nt5tcwahudyZ33auGNXPjKQGAgvhWh5OucL2/LJmPDCwqnCWRr5SZZvO4DbQCz+YWsg2
VOBFTdorGKR3icgyvf/UigdGZsoQh3/Ja/djn6IFg9+Gb1szifu2wkQ2ON8qAd/WfdFz0KfE0EEu
TWaoyQgN08PNy+p1wUTiLhk/Rf5m/e4Z4IBsvz9uuOYaFsMaPpC7LfKID9Lt+Kt5i4mZhwK/8zSd
PR1Oj24TsjyrXVm3rlGx6InKwHu7dY6lYvQJu06GONVN8yZwNfSkyx1Up6u9keWCFlVN94WeOSXp
gELxcvS/PjcqneQpEYnJO1l5/o5YO9YQ9IOhsyWHY+Qno7N/fYo8+3cOhTFJWPPmzjqu6ibW76HJ
QaCTTAeDDJbxG2uOqcUIbdbZBC9PoEfh+TUjnfoh0EH0RFd70UhZWxmjAgzfHk6IQwInb4nw/3vy
DB6QtxwrZFBZodF2CgK6hE8Xh6A31Br+Kc0xMEoXG667DhNNd8BPcq/D8yFR8qb7rJvlAnpNjgdZ
6aeLf+9qaMxkrbH8VSBDVkNcgekeosFKCYAdP7iT2adO0+4vadViMeOev6LLKj27N0jiYGcI5mm4
6Zk1NMGzE55v417wbaeFno/JzNrSOX8jbS7pqOW42PYU+BzJCq511dqSNeVOpKo/Qia7xPJXnBB4
Z1FWyJsAZOVJOWfAYQqoeF3sWHokFMUEaWfpGEQyLXp7yTNRwkKgAPPIKTrcEJKW1K54LuIrpEHh
p+gUhfK1CYp8R/nJARn/zL9PDmBIy3yTNv9PxIl7aIbQ3QcEVKBrFTY0+9b/HSdCvobuqF/Vejw4
0HiscHM9YnFF5O9DjmsFG7YiwfUuUork0cFxC1nhHPvVEk5xtamoEam5o+D33mf6jhHJAaFLfZNs
uNjzAGY5PDqwiM4iW+oTP8xu7V34mMlNjgjV/X4ns2k/W4V8ysa53z+pEqc2TO/spE/LnQlAsz+7
jQze3zbSGGkg7kUwSDe3+u4FuV0MZ23QvQStgYaoELDaK/p01xoPkczrrhwoJCKAmQPx4ZwzgBp3
ZRZIdTMjkUrFDEhLt/UxEYvV/PfLRmt1pVgLJgdFsUU10nWabV1ohpANwREBuUSOU5BcxhMuAT24
Z4vL4j3ex57zxOgySoHfgioifsmhsnm8EYfST1JPDVApYSZgaQt310ngcP1N9hdebDKVDASe88/v
8ivSvy9HQUFxEnd4YsD3h3IVDfLJ3uzFeNCS1tWDKm5+wawo4KNtRifz1PR9NRmYUIdEIjr+aM0D
UT8c/QbWyGImZhu/LAzcdBb/YkyY9bD8OyJcAItpQaWKJKjFl4f3Eb91NdmOGTxkSfBGqN53m18e
Boe/WY/GArBTNEq9BImYXNcUxUqKXzlTHcMxyzWvkT00VaWuc67VFS1byIR6uSq8Zn2xVap/RPOG
aIC/nxMVC8tdh/29gVkjGE71Q90mPGWUKQMtguFhb7EYINtDeuP2HM2cUISRGXcmYnA1kDTWkHyz
plViydmuA+6ZsEcPAqT6XpHuPCxwHRbrVE+kPbxoB92XoACe2zUgaUFW9OqYc2/qdQjHIre0jdk3
ABzcki9O0PHlU+K4+iwqhBE45h/Hr6u9fMF0G+rrNiVz3UoeU0uehlqjb6KKNkU/wBrS/UQidqsK
E0HmQRggr30Tw0xvjl7YhaouZ3PuMZLzyBn1dgDr5dXoRyAA93fF21WOvsMNGtMmT3iuWlVEbKBT
EhqtZxxCjnel9thf3MAJJtyxdh08m63kPF/bxL0qtzuOZ06y8upysXnDQvVG2ChYxj4ixtatP2Bx
Yz8RJd8GfBbP5E0qksm2fBN317C4qXYDFZLrE68ST68whmvSxE2HdluOk8mtOf4Yrv+2h9mhloCI
WPWCZly1IM8rMtmJGk4X7UA5zh0O2T5tVmn+Vl37mlInPuqkpMhRYQh44H1Ijfh30mcoJyNsTIHj
VXU/6m7z/83e3H/MA5pdlA2K2quYpswlugpCmOnjejXUhNH6QnnjZvWfw2mmbq8lEKPFrx5guWH6
mSZooFf88hMdU6z3oWeP5gYogU2+riLhJziTGau10S/4dFROzC21CFhlVFGaujvutT8k1qyYhHe4
DXJ1jeMn2/M+o5JPGWryKbBEYQiZFOuwtXReHcBAj5arzjn0CXt/GJHW8qoybCLp6yRDr7vtJUxH
HSSYC4VNE/9B5wtoU34l9QD7Ja7gfDgFGj+U8rRFlyz56iY8YlgGTM+EXzmb+ulkM5RjKC+TO1Td
FZsM90DxzsftFVn9Np7ve+eJKh+AuZIdsH67t2+Nt0OP5fKFv5o+svaQ2E58vKhmCm3I5XjKUle5
iI3i5uy=