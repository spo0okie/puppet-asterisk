<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPxZxg4hRHX5jnKmzQUhTsPHIVS9x2VZPQ+bGlrlzupj2HjraTI1Dm1TqblsQX/0/w0mGFtMk
QnLLTdF/WU7ipfxk4tS1ttdQLcuJYLoteWQAgXzqZJ0aS7PtRhDxyl+HErvcX6L7Wubr1F2uZdFt
Whmwvl3OMlxQzC7UaQb49tiuscDEAI9adPFQ8ww3+5kB0EJnqkpw7zHmHYjeeEgR8tJGOpubBPEz
+uL47QacS+g9KfabZs1L8GvolIWwjmFDURxUrEsJMPCvQA4zSH8P4pl/f1L+B/JA11/JDLvd0BSh
vIpZDXQqV4E9kmRrjuuC2Qn/UQ5d3pqIs9pnV6FDmnnpqZhg8lBUiMu/El+Bc2zFe6wWxmMU1TxD
diyq7faQExN/gbFcL+uf2PYk3Qu5uoJuBgUq08dy7kfzbRy48jAucWk088hrw5vh5JlS30Dmf7RY
rGR2n4wDfaxjvWnE3064YT9QUPI/1Q2UlxwA9zGxPBTjf/y0EMn4EtaEJXasrtUvurTOd1uUSjMP
Q2TY08nq301KkrpE6PLQKC0P57ych6xuzgRSmguv2GmWczISo07EEGeZLgSa8ExFwbpgGfHFl2M1
n+p27Z4InJ5MbI+Mg/BKpyD8cvSM2o/0ZIHqesciG0hgfI9g+4vYW2o2be+HIwyMEe6S/LwIg/DC
BOYgY8wImsyS4iw2JaXa/tbVcs1a3t/A8U/4K2keUL51wnOx6hyBYGKIu/vdf8kXDCWRAZYZyLic
tUA/yb//cKI8+6DHTb4Xq1onP//A4gdIcuFLp6J3mFEH5r6bickipBLZLXsyM8vET2Zbok1pBKmn
WQsM/bjbHSNY2VWjI880UirfE9lnbP0jOZ3ak2R1PjVyVMqkbTMpW27D/v583ceqkRBoynTeMzNg
oalWmq5HKKPRatJQ3PpiajIT9xdjiP7p0JtTBXM8mIOHbmZGUlvLz3QUhNNot9A5vnaUGhftHje5
B+tuXPB8Q8JO5Mbn7gWvsyCxxtyg95G4jq/5pAZgV+sfRBR4a6LbQJLLmbTrX3GcBme/G8bcUcof
lxS4aoYr9TqzHF942gEB/2mX/bQzjqVyC9xCzqp7NbUQv6DbYTnw7pQHO3W/dtmw+w0XQUwtdez3
pMpP5jDpaJsb9fdOzKXC+T33bmUyKhmoMtI/u8XUoQQ3ABbjZi6mODFgR/JJceitbse+8XnKDBab
9MpNbpNN2Moevul0dif+0TZYAHbcsgzzYKJ79XAUZ0LKc3C5nX9Xu5baYJd5xFTDummV5gpEhZF6
8etv/YkXNcXQo3zSywhIGXFhJZAb+yWJOAYQXDMkhH3Ipud6vWLYOMxVNx5WR6lpXoYhEQEjfb6U
nm2HXPr534lI6zTm0z823Q9CduLkVmJuEI47SsXriq5vAvmKgEjS6wfMDidAPXmhkefzyhJKYbfv
Y8T8p6wJOmE6dIFWU8HV/RCJml1uXaOmiybInsltvk82LluSL8j2mczqwEP34EuXVKHab6aihwK3
Z/jrstdtOFDxLCjO4u/zLbDr3fDN00yPeIKi66zzD6XJDj2AGRk0kto6Bt7jGpagf/6WF/80r/rL
1Gqnm9njXSsk0QDlJzYcYJPZjpB6QRSx2QxX+hY2bP/l5o+1HE0ghGdNPSQUKKkCCgikuijTlYWa
z3vutVxivAPxWIe2WrzBJZ04+fB0za9SefsgxBuHGVD6gsDEI5xTmBfvPQbC7AqPnVDj95sOzc8a
ETGK7yWm/t2CWcdLTbpNwB6oHEncRyxhzM1JxVbPTfSJp9wMJH2gOIP8l+G5nvtQyhHP/Nz3/lwX
ELYReio+Rvpqt9NvQnpHQwJIgPi7cwydiXYd2UD5WjULIf1ygxSrSm8Cfgpz1Zry9m1QFbVSea8Y
M2hexsw6u5ebKt3CEyv4d+/nL6QGQiB2tNE08SmLAXeGwzVA4ktd1obGxaf9Ejzu6FWhGflE06oY
sWY/4YC99/D2HjT4e48SwvV9AdsAs/QNH0ypr6rfMnwA/rh7CmOemHn4rtqdU6+GKaBwn8yWR88z
HYKwPTV6P+Vt0Y4J1Q6T2GXaByJfX/ur3ttY1xcQvoTT8anxTva5tcvImeG7TQHQ8tB5+EaC5tpW
UOO7z0DITfoNCIBbGd5fRF15ZgmLtFuf8nHB29BvlWDZR+RZ2mAtgkAPtJKcuUsaT93RRnGcI1f7
Cp7GJxy4tWqLGi6Eb7p4nAN5uCZlM1GUuSU2k2vBG0qgUfM/mrtKTWBnudpmjA/1naa=