#!/usr/bin/php
<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPqsXRv+4E5JHDcNwl9NwnYwjyO/ZgFMjJS2trDI08vZAYiWIgm0s88R5ZkgqQuKsu3DFY2qA
bEZnGyQwDtG8xgGB2tWTMMuR3IdV2JD1MGudOYfY6BVdJx89bgeO4oEN5aZQSnTc2HN2G4uEo1uF
Zc+JVr6a9Iz4OLdR2/TmfjU90dnv6yZ4tzdnSGvXzgaw8ffHqDMfqZy59jhX3VFFp6oVgiq6JlIv
D6AqGEVo7IADlFH4XnktSAh5sfyZE8bGMynvkGLQfB6S9obiIWgesr1AkoU4L9EoxDNkJ5egfmbX
jk8OOGMWnqOtVWRrjuuC2Qn/UQ5d3pqIs9mFTfwalqcBpxNIGIzUCJUaU/zul7rHtfZMHrwXPYnJ
gUmSaHAVRdDkbyYPr1jqW7ecB/EssZ9A1eBp22dyn9RL23bKclxXJ8S7/T7kaLH2lloK/0dTDglL
034x6CqLMzFAnCSYBx+TqSbrQRUmkn8hFXilavvyBkuVb9vdlNl2zCVsE+6Gb16+53iKj2Smaeo7
vATaorOYjJOvIpgtKT9au+xQ+PFrgxihKYzCvpueVG36FI9zs5u6jekC3LmV5iVau8mt6pifVz2S
iaDtS6tkQtAHy6sqgU20GqG4JdYiygbGu+DSujC/GWWFOSQ/gQcB083xvryne2TehYzFXhCvAgOU
4pZaiXSSea/YjBJYmCKa5We+a6xX+kdtCo0M28ROsN2Ap8+hkkk434peH0KYADNt0pzUHkoC0Bk1
ByPUucIDSSCud3KNQxG36Vhc0IxSdyzFuu4+BO7/Wc1lVkvgV8f71lwbysRvELi8s+1ZLH+FV6sr
NIeergOeSEenjcnKlLMb1hCoM0swH/mjbfiDG+wifwNYISaCvC0zfZMGtSwk1yw9jeZ08qH/dEF4
s89RoqILQWFHJBnBSZ4cOpd4uCZ6mwS+q7XFICLkXj8bYZEx3LX8or3RBy3VVmrfK+Ruv3KkQcmb
mS/1A7ZanCtL+Ilrw4ky7CwHaQSo2YAS3UGVb1NdwRWjFTQP5Lqt1sWiwHW3fbB/hvNgzt+ASRKK
4bXsUFbYm2KgdWwHE8McoALkKDoObQKS49yXOzrSo0gIU8r2J5RbJ/zUnWHMDBWgckH1SlpTSaN9
MX3GIwONL6E7dLIY4Ol6U9FjKfXlysBaXCUlqfQofVrBr4bICtv5hULmgDLFxt3NOJbUSTovaAaD
ZF8RMX2wJD5642nmJRUz+s0ZT+qLf7h5j5RJs8bMpjBI+U4bHe7fZTgItuAMaAISgELu7pHOgjkW
4BbUxzUqK/13Z56OEnS1ULQAqjkkcTN/ySrIc1g3kcL7g5Af4moBHvhz4/OXQJlyOulMxM8QZDrW
pDWWPSB4sgm6P6xWHIxWK8NcNz/5nmX/ZUsRAboNl+RAztZNTTBoS6zjVq8rPjfiSDEtIUfGc1Zy
eBBI9W+gXvsQVurISE5jYF0OszWOpuzO5UPKXwh9FTv+fX7aVdUCQuCDQ4zkJP9K10sPmskNt+1+
fIwgWjlbXi0BjZb14sY9jCHC/6ANZIVBJloDufrKOQqOWYpSvDfW7qMmUsqByksH7oCq7qMhsKif
eKdTFOhNlkN0Sv8iV4xtNxW4U37ZEwwYvQJq2vCb3LQLO7hFJSKtmlSZFhXk13UWXQ9lmUEadOta
FqiCII1jLP0mPQq/avpzdtaR7zfOFJ79aOdiOV1XjWr9v/6P8YAXi1lhqVcCgXDh4NkMA4o+0Cys
TKe1UvA83loOlRp5vQvTlrXnZ0Zes/pvk25hwtw+WiB7UoV0x2TFD9amKpf33FAYiGq5xBJCS3u2
nj6z4/nzE7A1aDTYs0ILeiva9N8xIMgHaAmR08XcYR5irx7IawgZ7iR5FqhELcDCyyLEYextLc2m
t1I9j9BtzdCeVQ0iHUHOYAn1bOFYzb8RomzIURz6QhSEBXTaEyGliFVLVE/3sNvvQLFdJ/i0oyf8
N5cg7ufuGYhLlmZ7RSubJOpz0p/lC9PmU/9S35WX43+vzSk1T7ulP1w1VAGuMz5UMczUUkxTJCRg
d6aRU9Z7xjS3LHp9v7Zio4BmyEO2d04B0HvG/zJ0HmUR3Hl7rc0a4V5zONEmlENamhUdMDHVa3rD
oCWUQAkWkwG8/kSZAv2l+RAFK72d5EWtLqkKrAeSDpVmwEfJ4qjOCnauw2mDXLrrr/itkDnY9IVd
TzVToqF20NybudlrTdmX20j4Xu73XA71Dwr1nj9w8cX7vGYknQUE3Mp1+cx/aUXx4z0ELz2/jNGQ
7dfedE3PFgp1EXFKSBbjheXRU5eNZWs8wx61OXGFWrYxkV5vtFiY2Nod0pqcWC+ZKVGCqo1S2wwV
a8zTPfDe7C/fEioUpTg5YTdErozofuJcHHi8YfWazsj8E/EilnDyl+Li1jn1LVgZmHX+wxhmSbLy
eMxtr/nfYEnLhRTL8qqzfsw1XXOzzQphLrqMGkQNA0rDQFhzSJkx1HNwswENPvRtpJ+LDJy0xizB
6MY0XzX/t++MCMCC0PYauBI9reVh/Vv290sWB2L+uHaGmTg8EYUwJXpjiCuqDBEsBa4QVy2dxgtO
eAr9gYFX+jaR7PMIG88HL2jaiPJGev87k/6POQlOPEm/Tp8PKk8CiG0S6grgcYS//xsDAk5sbB0l
i8Cj5Qs6TX3Mr9PrpGvXKbWWSpEFHxSgmALSyP84VUadAci0oWQkOgG20xTSJ5VF0NnPJ/LIX9GN
5v+JGQd2+G8dHPZuxTf2yV1w+3wbHEsiYUYk1W9JA3N8D2vdzkXYd0a5G9TTliP+ZCmxKn46kKI0
FRrqE9VF34dS+21u7VJ12ybqXpHio6cigbV79OXz7ulWxgLBMopm+Cbci2JSm8FU2NmroDd85knY
Z33HWfIp+TIyb6QEMloqcU+g4aAWHNT9O5obhfNAymySm4bZIRBjqtPJ8LsUXEAw6z4LfObCPgPE
4m4honVeo4xTv5dukmoQyU+YTp00ifybCIUG1lXhN2Nmv9o7jLyzdzAXzvDYNQuL5zW3Avc5FLcq
dtPZFLEpxmlLHMwCBieiemkX7gbryvCGKv344muhCGWbu6Nbrd4xyYIAluhRnlB3hLcjoKBUtOqW
w0gSxa4ihiHFUU7QP421cjTJg+yn1gcE/gO8A9pstjgBuJJLukpGwa8jU0Qnpt44Gf39QmvqBHS0
x3NUorIVqbj/lYkW/ZUkd9Gn8kkhJ3kgpnj/HEeKHBg2rFWxBX8zsScTYfi8ujqVScAYhiLYsp6H
4/Fi2d7vPM/aS5R7o23Ac2wFnt25hmChuLeJ9lKkbxXWZdOV9nQM6YyVY7FD+mg7VrcECMhniUjh
8mEhbPUX58Zmg2IH0mmLleAvITQSNgat1AVCZQIAvbtG5U7FokT/CcV+inHRnE1e01vEeOxl1NhK
b2WAfVpxgWWEDgVnqHGPLe3G9r3QL/sg7yyVTgyP9AFOpaBDBl7VXWRT+0mxCg22p/fXQXEJmczO
MVMOCMETqaopMtejQAf/ovWM35soSELY+8MpYUpP0ek3ertRnz6k1X53LJVUf/2HGE5r0EX2IbJz
uTxx+2AiUstYw93GzvDIOJ8kiym8rM8c3I7JgSmgULksvCBZQAg7uj5tA8bGFU0FhC+NhsSfMioT
AaybcmcXuqyZloufmXUuDM44/F7g8xxz9pezT0Pqi5NUK3iWWENZ1mPNMHsKfROHeXVJVcc6I2qp
ZvJSnuLR5GW3lDIqiW85Yh7agQYXo76mlCUaDwelpQAWeB26Kdm768QEQWArB9nvAHcUV4oLGvk0
f6oq4O0rXQgOM+9poBbQVbBtUlysYSpu5ZKU7sqYKUyphXbgsDQJ9QTqwsq3mZfbKQ+sQM3MsmIW
GjCjsNRNwrttflA7tixFcqwzVb+LgfsJqTOGrTAbqHUyp4/hRKpsM41x4uE439/bEHO2v8f6L+UH
MpuRyhBdW4VIMM6HtbNaWVsXPbJN9i2/jXOHpsKdNLd8yRnIjIVT0J5ZAolYQRRNaWITopUNLqSo
Gfozbxl+4ct1KzVJpgNgMigq1x4gQhyAhCq+qQFcbI8Jl6rMNMHjVIPqrIhf3yxC5r4J6hDYyAK9
wlNgZSFIP0O2amuC/L83JEeftcPWb8oB6WLOGbg+CrIMI0i6SBO8+iC67EMhR2eS/vddcKbAsq2j
kXUyp2B9nCkfwLxeapbNADhsEP4/lWPZYUS+shmX6Chf3gJ9w3ZDdWtlriziflSFk/f8HBmJcYyp
hVB96JALdebJoE4GFhKA/lAjWYojNKF5E13wzb932j3dFJYb/ajm1gGd5oERa57GhqA3WMiMsNa2
G8A0zvqLae8P2B6UXxddJb3DJjUrnMwe4zz4KyOr9ON680MuibaH9jOl8oABSvE5HXyrRPkVM9Ds
flOlZSJgk0H0bI3zuCzs6PRIvmSm5JMvcbI51lLAgByeyV0RK+poYeqoUZTfpTxxkN0RxQg4AM9s
9jGn01BOouwPFvB3NqGUIdU1b6axVHmRAKdqCNH0DmpQ0fBbhCYQISF8s+9gNeC/WYu48D8INJxO
kWxNWMGsuBGXwWXVAirIrr9/J1uzTOU9v0HNmWaEG11KnGeWrXollyFiy2toAldeWyBWCTtknKXB
jcjupLei81e0G4WSAAeQQGJ8NsMEpMPCdrx+ocXZbspx3G9H6qcrWLxVYwGp2yUtpbLY0rnYbT8b
X85LAsD2571r4jDhS3I31JqSZuXsg/YPwj1xEXB7f1cjESOw56E5U4PZ9j29swoLj34zJya3KCWx
0x5YFNuUzDfNI/0mV+vA8zNbqMpec21avPuaofhge3PV7etORJ3QcXrzO7DCkwcsvN0Ao1GRGf7S
AW7O2SVTK6Fk/iYYe4vBbdRlWIndp23oM0oH+pkWr3abaAuM3tN3TvQxYCnzOlPyl/TTyIfnMTzS
unVv9XepHZt4isa3xqDJVmIWoucTXHrgs9gRbH7buY/i53faP7BABRDGFeB+lZq7v4ctqkRDA+Iv
l+4QEB/Xees4luLGSkgaQqKYQJSu5NYA4CTK6DWWql8q+LJdlR0WztvsYVBflzKMPnhj+i6ZQDHU
LyUSEYVIJ+7YdB3dDG6qOGFg32dt4ZQh4p1ZhNvfHvuaYJTR82//z1HDVMoRpoxfUda3IeO1CK3D
sKvKvG+M7x+k1luWcv0U5W1Kt1QBRuetKE+PDf8FyGz4FHArawGo/oq6pF/1l01nCjVQJ/y2cGhr
YtzGBwuTU9JDvqzPKhsmbV13lEeDjw388SfgXPilo9ku9ysE3uw9o5SoIHG+x0pZ6k4eN4sxnZS2
VY2ODpbB0vTcNeGju7y1i7VscbM5un6KqFtva8YNRYM47yIkzXVAyx/lLAoR/T41wPDlAqH4EZ1n
Sekx05zd2oywoakWxLAFMHrmxijq09hV0FTyIsrfLlK8QwWj3GklTlPbYsNRf6JlOCjosJN5uAlg
NHmzvwA618IBpTu8C4EwIzR6wcMtPLQuisFk7P2lQ9m9ZALsjgybt/NbHfRsj7B8FNI3I65yHPlN
rX/jUIjeFZHeqaaJKbqBP7HeHwUqpQV3sVT57bGlc8dT1o9Ag6SQbDSoDf6Vuq/0eLIktVA/2PlZ
6UDDvQJG8u6bYckvXzf8BJ5dHQ9xUbF6LNi1Rj4X2Ovp5Rx3u/fTsgE18y2zwTJGINjHnDFwlG4N
5n4GmeWx59gX4H8qdji5EmxnwbWnApZBNQ3VT7n9pNXoX9L3QQREnA2Adh6RZxpaqJh0jedqybwf
XVlgTahfHoF/cUk4jyWDRY2J/Y9y8A3E0TkHW+ICK0uCkUkDSfuniXVObojgTDzmMR651v3bxGs5
EwJCvjeXwVNhDKqdoudShYhfLcu3XlqDdGtifASVw8TB8YxZPga/mdhZDR8PwPha9/zjpqPMWQAX
qFGCO8Dg50ZKI21EuQERs+TJEmT5/ecJg3PZOjMQSPClJgodNad5tCFAydrhpoo/MoQs3XDhwU+V
9IOTLJ1DYGCRLoBOpwfupPuwv/cs602SgZYOmdh+GCOuD6AqYCpKzi4FIGQiHesEd3daYho7OKzH
DMiuX928itzIafeaplYRXVKS+XfbjUpOsALAFwKINLfdXu6tR9Gz+7JKDfGBTCHyuWbpHy9b9Hsj
xK6QBeRZfDwcxgEa2MaCj7yIqU3jGa7uQaUxQNWd84skClBV1wwTOozWlt/Peo8A2DxfvFZJbzMo
aiAZCe1fw93X+8fBOdNz+anEQizOhONfCYUNAlH19MBufdWbqiTR28xHot2V+JfeflDs8ScYEB0E
BiRWV0qfD0fNf8ShCWX8/602Y9rNEd8E5Y4e7Z048rz4xyJBWQT7aZrbYDwPzEytPw4RLAqMbj22
lA87gckCpy+ZXKB2Qv026vfNeWmHUzVHRjX4t1Y6KKIE/23mrXhLETnO8Aj5SFlK7bknHQzwd2qF
JaMa8f2PwhhlaIbPnjxZjER4JGzQ5tKnc5miKIi1Kd+baly5NmHEZQWmg2oeAC72/X/KQMBvFahX
kQEghit0ue6UWPoAmKtngcE8tAi6z7WpG1Uc8IrxPVREP+ddKtifGdmXsJsB/JimEIqtApz8Ai0S
sJdcE/YEpLP9TTUVMD+vE1AMoOuKtpXAEvPOBVKpzH/UPslfc1qBVZem2K4Ro4n92mZvYUTKaSOM
sWyfuIsMhWL0yGK3fCfC0Uu=