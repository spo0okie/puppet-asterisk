<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPsFYe84ZOHcsNIqree7z41egFHfuERRN8gBVwlpU5RhO+sfr/u78vKeTNWZXSAA4c4BVQ4m2
rNvXuK9jDxIGSPmT0vWvXL5Iv56aktuBP4Xqt63pqdDfg3EW7H2Egpg+AcKo8PK/8z4tmoR4cU1r
UCfqLurPavVyuGEbEH5BZgMVxHVRh5/uOzGEyuL+B/nt9p/wYkK30nYmSTeWepAXeIZlJBdg60Oa
JwdHFW2UJTVnu4ZaOhG8ZJHQf0KKJZRL6I3NXTcyHvpUNDL/tDaQ1CT7XKKlke/PcTPh6RONf/3Z
UmebqOyePIiS1lMtZWm9h7zveMSFFHBOd7Ht4WF+exOtocHNujvH+af32k7nuSEFdxiZQPA3opVq
6Jh9a/dFzT8CI+cbBMIs7dqE0hYK+dOZEqHdMShDmuVdg2so9rOvxpHiqpELv5GIka/IGf0tCR0Q
anhvu2cSHNVFJ1O2Ms4V4EbFmoeOoSIAUzYSjhesg6EZcouQ1br3gHDhe1J4lQbNHi0879rCPsrj
3Br/kPERumfEC2idc3djfEOPZ2jJ9el+R8ffePPVXdOHWj/ZJJ61LQcaJGnaRgYHrlJZZi0iCpYT
1gX1swNm50zK3dzAj0hiQ7mpCrl18dghOCFcDU0UA6PsuTrbwG37uIyYGVpXJCFfk2+o8OiDGQ+W
KgZCchHGf+e/Cjq5om1mlMOWxt2Td/4bqstw54ZKIl2r2on8cXk7xwquvI+OzFvq6xg6LWhU1+TN
1FFmvwtvXtzFJP3MbnNz/O63ZDvBOG+o3j+lhBu+X03bSB0oJqgfOSOUwaIPmnItKHWZgxl6g+QA
bdC323YuKd7yiJisntGxcn7+EvRUJlhrQpQj/6/E9JZGLNslrEcx8wSAPeX3mkGjbDoL1oK+CxQh
N0uPA7Vsra+R+ik0i8gE7VV8hPpwhnoRWyl2FNLJ8kFx2Stqw0KInwSdgdMRlQe0L8l+hy3eRW/I
Sysil1rB40xmSGs1crqFJ8X8KBG8KI+MwVPUTUjsI1WoPjCYkhIcA9ykdTbx3A9/6lyhdWEUp6kY
eMwDqXhauKULgParyhX2WX3hR0++jTLZrkW6y3x1A9JCdKbafTeRJgka6pU0kXtL/JbjXeuZeAVc
3TqnoHgS5VIPOk7QvUWDRsLGVvLWu4WxIC9i1hLyH7B6Ha2vOvEbxPz7tz66Ih4/3OpVUnEJXp6F
xq67/i43SuteQywSPPa5RcxGIk8YPA45LSkSTyPw9y/gEpv9lVrsPovxfnm3KEFSPN+q8P8WpLlx
vCgSy5nQ638oR+hVSKl+xQktDvEl1wlxeNn2ejFyXZ/f5C3NjMTd/eNMBEf+nv7EFY6vHIycdvRY
pTUaBn+tBuN1KMhgf4phUhjE8SD//wHUYDQid/9KB/J7gJ0nE9ucCIyqJIE51364rSyIH83YcPRu
KC8tXaHKasIp+p78c8/+NoZBdvXRxnoKoTCeiiz+ngooDdbiPC8KZyUExwhaq68PfE/DlHMikjY6
7eHprRw6yCFW0W/iKl8G7c1/4t1YtRVqxzqCQxMto1NaeDpsq+xdEl83aW8k4i2YOZTAV2dh+Wm+
BbiXymVNeol5ZZeXqM7oYui0uRcGdwySB779JannaqiX6wfevcaaZc2iSAil1LuqEkl1eqCQo0H5
x2+McckOX36D+zm2vd2kkhItMdMOBYGt6iE1lQfQUUOKIFDJLAEjYGa9Mp5tIlezhW0dP6OEIjfL
OgPZNmK5asAxDgj2MkS3nXUg/3QFOw0izkP2NrtxfX7pW9qYINAcdcIFm5Noc/EZR0DL7mI7mm/+
Wa2ET7dTx108c+Y48Kvkv6zpfOK8QU3EcQ6TOsPXZwcrkIMd56VHEvdjEkECRFsPssP/ywE2E6sD
bNERBtBe9oGg9dIErkK9/PjPXwEuFkI4NB8AxbnPQWx99o5uq6795OiJhjLP1oRAi+Gz1IzDzfFD
FWvQMOqrQW1R0iqYSRN0IXiYO9YWxfGH05fBDcW0csW6bRt9s9WsRZIOjZ8KevbgBTH65FhCwIaQ
V6Mih8QiOPzejBvTdY6ofPzuI2i4aJTOjK3nB//+L7a8OAU1ZctW5cdCYB1CfQHNuSWC78e9sMU0
PYfQbLbAxNglZeG8BTVVO7KgXIU1boGWQzPmeVUByZPaKu8WjfsZ7SgO6zU3mGpwAOTZGeKQt076
EP+lOfJGxa5njwdXydV9+456kE7FqCqDGysuf1Y0zsccniPqoOIfUoJa8ch5z08q1E6Z/0MRE2+G
taWE9+3ZLkEV1nd1ciVGXm0C2pPbf5+EZ8ZvR4lP9UQjj5xspiAV2qgjoZ24wCh59MJrYfanpdW1
lZtaD5pWvarGxPDwim8g1pLh7ZOVOQKd6H/mqwWFG64myCVjm7YUKSs9nVml4zer/mSuzoXet4CT
QHHOeB+EztMhHHRauqByXk1FsxXtkDPMZ401Er03CyprlN06n4Ey0XQDcuPDhD3EQdjTv5y96dp6
g18B6owPUo82qG4fl9e44yNAtxBcbsu3/oFgnc7E8acCQmR7DBEtm+6XfjNKB6Wa59tcOeJZrqnm
LURJBU8kDC0O9FvC5kw0g4reiCgG2xjTBrpiC925wGmGVSshaL5TEjI8gH1SWOQD5Ya9o/QbmgaF
scmCg1n4qtAVxsILQaT02qK2COPLL/bbamPba2sxY7S3/nDvR5iD04Slf3tO1cgaGW2pgLbb7WW6
W5w9j0Z4g/F9G/pyJBc2MMWGHFF6TTxRdczoa/9PfagPU31CR5D8byx4ppR3IMR7V/XlmY4aW7Z+
390CIk6bmg6CCpSSPpvpfOdHMjHCM4ReVxeZ3aA9Lrw6iVP4Cl2uIoJEZu9veEzEVK2dBUP+ff1y
2xBFMleRHGQ5t4aS5mmDUFd0flCDv7czFnK+g+q4qNJctHpCDN+Hy224IXNsHWrjt1jFLGmYDkWa
6G3q3DgdJH7zeH51wcLPGmsuFVEW2a+5EiR2T2F0f+qA+Rg1HdKfprC23vEAc7ZhYMUgV0GBQf1G
wkrqoQ2DHKNtHTa3PGVGwP9bqRlrYCtxqJEIfsIwQOqFMyA5rmGCI/wCXLchROEbi5m64EIjI8mj
dCUe48zASZ8rVlyBcS0Lqfea+HlS2JFG4wh+AK0gIO8K9BMVxiht8PKdiFAAO4cZLFzZt40f/dB+
jXVsXa8PAkLvWXX8jp1AYs8rXsmcHzvprrXR5LOJ2P7y5mhv5dBkh6X1Wa6caQX8z3lZtskZZkv6
xboM7IIMrzWuxJfB5I0OPe9Bg5LuSMCGfQXvEXasieVVOVyhm1tvhAQvRVx71/nHgjQ8IuQJDzX/
1j26OoTHkTVkifsV30QFxM+w/Gc2OkYLrtcA6/r+A2gNdGoaHZy/GQzMiIjSyT3VKoZ3sqzKtQOj
FjH9Gj+c5d/jYXlHKY9CQevT7N9xgaWzMO0Mv6wHXXPweY4MmBXJ/q5qnDw2HV98EwZTfBec2hEp
NrFuhHZ70Qu2oGfVKBY+RZuPBP4jGT/icXBg8wXCc73XrsR2yhTkFRwPS2TVSam4vIOJ67KMCLBs
OBTFLyOobXQmwfGMoreM3D0Ln/RmR2JodWIDaiycabmUvk67IzlxkVL+6V6vTN/xvhDaRfx28fwl
gtX+t9f8SKLdfptzM7YOHr07borLQaxxEWqT+RYT8sLAVOdmmBjirTnVf0CUs9SoUSWEUeWAS02M
Y7oZDqBJr6C33q5zVUdFY6GfR7ZFcnzFnbL7j349BWFN0wHYhIJlIXfv/mM3/vWqS4mscv2Y2t7u
AP/olzii/UufB7Z/kgREheyBguq47L49CP1pnBV7msJHNOap9/yrhu1/21dkhBUCS/p2KZWQNphK
TJXmi8rNFQ3LYWHYk59mLhwS6qSqIMF9l5qSWXVqaR6rUdmJITxR96QSC6zPLe12VBLw+fz0Eypg
ucaPoAg2+GdAkIwiQfup7Y2Ck02/oHFFawCqJ5PZ5DjBvTWW63Rn3rXioCXhrsXIuE9/g0vVlovM
QJILZp7sPsgmQbhWxWET7y9aPrr3ENmGH2KmztHOXlqz5523mUPqcG78WT1+PdnQOo2jIYQUjNrf
4u6HdsSzUUTx7B1lsS9g64QMEERxdxeB0LnIptFSHA3NsBEs5r6SFVyOPKoOyV1PE7jmtmfnHgF8
phfFjj8d5BuwfpymHJuKm1IP+4rntpSs4j+FObaz4RKrZP+Wvj6OXeu9r+y4o2d8ZoBJ6GjBW2/q
36f20GRiQ+xUtJIdaxo/ElC38D1mTsYfPklTsFZTR/hBzmqSFsRPT9sNL1JVSSVtjlbdT7wzx2Or
xcfV+VotHbDBQcybNaZ9G7UlSMwUZjjRUMBHzKKw5s5XQTeRy7HtyYpCOcX06fIkWE43645UrlkT
izJKw+sbtQHmfoA/C8vjfMg+1nAFTlqU3NeDX0T6DbRVyQuDCLE9digtO2bSa103G2xyf2JXL9aj
/rTXPaWzNiGc0ZXzm0y4C+1n/Ctr0mSi1WHUTWZQkYAAgV8Gnj5bUBEkVAvntuDHPkvjt6Xhkn1R
M6Iwg2TWT4fcxXOEmNiaViV1QUBUf5Q0s4XvkUBujf/pb0FSUZ0946DnE5VuWeOFtO3UI0AQGG1E
55U2sQFxoCfWg20hB6E9k5O/emCmkNSpYnZ6c46mxPp/hefbIM5xomhIVse4pdHAWILT7N+oIh7s
XNrRPDtx+ZMwE5Yrgc6TD5VF6ZaqFO5g9bcIKPIQTbrW6vqPbHalFHcjraYjIkIQI7R0nwTv/vlq
AoLbbv0igOtCaVfhsY68M+hugAKqvTG87vW8wCg5+Tr5LuMXRyRY4KSTYXjiWI9yKL04TUvdnMj2
xNIIHWFEljhcC+msM2oaNNN938WFtSm7mxY9GSyfGr0AZzgvEjRTtUBAXsx6nOEmgCtVBlzk5+ma
gIthqnVWgD7F6GOEwuPf6+ADvZDWCV8VkcrEEVnzM1cA5MksnL3SrfIrSmR9YZdIryGV4S4P9FSG
DaaTkunXSYN+L99tdnEDrggM2dbJivx6pnJMBGnMfWCMSeB5No9f4Nw417QjhoNAnLe=