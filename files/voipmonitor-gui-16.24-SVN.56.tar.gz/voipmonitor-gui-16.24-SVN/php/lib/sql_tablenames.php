<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cP/dXeRWaPHg/LYaqcrP5O4JYM1WXOJV4BwBVv14kjY8g8sUT+dddM0aDiJFtTpwzhYCl19sd
oNe8ByvmOdNcFeD3m5lOKTSZkU8i7fWnvrh1sQgrIka/DbUCMa+qQ/VkWr68wx9l4o3EvY6DHqTh
bP8JDoucizV/MDoVtZGwSMFWSF4eMksUTmbmZbkpoj5OPhmbzeM55M2p6autcyR9CmN1iI7vfSBG
1L5Af3FdXB1BJ8OTuUW0HO1nxgkgDDDUKx+/UBfUjNQkbB5Hh37ssNfUaBKh3+LesuG5nZSlcYqM
MA6gEHXTB4Nz1lMtZWm9h7zveMSFFHBOdFjt/cVOf7ATDdtmfIuXaPLVEDatI/bGe94J0W9i/rHT
82mkzMxGm1yktZSK+JK+nNsUxko660GsO00lGyQeN6ozk0XPvdDFYTlGdn9n42uKFutW0oHU+jzL
R/9ftk+H09e0ZG11iyFeDsCW4528CkfDMwjobGnnJ6zddtoeg0tOdH0lexDwZaNR7KSEkGqNUkj7
88/WYhSfqw54NItfZ+OMAZadz9yxQkZ7hWo881dJAqFhA0FVhw6LwDn+E4311YuzHawl6MF4Kg7U
IdtwDZlwgtGHa8OpFMAlV9Bt7S41o87PboA6VxYNI5mDkXCnIun/TgkhF+cAzo/nBXQRwVN8fCZa
GErB2JTRc6FrqiW59GGoZHCGK5lO0+mMOG4z+6FXOHm14EX7/b+hGo5T66DkD7PaGu+JSuv6kfxh
s2aphSCbCw4huo3vxIlFiTLpyuRWeRlzodDuLlBbTxjS8EOcjny+EGnEXDsNbf/SiJPLuSdx+XRq
NPQXt9gadn5VsDbmtbKaoCYE/C4bIaf/O57ZCV+zwZa1/6Vl+ufYZaNd8zRJFRimAKm41MsRgOfX
uQ+pwwZrwz5umGbs4O+PLt5ITvvj+/7ZaVYUiESiZwSOEwQVHvA1Qqv0XGhO24ZoCq14byyTZxXS
R1O0Rn5X3b/t/hvf2aC+9Vj/Ddy32TkDN4oZmL2zi8CKOH8mbYP8fwCOY7a9fRlcH2R4Q49GVdqF
wKXKbiFy6QGVxV7eDrhQa8Wd2ZBKigvQma1qbcj/WUpPeUKwZSlLPXP95/gAZHZe21jwqYXZ+P9t
evvv9ZZnhWXoJLq2Wnwu2vOl4gCAcpUf2Bce04XmW7DI32kd/0gB/19JqrHRyQE83PVZiVSXtwDP
iRn7LPNLg5geh91DJe3QPXpmtLVOxe2P0944QVH458iwCoutoDmErntdx6pQDJcrOCPp4EjvgdfZ
Ic7Y74ZJdxn9sht6j4+vB+xbj5eYffQQ5t8CyVPpS/TM0PQfY61Jk08VpWaTYwQVcSuPQk0ZuPQe
A50/YIQoUc0RZgBBBhodC1USQVydHzCaxgKF1IN/i6nJEB/abhuPLg4GS2SvFU5Y4A0RbdYXVk4x
UkX4crIEDmAmqR/mt/vtz/RauXjWxvjH5aTJxpKinaGZ7UvuABY++QpGSx5YFwKsIdI8KKkeeQbg
MvtVB0QK9ZOErglMFzH18pJdnLPEaBI095v8Y+44agX/vMUpf7nyo4h4eG9qcfexv4aotNFIwy+P
Ep8CFNX/dGWRla1Zsnv2wn4MI6+D2hsIJyfhdeCDT0zRUimThb3LUlgvpLDUSzIICg83ZrzTQN2m
8Q2+02fMzBTMaLGYm4vf9sU/unV5YD+jvnpx5L0d1WMenSoVBSBBmPdDkYOaqxHQcw87GP5qNmcZ
BFzA6QrrycSYnlWgUihC4XgFTEoF9fJJp6HDG3MsMv1e0v0/FyKRWET+5qhSINl3rzUdYKijJHlI
q5FRLaRfMC4UhGJxg+92YUt+URZw45MeXIdCDwc/qdCFiiC4kU/1h9DNbQ5GgA7O2NKYLzrOrPjk
GlQKTVwMzY/TufWGVai1/+LhNKIP4s3tzYKd8bmOCBe4gOlG/jQL6aqVfkN/D+twE+9q9/hmyi9j
LvuO6cl6eWyZPseZJOVeGMQgWBWW5aBLDwkutj6cfItqf2Lcse3rz2kZktsCWqVhHT0JrABloZjB
oaNLLT+deQcxIgLp4rwXxjve62AFTvtPxQKOv+reg+4IUjkbSitAt1a8yKGWRepzY78Mp3GH8kj5
PhSShWGIYaulHqF5yijK2XhoV//2kgZsMYKJAKHzSCw+mEvoAFmNNPRznI6LDrfk46Z/fQEtzHlO
AyKgFH/9CtsK+yFCvKhOI7ZfmSBjPxdVRvf3PomwUqlgMoq95Sb8XH5VnG7SJhLkw9XkFq2/GKxQ
EeXL2drPO40wzyme9PolLo+z7xr1mKSOJ702rz0nzOZN3bDxxTFYSi4p1Y+KHW4/gsJC3Aj0W6NY
AdiPILJ9G5Ry+jaBCkTVBgs6WgU+2dAHaWFojAmPPfUOrwweH4I/wHQZrqU5JYdcA2Dk+VWvLFbK
D95o6rR/Zx0LGBCERRXijhBKdyABxTbhl0qbgILJ4PXp3IZE7clnk+wlWV4vBvuigMSOsijFYYL7
igvZDc+1Jq4h3EwD+CuhDX58NZuYRYPDNgmMwLWGUbsdNhmZP2Dq7MhzyX3QX7K/fqZCpgfQiAND
DMdmStQTgS8qtJV+yFUa5BaFsxO5PLIB0W+tZoJzbHpcFPq5bUCF7eSwJTkwUdy8Qe/no40a1F7k
EvUK0TZwPFLiNERW5oG0R3UXklFWf4k8nPx3X3O0R3Ia3RBQkcdbO7o9zBbuSkmBwIUNSNufHlwu
m/12c8niL9cEQw9WCD6HR9Os0Qv/hyiS7zoWPkim3oEEE1Hq9Qmst2I0xz/47PB0OPGv8BWM69XV
TJ+9bpJGZC5cKsY9BYw5wVLhDqGqv3ixdT/mY/CDmCqlrrrzwtzbAfaBQHiVZqC2aJEwhT8P55hN
D4Ea3+FJnZELbbjvBI4OH3B1dxNcNQulBMFyPI0xjONuhjBD2pvrlbicdi7R3R68jrpDu67QK7Q1
xUTJSFaSbuLy8Y3mS+XJSVb3TCI65B4uYR9mD/0Nu52sq03k7wlWsy2O1WS8eUtq0l9hOQuoleWA
mBs9ADLlgxnZT8aCOb50Ej9GSvjn3p3jszPFR+AvgEL/1gvsEv0kfCerEiIBaxHOMex24WSTW+eG
PdAgXO0FRCP337HLlduA/+9/K7sEqemkws/o3YSxDhooO4/J7uJ1HY9fSyz1EocLZbDbDosQeV/m
ifsT6NiPQDbOE2RiwKNt7KM9bQHmzbxG/LuTo9T6YuxjqpJ7YE/djOgd3MZReYm41qdkJJf6/aHY
pL1wi/cclF/HReQdLh8xXtcgpER2fpN1iYNYkzc0j8BUwqQWhCar64jsTMUVHGWY1IwmKJF3R/8/
nyFcZiGI1hYyVzV2qDk44fgjTGMRYx0B6DpDHM5CQLERwu+tgVDJB/jv1Rb3J5lfMexdyVLHxiGv
ScdCvB/9HyRe9IkFUK5jLT8i52rXwPmUxxala2CaSl8Z76RHDZg5VxkdWnGExzdE2V+KNkzDy5sB
PxoKd0Bm9VSaRBPLpDqX8X+CwZiXGDtLTDStJg4wkBMoyruQj0b0UbkXPq9KgWd8q9fvjPeY96eU
jpGreCG7M9ewaV47sxC/zxFcOOlb1sVMB1i8v8ZiDzNpVgxnB4PEXL2ldmTB947orxk2+tGIkmzR
ipuA8HezCQiEi9mwTcg7OAoRrziv1H7cnLls3k5sluxn3aWlDba62Qtp/e7Udx38yk/2V8VMsaMU
fXBF1nKbVInBBorGslwZO9NNZ9HW0RhiQniAFytsc5rJ1gAFvqbJ9xxEXfYzngIWnNmZnETY70oX
FaRWTSSP9yeXDv/tCdmRVNSG2utcZWmK2oguH8/UXNblpMywrqgNeQPnDimvoAeedKfUbxbVXwc8
qrWMyh01K2UqhJfxdpqCI8dw/YpPE8RqP78Ns6Of+a2fX8CFwf/GQdY+UTflO+I3/bzeEtC/B/Cm
q1Vh2Y2bmycktckcDhaG5hn8/On4A8Luyr68mJkSBdM3oICL6aWOwilDwPOF6tEBYGPnkcEkvpI7
LqrygNCrPK+vZYuP9yJYc14IGiPB6N4n4Bakb+Z044Ud4BWujHlMcIX1lmS80zEP7TbeE2TX00xS
luHnbw/fo0YW1kqSq0MSQ20cH1XDJWQ0FpdK64Lkc1OWJtmGTma77Ex05pt0B1J8NhOuXczG2Goc
X5exKX+CWJq+YPkq5+DeDQHSUDNOpxSkt/9sB44Olp1dHuTpflWvaUpZlkt+8pJFeeSJ1xObLcMi
fv/qNMk49sDCgfrlgOCxYCqKt6qtuwNiI2agC+KqQ6/IMp3C+pdlOHBKjQwbPDME3wPyuHia8sr5
RiOOJc0Yk2pVL+MNBiw7c3WMO5Pacutb6OQVm53Fp6xUieBmeXj0eQr5fLtZBt/LKVQKJIf+mtNw
V6k+Rw2Ymm4HG3W9IGOd1E1OXTiu+6qqlxnSY1lQGaTz4bzs1dz3/BPfHJ2onYeEiSztrqjwVoS4
LPPG1XVud/cOgqRMv7yev5RBDh9PMPzI1SEg5XYbuuEs5fDL25HUGmrcNwpEGCE5YJskvMvEsKdR
++SarmdheDOKeKtUvVFRcbXUk7sUTdWqoEbEAzrXhMgmnmtAbTZpIGgEYg8kUd6iHZUh2wQtoxV6
iI6HRyMZqNiSM7cpAU6B1XIZEKNQMxKzL0zPoV+8uBfp5XG0QPtBPxdO1rWoED0jnLMktv7SSLx6
dVm34P/0oeyvSU5lok+IHBQHAwdn0enlc3WvKx8MbX/da2fbuw15JfPZzXM8CqOSKClcFtk7WU7L
GtMm89RiLntgPHlWMfwll1mkZFbmfNUcCuJjFTIjZXbrKe5uTNJcnlLCkbocd9UMiiqWhi5CcOGs
1RiKo9c23F+l0HJL2kA57vYoWSrMNKJ6T0VPZqu0Y2/Tx48mYiU94LzFxJRKDzgj6tJT7VMZ7wFy
MBqj2t0ZsYKis44GBG7NcrxMwJiYlTdYUm/qPewBOo9gVVKTViLSTCgEXyrfRHneeqLSTQfakMA9
QfNu9jOSYinMfs25zmSKgZNEyzNWSAQXRhnOKL0vghBTsXhBgC89MU3o/QOR48E+9X7wgnzTwQ33
PVqFoaZg/b/fy9cH/BBCGukaq206km+1/7/UH9BDcukJpra52F5BGlpN5BQABWNuxdo1Pw+HlqLk
PrGhMftrRCZzYOz6hUS303Mp43OmQKsT+nBoZa/L9QBm7bHA9yrj/m0Xw+b/LLkHQtfHm8bnXnQA
kWEvF+nD7P4StETllHuMLjWSkQvi4BRx