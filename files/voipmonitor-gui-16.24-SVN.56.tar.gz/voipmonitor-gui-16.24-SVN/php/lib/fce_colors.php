<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPyGe9jz7kveGUUUp/0+SAwDIyRbNHNrG3EgVecd4GHlGNvAqvGKKZkCA72alLcoCevkT72IU
SouK22ulUNTU4BgFJBrjEr1Beh0mKoCuRAPliCgHyf3d7PMfhDXuBslXIJH9rhaTZCxmElfTcSge
lCEBPoO3aBLuFuzCWFjQbZBXWNh27Bu1qzLy+HxsRhVGQoV4XeLR+z1Z7VsnjikM9GlYXkhUXkQa
2gHYGugR7dBrc11iUk784xkOfJzkes8UKSTyPgyOad3oG1xm+tKGijvSSWNrEQyqtLlxwM46HL2z
Hb1S8mwY4iSL7mRrjuuC2Qn/UQ5d3pqIs9o9UVAWkiOJG7f0szlUSNT04l+wdYDyuFgU4p7O8672
beBV3gpef6/Hao2fTnDIYSyPNgBhWJSqsm9oOdpNgazPvwojK7neW51oGgrLcuGMX3fNnoPEDqWS
vPdcqWLEdoS0HuGJdEB2NA/RGOrkzGYmA8PQjdA5QXT/WFZihk9XM2U3FbJcfnqmNyKX6R5Lsz6R
k00vq2IwH+YLNSmGSGKuFTy6NMiWPHp3aTeBHk79mP8sm2jGIQapX1dpiohKhXc4O0Zf5cmnxJTu
uln22drUKAJvfWo0dL78eOaRt7f7BhSDwVcDKCKYvZRTvpTrkDCEqVdYIvpKdfVxGDNLhpZfQfu4
W1isV1NWQ84towlyRdGZxG/45RC9vtQlLtsqSZ9K+Ke2uHS4/NBIPu6Tvorg7cKYKS6q/TmSQfdS
/HIZPRASb5xXHVl40WH8NESw/sXob55EQMbhdjZgV8SQ5Ec5GaV+AiEiZ21qau0CWeSzT5hz0O2i
KxZ1R+ubKUc+GjiSHNKWYKUgDpzh60P5arlg3WadASh4kwLXj4apEyp7yQg02lMvpmKUEohL8k6d
j/+Yal4n/lrdUrclll4Z+SuiGfDqKedFM+GiU8V2b4vFUgqebTL6YtNIuU63kxwrMxUziz9THp/S
/0BKBf9fBdQFq7x2J16Bl/TqM+vjoIs6dODuAn4JTk+QyuOAs8cHffeLGXGL7NkepDVzkQneXQq2
pTIMdYFlcH4oqzIyjjcEOI6Rg2ff7F5pVUnWDSbfGU/mIGMhV0wPJiJnWg7Xm3tLS4I/P53jHt9v
K2xdTESdw+em6eNY2SSFmvcVsizppbxy73RpDnS/puGGJoI/+ru0nQA3vA+XUo0q24MSXUh2OEM8
PTcSJ5qFYtEp+XMOK5/7gxg7/DMRLvZ1Ch7aSF/yLsl4dpX5fBCAY4QzwiyYcrfQLlaorLLQK5ok
Lg5wwbiEL0jJ8jjhsxUU8AUqpn8eO+XtbPAa7sWwQj6WOT3grioMXgHy9keAUBIsIeqr3OxLwmaa
eg6pnmtbtIwpQ+zpkCtMnliEtGvB9F+xKaxoI20MOfUJHHHqM1O7tqhT3PgAs4ubtFgzBMThtPoo
8c2hBgI9gu6TbD4DdumWdhbK2dl/5f7lI4TUJTRxcJhxBSYeYB3vgqOiLC6m/b6hVSxfAHRltdRd
7zsQLCCn7f3WR8s/0lSvlBESV5UMgD1UB+exBCWTkvGD3X0tKffkRWWbRGUwIkXB7lyEIzCTXZ5e
tH/J3e4fGQq+hOYfGdXtToltrcVI5wHSEF5+ieWG2iAemWgZbgcuRoGBmUwQK/tMtSseR2o7/sOq
xyNSZLYGPLVeB9VvVNta8TQk9riRk+InG4pOb6JYUKhT6hOr70s9r0nrftmeGzO6HomW/wO2AotW
AId03z6Fw7wB7AY0AQcwB77OudvCm+MJ20l9ZMh/9OEWYeExW1rtPMsoUd2fRxBX03TaJPeFTjUV
yO7RB2ZBR9H0dycfJpcum2SiYvz4C5X5vJ1Xweem3rrw22QJj2BLYWTkGWDr2rWVeH/ejszJctfV
urZsbVFPx3c0jE1X06J26ZyqmELz2L/jMLw+Xks6mgIad1PX/sabg+FIz0XP9T1Iuq1XMNwszqY3
zDgE6l/kbzigK6czBs0p5DBeQiRIY+j6NeJoAOPkxeeAkJ22ufwwaoW5auhJpRkAla9TPecJ9Lc8
ufdYmLiG2wE9KjT41Yy+z8EZ58Oj3dLZ4F00YEQhYKEhdLpNYPa0Zv/1xl2qo6bpuwZLGM2UzphR
Hjq86W4Ql8YGSfuZAgWjrT0gGz6UsC9XjuclsXdixnPTmxUgprFxqDnrwLSVL/7VlXvQ391MdaUN
w3CCXbYdG12qbMPnRfTma4PXghMzJo6de8ANcoKnWEq2Cp9woH5mQdD862ShcnFyE8GR01XV98Vp
yWGsEjEF0/Q3hDxc0z2Pjsq7mThyAMbS1DpFuJd1ulXdCgnG92auIyTVJCZBWwFjdNzmz2HMcf39
uRB+y/+ITcMFaJf5B92Q4zO/sm15rI4619ux2EZi9QalwTFb/QVps5Qh+7R0buVtejrkGFL8NMzy
Tlz6AXE0NYfA4NadLU8l5rdCKwVTNmy8b6lVmw0fEljasxkdxvNryGlmjiC607ySgucCIGmsumL5
x784ZJE6eN/8Mkg89tnahD+yvm9wjUzJySC2bdJqnHLjiLpUunF8uYCtwjt1nXqM7RfKgJ8Emmxi
eBlqUbhV8Co5h3tkpA9Jlb/Lx7vVjkurZ4X+jpq7xOPKi//vXa1rTNA0M0goY9kf2vNVntBq5szZ
RB5lo9plYi/1YSG94oMV+L1YNT7cIgD4INQO2OEuf8i1kHek4fW6yPAG///c56itcQ0U6Ue6qn7u
gOrVsAT7TMpmlFYmRpiBcJKMvxrTWLIcCNs60yup/vJ9dSbQkvbXLUhX2N3US7ns6WvtWG7X4D4W
hTdY3fGtif+26kAtzTHAEhKCMu8lXOuowB6zldgbc+0avtyY/LjbXizOtk6eN1F97sIJBZiqtW+V
Ypw6IC+B/U5NiL8+ti8gm3hZO7LzaRws0xSszIOdgYlbPfGQqsIfOTJtUrkxB3KOgNbbZfVMTBfx
3WljGUG9Vg/MvNaErulZbo1LTT6JVAbRr1VyMMc0Lxq7SzT7dS/GpY0EtKPdaklpO64z8G0E25bb
3fTlNPCb4v6RfBobHPm+o9w56zJ9TU8bciKtM9qSriPpRl+bJS4GbyR3BykjC3Ik1HawQ8FE/zvV
5qqA/0Ny790X5zDv2Or5Bwz/KOPLmIaee3N2kC9x/hrEPy7i8zixZyn29g34dt2m6+qPHfBxJS01
KQcSjUB3CaxnCuAvU/z5wmIuiwljqb6WLxTyRXGYG8YtSJrDIlBB9p2KfynMp0bHitz4ZmdzQ5lY
RXemk60blEO3vhMiz13Oh8yCsG/YlQ7/1FJYwRyXgQrAI438X7asJcsl/mBZcKq7DOtMCz3nLGqL
EXkYSbVgV1focrgamdooJOoYWbMBZyzhHAYff/J7vn13NO35Ii0OKDHVRbi7u+IeZRHsajg4KO5i
geXYXRK9S7sCYGkQpGwjdkqUln2nIPXKSAKOiUFhOfloMezQOlz9KjM6wZDys9M2lVFRQ58nXxOe
NMsEXYxRvcqhoKzqrCxcHHwySad16yeODWn5HApaqtIK2qeATkhW1npjE5xOLWPkl0DZrwHyqiVn
igp864nvOocDAXhMy9xUBhmWuu3ddPWXlvkH37deKlcdTFWG2c0pDNUjx56sZhR5XvNSnIa68R+P
taZILjzelef7ygt6UnZzlATNxgXNeEiB/lBWNUmIXXTM2Qt0X9IqulNBuy7TD4TZYJK3mdIE9Pdy
NHdT54EY9hyi2kZ36MtrbosKfoLjLrGZ7auXNt4kCSaCrOGYa+XethSJgzzKeviCpQf/mBbC00id
rUpVf2EB+gWQ/zR96FE6KiROhZZFAjmRrejmnaCLI/4dpmEeVIIA5FN+ujXFG/3WKJxcgaPpscz8
MyjzopXbpNeUbhtexF2/sBGtomQB0uLZtUepd7t/J+MpvUF94EEr3UU8JLr2xVqx7AO6iqtnfydH
GzY/yPvdFvjrA9StiekU5bW8JXpELDNfZja8d0aAMGP6NQff6ZIxajNm1DhM4l/ZWLdjbAKBfmXm
WfTyJ44Rk8ySmvKLVJQEQNIjSM86fXbwn9Hsq47Dm5tZgWCrETlhJzOIZKEtgnAloyyLLMeSvrwy
K6gS9zqazl32O/Kn53ABSMx4kQtpscddMD+szuDHLE9eXOX5caF/PVtTlKCxJdJLu/+6CqbTkta9
d2Ox3icwjuy4Nj2uHuup/VHlWPv0YG6QrSXh8hhlJapeqPH/2EEX6ncuyW+is8zaw5DPgb+1zXHf
hJAAqVe1VUh843BO3vvEse8wp/KX5EbWvts0CSPZIqGhN/FuPR6wVOu+jnhP62nHklQX6X/ox5X6
7kooaz06ueH3m8XBS42rNvvgScWblGiTEXfnDWGrKyJFph7RlrKz11Ag3UnOUQlZvJFcJ0TTStzX
Z/F6zXHM+jBFgNMYgBN8e9qhJASte2kRQ+iJsF+7Q1kUpjxOB3uC0I7x6swCnKJq6MErqGMctW5j
OrLKgemF09wNMlzJj090Q1obmDY6WFbGCkqgE16/SfP8E15vISKXjnwhaDJkr+CKarH3aeBOet+4
6s6TKtI4aJ6gxS62uigJom+6hYyUhA3wk/j9oOEWE6KThXtUXslw/HeByVuZMtsGvNw7SOmnAZIm
dNGrg5VxHWfw1+Evhfaf3/L/SKlaDJ4w6ylG21CiI6eXljw7M1JYicBNkT5VvfUxaDD8YuLPkSpv
69fRdn7W4tlM8jmwToyiNXfUmBJrNU1U5fiT95GoHyna+lS2nMLDU5lkLIoYnc2FcW8Vt1e/CT+P
0z/qW9ewSgUdriYP70FmN58h2bSR+y1KyqYQ6lfF6360rj6xey4T3+OFqtAuh7ROqXBgtxKOYfqx
Bn/q2VEJmqnRYx2YWBtEgetI7wp5RA9gWYOZ2Xv/KD/9k/+floD2