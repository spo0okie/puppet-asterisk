<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPn6DX42dMdrtsKWHOpdOBbHoXLTbpwNu6U38e/q9goUV1iMEv940+oVGM4NCY9PB7laOnoCw
fnoEr+VhRB4tNfxiuXh0/BJFBE9s5sZW3l+laph7ak1Z9YysMTchKrluWKjR3xyHyGIOVmNVPeJ5
MCOPxvNuBXHzl6DRIuxo7noRbiFIeJkWT2fSX5Fw0TZIlOo4n+Uv9rxCsToCLTDSkoy4EE/8UJa7
gjgYM7DeR6+NzbO50tJlkT1wmPG4A8AON4j/jeZHg8LBn7u8MO9HNIBFrHrQYTftwOwgbfTG3M/2
oNAj5YSkge/rkGRrjuuC2Qn/UQ5d3pqIs9p5VSmRJfhPir2LVPXU8MBZLf95D0sjxVyMSblFkRzN
J1cTjQ1Db9fVbYk5856gbvksLBaKOj93i1innkuhil8vq4h2XxcURvXapxt+4ej5Stye3JH41L0Z
wpVFr5f/aqXf3coGpiZOSfK17bH9qouzCEvvOkVMiAfojjzSQHJexhyvl7pExUWX3Rt+eJHX575f
w7Zv9e+GyVPY8MbzR1D5jfLiwPOB9Mp38GTCeYsBNXDLv5v2qF2nH+NO0W12K6Z5qmmSAo4l3COB
THGqOf5uMX9yINGZ0W4N1quwDSaJI2CAqNdiy4mrVlsbZypdPNigBiSwipRmoB3AYd3uqSIg2xNw
8PDNNuNKWS/d3RaRAugjAXDsCx/su1PXumMVs0/PScM4GanDSzoHl4JDqammYiprIs2IUP4XwUqh
X88nzXfDosKh3W0OrfPmUAGgeRi0ffsRjUI8zQwrtnxs+Asit2uaLTDxXwOT05x35vrVCuwVIpLJ
VdEOKyRZzuJFY+BUUAs9tEhs4EKbkW1RlsVJscVHnmU4DoWzugidhaIBrKivdDXlO7kpFTfmvwoI
TsRYVDfYjNbjX4FRf47ojenZ4jDsKOJ9HSs8JYKs8p6lorWHc3LBDiUopRGg44ydjl9P2U7PNn8R
LMaCVnvRUlT+OPYIS2OK+8Ma/Tg61oDG0INz2FXMvRhE7I+WY2JiCRLjLDof+E3wtChKCs7/EQsr
KQ1hCvpaQHEvPEC2fMwpqi1CeC76pc9XdQ7DoUnbOP50XXv+7zSo4QWxvt4WUxL9GH+FeMBiFdTw
gCNNKS/WnnIhWzEWzTyQeqezf1LMiLJug4aHqrV9l7C1uPFGaDCoXo+JTO6gkY1Q2QfIpL9USnZO
vk6qu8LGA/X2SKRTMW4KiqVsBiQ4xVBZdDh0vEXHakmo5Ap88jWqD806YMkg2+fPNNxKOXyZjcws
MMIldoIpRlzzHjNvijn7fTKnvAl6UDKFdO1tIJ8xTVltG40h4Gg2fsKSwwyqYBMZOV/lfvy2E0PZ
pma4k97ywgF2v3L2m9hux1MRIRjv6XT91mi1613NwyekMqBgmuS5IFCr1v3J973xhBZXY4xIq7sn
rjUKcYJFUM35VuD7OsWhSITRtsLHOeEHwls5i3hQpz2BjxjeK0gZNqpvtOYXdZIuVdUk9L3nRo7B
0m3HlBj7tj+NlbZZ1XuMd/FrInQ+LHFj1nrsQn3DGZF0hzirIKF3EFe7LYw9+f5+C+NA2jcNojs1
2fkx8er1SyYLSIt6JQs3+RocjAAy27QYHDctz/1ME9xMDijI50uqIRDqMwS4+kQBDQa2/AdE50hx
2SmG6gmiWUrKLfxpf9fnb+r0SVo6Sq4R7WHjXxVBNCoDuBLQnfOw9NNmexOGfutT633X4/P7jz8u
JwLOM3Om09MuhdT0kXsm+hgzL+C7A7CjMnQuvQ1FawXk9aMp4CdXbGD7BzGVsJWP1LMoHQYPqMaq
mdpw7l/04Pt6ca76RGdRrSms4AATaccOlqkl2VbPvj6DNjsgWMf83f2Y4UohccQwNMrcBRULk1b9
oPxv+8CuYOZRJWbJZ8XBqyihA4grqWSDxJbS+tGWQN+5WLdovxyGsTlfBkFGoTOPJ2Q2xItJOhJy
8m9TejcF61txxcoJax9ZyRNvKhjdfIkc8p5azgmrXVL2MZsmFN/dJPTRFIP/c6bVshrbTLCEN/yj
6ArkAtsuUPUcyBB73dDYcAZaJgT2I1SrS6ssvAZH26O2xuk6uMlrWhd42RqeqlMNH6RiZUSr/gmS
Sw1xR+sdHiv5M4zqZH8Un7XR1oiK20C4dWQ0jrvBnSMjPRTRN8nla6j9k/As1iVyDD2n+SsElTBQ
nwWsKyS6Gije9miJ3A0HW7mm8u0mwRWgTcdOa/Xs4zuexCEMwwtNfycIgXU6KzitDEb1FXGD5bly
mYfsh5JXUsnYUXiiLTmjO5oShes/qaMw9zbIegG5OFKsMi/huqco8/hx+Htn/TdstRP1BahcGoFj
s8qOCWumTJ+IkHLEdUjPFSm8IQUsEngvoJKSsYuIhnA8sDfqxtkP5X1tVhbJv15rK6+l+Noevh6B
JWy6VfQWHbd6T1Cbr4UOWwdhVIc7uH2A+M9sxJJpb0CJAJgkKcR4j5U5LS1pTPsDRa8RHZd6/Rjh
/HdLhTaI3+mtOihbntkjgoyhaw8rNdRWbOZkOjEF1FpY3vU2ZuAWM7fL0bJ8uiXjfvHpTUHbk89o
Fng3MYqIua7D/jnAXz2inTLmmXMl5zLLJ6GTG0Vc1b7HcaO60GXh3TmcppTg9XjW6PeYxhBug1al
IaYLjq0C/jnAvzlWYiql6eeFW5v1LM/MSaDShgcXBhz1T8ljArSOfgKO3CnI59vAGdlSnhjUq3Hh
quyF2MliUjsKMGGmZmVSs1nWwfR7ueM761YsUbP16WV44XggQXjXKS0qbhHInzsNP8e9/wOLHiht
cWMg2KM9t4WnX2CHl3D72iM/ewOoTU3lUfgqY5d6VsKUfwXTm0D5fOXkt61LDpr0QMwh9w+78sAe
fF0wCWFgG/ohdVijTWjl3+FG5eoVJVSeVbRhj3ZVozVW+hFpieJtoHfsekO93jd7kapmNoEWO4ib
co8VQ+6vlIDgXz0bHo6/cHc2+o3aQ7UIi7C66J7hVC3xFwm/Cce37Ot3tQ0dP5TiwNhK9xfxO5/X
e5fOrNP4Qe4bG25uRe6onKfESaGj7aTR/6AR7bhCc92J9/ZSRHAcd8A6w3fRm42rd2MOflQFVGAQ
Gg5u4AscnIpCqbIFjKUZhNLpno7NzZZ/2Noiht6fnnI0CEkrJQsDSvIzsHoTG/N4PAIm1h+2o4Hd
0p9qp2TwJ8s3Ddh8z3OkJv3pThSSyodD50PBAHH2cIjH8iunW5I471k8kRS8Yd7qL93oCySgVpbh
4o3WN8VFMs/0OlE6vEmRwe8ofJPF3UDCsb4aM2fjIvspKKIFIBuSg7IQO0c4geUUAGTzXizasTGY
b/DJYAiTOIPG6oTs9OUrpMreI93BvhwDaIBdysFPBZWkiJisoTnr9oYvZvCCJZjsf9DWcMYvoAbm
jyRYHvO0w+2qhOlyLxVpXrUnrGfND+TPsOLRjVKkK05F7vlBo1fUSpKHBjKhQvOry52+NDFytOPn
Na3Fp9eFik4izPX5jZIfAr/fr1r7fnZaqBj46BhOqsAFxbEPE7glvt3NL0kWmAyafYk/O1lEDVvf
CDKtSPu/0E0BEHvg3HfN0h0Zinmp762GEjiCJGmdMc5z03gsPoLH+LWbheET2KDsOxnNDettBYJ+
xIS0qCHaEzNrZFQIEHjEJ6JilLURZJWK85FuVqCnZYUOlq1JbcxeUZ6ehSjXQ2J5ncTkJZiRW+bF
dqfz+qNNMtknetB7XeW758GQ3fLebFqbTeQ715TIN526mqOid4bMArHz2orXUQ6kzdmYcg1RIdNV
y+4j4q/OGorECqA0z5MOZYr27zujVZgGTlz5/wWhZP3l99+JgR3+sIcOER2sNvf9A/MN6a+x7JYu
7Y5QqhEf5HpgIo0q97Qs7eK0Wrgyrh/xIGbkZkgXmKG6yHjL5u8Aq8/TK9dEMRhkR6O909nQ9KEM
8hHpCz6Wib3Av58/+Ve7PC0408W3Lwf89TE03P7z0aXMgi9wsdFfj8O7TpT9n7yF1gDV47H2Olon
CT7uChG2Ii7oWdlPfMKbCzJ0lzBN0SwxPl40tw3aTdEbRAENfXSZQBIdn1ezEEYNCr/pCYcZOnOx
NZ0OAUXHEPZFLkEkdb5PNg8T9GaDPFZnTfPEAaH/bBsZR/8IClenzQ0XNa08A0tJXMv50qdrMcV/
0UtWlJdrnpTgt3breNrfZop+h1jWEZ2O13VmCSwmxmqTR9iC0dNIfWArYhlUxfAhZldb+Nx1srXn
gXY/iAuUCdRSkUMWN0/b4WYjnOFQUSRkvVItVZRmbcYpJVpBQNzBSd/GL87G13loGsOc1yup46qs
0blvJ50Cz1enhbdg/sOaqd/6b/oNuXV0qymLtcxi1TiA0JylYQaLmepmGUokaWeOdcYqfvDA79N6
116magHBTqU6Zu8o+JQS/ZFmKhdlX+rvApjs+85s04T3CROQ4MAPy4fYl9rmPn44k6xYn1rhK7Zn
Zo8SmKtuYLnhnu9jL3Qffj22ke96otJmgd1pMVyhL9ihJMXpdPWoh21GkYdaNg4WddpOLUUh5pMy
iCvTA4l3pmxEDvYu+YXfyeSfhy99gJAG+NNsDrMNNvXqgR7Km6lyG14ojEsMG+NCXGR+XPE4JhZv
cvSNRcFoYjAAL4gYvDoV0iljB2jxDaQFOu/Y5WdwQsYWtTgdB1xCf1CJCaNLjaK8+X30fA2ZNQPH
eCEmu12UlxauJCqhTYuxjAeh8MhmXpQF/T2/FzZp+maSpc0NOmKk3asmJSplRkVuqlypkF75uexV
Q3EuVn1mGl7VcflrHq8AO/J+32qa7OKgcI2hYCre1aGK7B7JqfmWefd+M/6FZUCNcby9ynzbwbbE
+6x5DeJxCsxDlfQVLAbsoFLswCzC2WAqmk1qvUgHUWcGYPs9QS7COp/AvNn7jkzrAW32yoeRM9pc
6Y42S75cb94G44Gouw26YsEjGxB0Nb0dxBbDAfhiSfS2B7nm77Bs2oEUEQy4Z6klO2Me2ccyAqFL
lLs15t3yY3eQHjcVkWVYKkrSsDJgs6QSyeIbZzcsKGBa2PXvw/tRVtm6v0KBZfQBgfI4db98VV+b
8U8znVhcERh2XzsE7wi3xkGvgICv7p6LXlSmlXvcfMqzIwv0S64cXa+szzQ6xtuYV4cWl6/qugZ2
0prZBIOrS4S/UVGoPSuzypU2na0+ZXPn1X3hIuD2bIc4frpjCWPwuMmUK7kXPNXJLfDG/1lb1ytu
pQ+aQOjPf3hrzt8BTrRFXA9TALjCA7sp5Dikntw+BXxGXNEMwP8HW4FL/UcvB0q8MeLutmn/ODzW
WPcXgPpdCqcVMNOt+orlZxDG5yrTi2mY3zU61KP2/8DEytFdStIQiumSFY+W48R0NJ+zYNTVUi1U
c6yJfYr0Y3Ju/HWpQs6G4kEyz4rQdGWdgE68wTOJ7U+dNAU3JUw/XjeuJMmQal0aOwuKDXgiAR7U
3mDaYTl3DzBvJwzrEmYmAMd8vXPTiGhBDEkTmVYA4y56/y7OxghL5J9AKrX2/1/14cmOgRO4pPKQ
QsWVFX/D0V+GJH0VjwuYm4d4pAf4Su3HKCDk7KMeFS6f431F9TlPWgozuax1qHtgYYTZnAyXCRmt
n1b+6XvbX0cmKrS7OdwbQp2y4gjTr2cNpvwCVn2XEn4Jhja2NJgoSCF8L7xflog+QrRe8PZTY7WC
c4s88rcqHeOKyauq6G5MN1UgT67pb/sMWm/hoRgn86VKcGCffFIqB/l7IIuPp82ZZqHuV344By+V
+PCCMYo3Zmxx4abbgtzUbSo+fyRnfUUDtz8bEdyRGsBNifuaART3hXGKaXA9tCJvDpD4egkX0uvs
/QD1OOW18D98UmhJzk09/v0hqQIzfVHYkTSsMFmZutMpGL87S3Jts8EN+7CUfrk6qShpiS2TWTqa
9+yFocD0NB8jZdSS85sWwq1y6y4OtQqslrF7j4EjEJdmnW259qeM7FfHrj2YvXGwbqXv4UKn2dSV
IVpw64iFbhMvnh0hPcKu3Iv1DQXKur+jn25Uv3PSr6MghcI7oLA1NTtpVWkr0LksvTe/j9nlc1gW
0FO5D+X8R3NTi0/mp+tmcbJm1p53tzrcj7Up+rfj4XKAD7uadFxUoQrASZtrgWBhq9y8TIx2yTxq
AOJS6GyteTl5JneiOJAOVFZCStzpOWNgAvWv8G2jLSTOTUzTBPjzIX3JoCs49k2QoAoYIQiIaY1d
3ABjwNkxH7gU57W0Bml//K6/QUn7Pi1cEWrvh9okN2hJbwydrT/qpvfcNQVIkSs1T4N7Q3GQCQ/t
4la5/iH3yTJTFaTZylA07p5CrmhR/qy273BuwGUOZH5l+y8oVc4gVNpa8/ddBrlVg1UbQ2TqMQUW
JrLQM44o9rzgOMwTgsq0Vt1QkaOUrzS7Rh9fp+FF2RqnwTmqIYYLVJ+NTZLc7B427Z/j6Yps5sOu
oolmhdRE3/LK4vBHrZhG4ZikToT7YBHyWwi5Hj7V8oRsiJhW1ImFl84RCDT+03jfTMNK+jSQhl+m
niIg9zf2SG+djt/sY87qK9CYl2XfnuUBFXI+5Um+lkDfcMN9tDlkhlCjEf/AyQueXOKMTICHQPR+
P6LIyAiUZUj5kS7hrQyGVbbjNuoR/9QTv7/wk+uhWp8Uw7Gzw+maqD90qTCiLO/NE66czwn2ar1W
ZI1hA9WIABcohj4OCIUtUtepL+Sbxqt0IS0gUQrlN0irJNDtGn99rp68+hhURWOhszsTaKeYzXHL
u/KMaW5ELOWB3jkpvbXNtAQiDm34nIP7DB4w5V0obXUQdc4W39TzzovWFHYpSTr/0Z8NdMx1Rr6x
x4d6qO0VX1IO+wAmlLthTG==