<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPyYwtlIP4oFx0tvBrratFMB0QyT1zr3PciH7uai6p0jCKRVSFSLtvsrtLQA5J332jlUzE+8k
sPNOzAdVceBxDjl4qCSg7Xx4OWx8yj5KlLK+P+DutVPPrK2BMBal07EWGIsUbwEyUB/8UdunQhdx
WkGXV2utBVESqf7x1I/x0mMF8y29Q/lmj0mn6vpo4/1SZYd4YOW0HnTteGTO8RbP2h1Ik2Px2Plv
09rMCeTEdHmJGfgWyUoU1IJJNNzq7PWaxIrdTtXxPZDVtcxcTngcFvX3Z+cEIdVEvaq7Q8/srfT4
DO4CRWHoZhh++mRrjuuC2Qn/UQ5d3pqIs9mbV7jInr0EmP+Nb29UQTINPCx7NVn+L8r7Wa2cEOI3
VUeQkWTxDHxdvcFKicz/AdO+27qFMEDxVu9/40nUNFg38jXxmwg4lVENR8Pk+z2nlGs9LU4cAo7+
hYKh53UJZUrNYnY8ba1anme/u5B7mcTaMsNAWWIn8k3U9biSo6+jtPLFRjj/6FpX91Ha4Gg8p6x2
1JPMULDbRuluvcls5udLaqASok8KGOZ2Abg8jcuuWaOsAuMOW8B6cm32AN6GNXTb4HaCGqAyQ9lA
JBPerNx0jAFyThj74lQtg8Q1s9evsOJAAJ3L0zrlyOyuWcQ3QfdHwZPL9TG5Xvp9zJdhVNZofGmD
PoCLd+IqEiBmS1Wx26v/vMzdT8umfkI1HT3c3W0BzAHaAnpc8BKp4fesmJD/YyIm6Eo+M/ohBTXe
9gvJ3R1nUhHWZDN+GFIWrE6H51kHKLwu3MZfNX/ZcR9nM7NSTA8CYw9RJVEMauo6z9eZSBdLHDbv
Tl786/pAbcsgvYjfdom92gvTyVfmX/PHYlqx0rhdbTddg69gyv/H5t+HQDuwakJO54OeyV09T8se
8nE1NoxYL3vXymHFg6z7tMVLyKlupASSQFnC448WgdvpShb59lqIVajZ7Kh35g7LhMvIeOADJdEE
8IfbRYxR+Zz+ZORcqsZfJ6EVJ9gfrZY+5BQKSnhGMSw7kwFhlib8jJ33IpNDcA6WI7fYYhynt4Z6
rCyDcIGf/6gJ657gCzsCtehuTrlndW2gtCnuO509vtNdMp51srDGu2atLJYFs36PLn1+iYxvzz4c
Sqo6O0K/yIXbhXycIvJjrb0n1vWncf6ieOSvHBBtPK8go5cQUK+SCdtU/KhM0JUx0stpfs8IvCGK
vaV6trLiQbJrB77wPqpajSkIv6PEsEH37WX9AaOOCJiEHjAxqwfb4t1KpsOOfOS9bEswTnZYqVtK
lW+4mjfFtxh2MfL89Wkc4Yip5NxXJ2G4JeqAAiWthKGrWqSGQ+I8lk0svmOETHt/6R9ExlhgTuZ9
p6XIPPEAY+8XbwRlB8Fa152xc/nQMB9p5Won8v2oq3PD9YCnPwwMyIFoPvT36owZFNLMX+jl0e+/
vP5w1iwFr7+CTqvpnU0B0vSNr/pUvhLPcSOULxELCQxgqMP3OYdUw2BwgtDtZB+X2MedwwXAXWCO
n1mHdvQoZx8s+3Q7jsINzcqBjSokYtexvtHfA/M3Otn/pz8lTgoSl896M51zf77MysMmU6ljXvB3
twnd0ODRWGT4cJrmJ53D87GIk9Dq+X9Zdi/g81BfCzg4VbLjf20LZRYR+6KKQmY5fxm3s3UWT+jq
MR3sscsx88tIl1ZFFpdkVEJszo6VbUi8I6iLiTyoSljqCONcjN0u2bexc4Csf5ppFOXpHNrmeE9s
/nFSMoQC19ShhrUnd3BvQc3risPZ+gzGxKvCZCEhb20vpxcN7/PZhPhwBTBEOACP+9AVBdRwXpqa
AXKxaKbpxhu3zAVENJWigrlUCGF3YIEDxvXylo0m9xp8wo70vK1IUXG7St3N9PZws52nKGoT4APx
qaI1uMDYXtwhS7P6dL1ar1hKNtaRhDAiEbnos/bOAyTmXrLLQy91emBglPvf7Er4mF/9OYzBlEBQ
UT1/Ng5wgx16ujjz+jfPunhdnwcjUVrjaDd8cmFS/cIrg7igWEC/ObDl1zGXdt8zns+C/OqkFIUE
YM+2xXgZbgEDJWHNq5qmLA+rIg5a6y0hpO5OkmDA8maFOzJOLZAObRj3DH2Hpu54yvrE2ki4DGe2
PiyOuIreyNXt2an7KLbbLooSiFwg+nVWxy1HYOyOxkEJptXr2FOBWTQZqFqR2/U3QJAqT0jcX+bs
cWX1SL3xxlMVsilazOb0Ow467XI3TZk/N9fFGdA3/WPk8E7kQ1mY4cysY7CN8YG6QEjb9DTLh/JF
Vg3MZ/na+gpz7b6EYTiIkOyPtjlr7MMzAKcz7bUwC7YJcXutQDoS/+0g66I1aVMvD/hYMfOuZO3D
cMV//2KDml+QWCvav+B44SIqIz1E9U/erFp3oONe2LX46QzTiAHgPRWtVX88sw4Pc5BhnXoi9idM
6s3aSW5Vag00/MmW/FtC0NPOak1Yo98nb0kQcBkx4/lmdJzpiykGg2EYuTs/gSJTRePANZsqmu6w
q1hJwy+tUdxj+CQZoj1e3va9J0ZXYVBU8T32Pj4uncPBj2Jsa//4r0LLi/4oBmar1xYksFZseHxh
YMtBizVsSsazJyyp45u49yJQ7zEugHoa2jKWy19FfGq4IDYTOWbk2WRzaeB76D5HX6McEgIPW5MB
d41bMwoBMmFvrTC9qUcQW0eInMQ0oYPfCfQPClMWFQO7mYEQVW2orqAW8lh0Mf9A7WkNS0FAEnYY
M5/P1dm6hZ39rHLcYeFwHdnTa5bWrcAEv6qQjnysTmYKJVm7/t+IXxTrqFdieHazDtb7QVUGtGpy
QJVeSKp+ZRBkPWO8jmdBtxRt/A0t+GIjd+UsLuWEgqEIAzSI52T5SO41VjbojiYrAeipTEGcl2Qa
foSzjtzrQv4xRZDWHBRfq1mJVcBpRa4VwGsL3QF7cnTL+DMjE5CHAnWRbSZPLtrOVxmK9A+cBk3z
s8xhCNhsNjA/oCge2zvc0SUcknHA7Phd8ejuaDpMd/QPSqJ+xPcz1bYQ96r3lnoY1qw4TM5GxPoI
fqy5hCzqnKIvs/z8A7SXcJjF/JNkhlM3py1q1mCwP6KvG6NRBc8kD8epS1czAKyM9uosnKWVT9pQ
BkTytbyf26d/LHMmKQBG/dCpcym82P3Rgjf6dECot3qjBY+eA0947jkQrcq0D8uCIFNyFOTdmWhJ
jKnGqfPKkSD31P6cd5ed2l3lD3cgQWIirsWAQs3Rrwn3H4Z2YbvlCvsq7KVlKywXxXE9xnXnJPAQ
/cxgyQB+kWY7N77ufPv3THCR6NuWSUndJWtI+8rIE3uguqsOINHRsEEJakcm7OhlkWcLmiG/y8S8
rzj4FfMO9di2DUIcYYUeQMwHVJ/x3a68sn6Be8WRIFqK6+1d+hRCqmDcQba2TC0R1YKjkPD/8db2
hJrR+LTyxYjZCGHDk7u+K28OXy61s55/KUQhMNk7AR8cJu6Z14W1NxfGi1EBHkiuVjwN2dNv5hvp
Bq/Aqp+SBEz0HxDwlr6ZqaNW4TjQQO86ISUMz9AkhKTTHGsUku+t4L0IdFHCKmKpGvnebJk4xags
kFCj9EBE9uJAdXGrMskthIMgHOyHkwLMVkJL+e4SZVZO5fj3i+fhatUJrOsMloPeI9PdZcqCiSjY
V6QsZHiFU2rfOa1r3wMnKoiwLdOe4l4IMjIIIR5GkXR6tBhDkeryIfwNK3YptQmaYzUH21Bl+NB6
E84s+6dsXrYc9YAAVHlZ2qSXsUYL3GrfUs2KpTvobm6gFV5PTRwtE6iKnbbLLunpsKm0N1dODCIz
IJ1F6mZoynmVhCXTbc/eNZI9euObmHRZ+yznZb22oitRiXEjdAgvWI7661ssxwf1FPIcjPz/6LlW
CKuet8a5dg0Js7Wwiqm2sUgkFr+iF+o1yILb0zVkSukwLFbMrkk8jt25UHfcQZbpzMp8dqn+zKGK
maYfm/MouHBg9Qb8Edd1BoXRZZP71GNAUFN2n9UDW1IXlQd3w/WskQdV564h9RA57fseUmec7ZeS
A/HdhJNncwnCNSch4A3RAHXx+cK4HZgJfhatshyO3HNzfjzUt5r/55IR54GZsJ//HqiWEYH9Rr8O
s7d3FUJ4w8yglb8QJhTlEWeT6l6n4w+PNaW9FKBzKLPHw429XVyXXAr5HN92yHL2z4u8+ONoIbSZ
RKifc2iztdalUV+xMNDVygtCRCAp2VOAgVxC2zAB7jMriJcq5cOuqkRssmLF4sHrj4obKTtkyknz
bJSclFmthdAaMedDfxxQIe6Y36Dey+4Gr+ueY/LB41BMorxdl/yn3hUI3XvrWyfXJQSGCgsYbL/e
5rx9vsH6qYp8ZjQzzArGCbS4KeSE7mr/IIn5UkcIv8O2ZeU6HO4r6Si4GQNrzDR5wTpYxQe/ESl3
LTYYSykz9U+Hx+Lac56U8uNQ96RND+dTa0W6YpORZiDbLjeLaI45ZfwMaQelLFCgk9b1m2hTLK10
386FRXEHn9upjSeEmBvbG3PNOfM3TqEOe13/Hi/IwTfuq+5KcgU4jihq68sUixDcx+sy/0h1w1jo
QMoeM1OhKuDF1drdgzYmmI2R+BlqEW7KW7wAV9YR8O9CbuDeDTwFGufYoOjuw7F2Y/laXMCfMTIJ
IkV7P971NmpMm+l+gRcYeZ3C2oyeyugTaqLmzmwc28rbY6ydXMEy1yEVvjtNmVDf/rFRU00fvDmt
6WEtBYhgwSWXE4RFemDTaK2e5F3ziEC6PsZKo66IwjRhCVn1KAlMERu82oyiW82vnMIH2vTrMcHP
j7BTsEXH8LXUTCuNZ8zJMd8VCtYKTDCMl+q10sPw0Mjx78HhL6XXIoEc6YNvlrLVKzlwIzC3bQTc
wkdMN1uP0ueGqhQrmlmZcPvHfrkj1K/MNfjMaYpQ0h8odsQdclMLGifWO8zLoz1drqjGZ26z3+HV
Nkwmrtsv7GN+XF6DBSGiM0F20MOUjsskZ4xBtFlHCw67opLy/YGa3ILtz6ck8CSloZT9VarJOmtU
8Ord9tldMq0+NG9kOGbdvVUyizZ3Z0Oz8uWPmSk/C1K3BJMZVfupskUdZ9lZ4g+9bc3yAYs2FJy3
iZ6RFUK5n5AbHkjBKo4oIvfx/vcs5/MXtzRktHK9zSDbuNWR1Q9KRaE+cMsjKEsDJtpjw/i+TA9j
C3Se2w1/vOPgA1IgixNZrn4I8ex4UusWPVgKWv04MI9upe6zhK9umJjikNY7/dtCfgpoREJqNP2Z
4AUUA5pLjUZStMaZz0wTYfPTLMJCCS/JmggWHJXF4PSUAvvxN2XM2XVahsx/Sxq4PCwBxy1T5Nt0
BZEUIESQyxBkhF986kBpNoJmUCEGi11x8knppeZ/vYyQjrJuIQZuWc4TXaq5f+oaiBv37Q8MVZH0
dONzSFLrvjhnSFTGp1rWehIae82TiSLxYj5QkrGrC8pHL+8Jzktkhl1IphB0Qu4v6cnuN3Vv5MFh
HeFFacTjIzQQcnxtEoR5ZKPiMCIAjSlv8XsCQI/Sj6vlM4LQ3H7xiyKjeC3hxdzHlht+qZBAjLyV
krFMVEYq4T+plGSAnvhNA5Foi9c3iTjFKXWS9DvCJgjQZDI8Jl2e4VkvFTcimvAZp3tDKATrh7zz
l6anuS+jFdTlvavCp/zbqIcyv1M9Bvbx9eyqTvILk4iEnmmTli922w9EUV3iyupK+oqR/u3+gHJC
PcfuBepJG1KbdngdRW4sMWg/vEPFlULfRMKBIdK2rRHbtdkCbCxiKmqfM7L26YuLyyDHc3hhBtHs
INi+bh4zaiCtvHrFyIe0lRPYDvFr+wWF5SPoMF1jfn5/9ZIJuoz9xR9Uzl3TCaj740C7XW5JyXM9
vgnYaJ4Z7qTLVJYBdXGuUj8iQsy8jX+sjCa3fxacC1Pr+K9ftT8tQkjomPXaKmZY/cMd2cyqjZkH
aFfOqJ4PCA8QSMRRixvIA4KX0d/zo3jMnw7flAXrBTmcwuZZ/A1v7RfF/9hyY5jr1pPdUGKr4XDV
RqjbAek+gibmT9m4aYupVFnyu0CSWUJET/h3rd/obrAN57WUbg6PjILb3d4Hg/VT1DJY6kmHmES+
ErUxB25LKlSdc4eWTJDEyjQrpXHLBxCwwpU2zGgvNgYxrbX42ebS4B1DA8SujcmZ4v9zqthxfGCG
ROfv8y1eiHabrakM9WK8EdAfpOCn+kvmPTLm1UegvDWFutOYKuU8HWdTGoQ/hiERlKoHmYcO1ak8
/YRpu/N5r72eTCX4V2lJf1J0uGhjREK7gVYzSTVOLPaL4aU2PflAdD8zR9vknwQYw3qB3Gtf7Zbg
DBHrDzz7pKZKfyzkCzfBbXRAWj/TpyzsZpyvD4hn/8tRHwjg7y5x9YJ+M7DlWog0w0v0BsfUNO+1
6uhUbggdSxLcZX8l7o4lS/36mrTHgO5rio4Zh8a7tb3MJDw5tZRN5Z1+nk5NhHtpl24f9Owtu41Y
zb48bb+vAjFBXj+iCns0rgJNp+bwOrgLnA2Cbb+QMcn4vzgnZNAnjP/xO7m=