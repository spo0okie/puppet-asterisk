<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPnCOy7mziCXpNzvbNrLKC7yGiPawhME6LF4EpAVLlupeAuQoWhEN/uk/q5OePko2KKV4JA7Z
vWkrSANMMKtzxb8o3W63AuQ9mODxPqc5XHk8T+9IkZKsg7e+O4HCgoLXY+fv8Tu3HXCXpAA81qiA
eXXbFKq5zZ9Bzy/q5xGMbr7fBr8BmgLFdnxxr3EQOc/6UDyUU0YlCxtIWYufqfRify8RcLg+0F5c
0F70Wqct1x+tG6XDjqjTdUYiWU/niUyrXrFYbABXEnd78DogITb+1NgwGEtRW7JKIXevtH15TrXj
pniNpskHn83GcWRrjuuC2Qn/UQ5d3pqIs9nXUfRumVD95E3fsSmEN3EVR4DaqMlSICOlQEfvdMck
+In32Kj5zAGsGc6uVL0VJ2OH6MWRGYRjunB6qCqMQQ7rowsd3+5frjBk3OhREl9QsXmGd+vTZ6TJ
StKx5E6p1+9GtsNL/fcnaO8NWEXQREbOS9xxsnvx7LQUsoBK9KdNRvkYjfcydTKSei0rMJYFIN9s
eu4DMNuJ9ZQX5dSs7xRybnwJyX/FXFByPkNDGrr9WhqOnooBUBE9rliLUzIuG7PMHyLY8EuHqqea
tmQJlMmJwGzNCF29kxGdzIDd4n4GesSPw8miS3Cp+nSiTbmX4kIgpi/71ZqVKgql4MHkpFEGg4DP
bExJKOLw9/exTttbQ0hZvAu5nB36lCz2/msFM31YbIZl7n4iEiBtS0lbaCuFqKsH7d3C4bl6Rxcc
H+S9EVYNfrjQ85Tmv48r0wNwPSYgOA2naMGPksXa3lwiGmRGoxHvjRXqzjSk439x4Yv/1Io/PEC+
rl+hZwnhIln0MjmC8H4kyd15Qs0+i8DwnrvYYEXkfINN6M1qc7tcr9b31Ac18kXa9t+Bs3adlb+j
16Ey2we14UCkF+OAJW3B+lmLDbVZ3UAF9H+9qj5CzLtFhPtAUpS1vNaAuIT0P5dyHCXjP7cB+SXf
aMejsTNcVV1x1RqetpLKrJJcuw/QR/HMhaDKLvTMEG3voFFGeMScdXbMwfsFrwy8NmTPm3Z/LUc7
oS4iZCoKRys50GdSwCoS2wo7m0LVnyh/u/j5Q+IJFhfy5TqKlf71HaRNlyWWRKS5GAxtcZzIk/ln
SIhcfX/Mi+iI3qMbHggTpcE5uZRz3a0UTAomAZKHMZ19/wlRkq9feL4lppW+IrNrsY+LLeZJ9+DY
hy0qnbbSgnLu2be8PuJUuIv5LKFnsLEuDs8d4rYPYl5WM2K7C83Ajp1SKK94u5rMz4HtCJgmZNPK
Iz2DK5WC3XYg4C36CThqxM4akWUSgVFTXckk3RdFYeXIK+dhcmk4HFZJPkmY+7KI41eCuMqdPa8W
yr6TG8KOjDj8/5NnOcg354MitexHh6nnU/yDO3IHVyRbYKkVE/zwfnk8c7K/x6KvxAp0i0z8SxmS
h0dqeTtZ3R9I+6ijByhauLWoVRu/+Jqq5Spjy/DV8tZauQA2JsvuMWHziqHc9AXeMDqLPasyEFHH
liH9ZEw6xrXUCKySz1+GcqjjIHg0r8AZwPMQm8wmmQP+VOBOKTXM56rikuCY2VQ2pjovJAsraVst
WoaoclIQWAhb1gkn7vGfa5D/Oej7Lxd7fWc2u5d0Vi2Fy1Yn37HaQ4i3V+hN6eeD+cu2w9rjhx5R
i+lH8nfh5PgRdSE1Wo2cqIiuE0cBN+NIQF2Dv83eC9U0u4yEbQXYPfUX0FfvM1OtpCNZBc4ITkpS
G+dl/NO0MSfn1QE+ZQj1h11HsQxP3cgzUXZ2FMrzSfhwZvGrFerXTBeR615ipAfKkqg4BtGEqmQA
XU+Jfe9SL0AXoF/CHHlV3R5R7BfzWJy8sEKi+PE+lpxFSQYKj5W5+yMhIQs53SK3PC+ii8Tlrl9f
RloIhMg8y8T0R6OcArMp/b8am7Hz5y1ATNU6wGlkmAxd8ByFM1oWBQ96x+jBZ7ua/730SOrjHCqf
qi47z6CD3R+UNIJg9bM0J0/+sr30jT9rhUtqkftpKHi2sfv+bpy7PqVgNEZdXhVzzLp/fiFmo5+D
NUnV9iElQcHKm/gIaiONJ5rgGreFHQgyUto9tW7/rjTx4+4fnXiJ4Z47SnoHgMI6lYBM7VefJBPL
YnxlKIbfMHRqEWGEDm8AN10EXRtDOiv1SfxBQFdO1gK7pm6Aq65Xleq7Lm35gnv/NIwSNigix0Dy
8GwMEYPs89jsCyeY+dfSYDTvypqwG7jKahSilRSoEXT3heHfstbV+/d9kgrRlpCJreLToQTB8GxE
RIgTQDkAbyBJswvqW8r5QwiJKJ7JMKY79ntW7Ck/7PLCmDFlTcJ1JWWAURUN+YxDWjHtJUJ1EWwz
oI7Z2AP7zFPEJy1m1tkq0DqNGeVH0PKr4ryVt4OfGg5H541kUTfPLdYaJ0DXi3C7z2PwGdQnSNb1
D/z36jOl09A1ThUcpjzxRyYfI13SxTovLYeVf7Z2TAdcSivk3wrVpjHfAtl/L7Vh/Fpznk0S6PDi
ALdG69MUH3VfKHLIMhtSiPYTyuv4n1oCDPYhWVVsnXyI5eNEA9R4Gbi5CfD9C3AuQnPQptu1Oc+z
dVuTtn9qP+c+eCQnuA95zrBYnWdb4L1DqolZZzYtNv/a8N2/vtljVOnsECYPdswGzuDVEKf/WmVd
uDEFSBPYzIkQ2LLEMOd105bDxtOFTwwzZbG8XRzWhQSP7Y+O6cizznP5g9D8BKmAFrjWphF3OIDQ
HA4FfSVucwOLDH2hEBWi7ewvcPZyR6bV5fkjSla4/xu3r16yJpNNYj3eTb8b8jTNG4vw0RFgN26p
lC65My8m+UJJU/4REutjUtLb39vk+KEuQ8s+eoRqtaqsDSqbDZvBC+LyrUM7XsT8muTjbWHSUOtq
FsrIs1izPynyeHxAvsYsqZugK0sVbKUyp7GsjHhZI+1bvlyI5h96TjzFh0q+9pMISvMiPuAApMrQ
J4ZGb4cG2CyMpI4amik6lPw6zjWQjSDOTi3wVrylG7hfWyIkEHwoZHQi8djVYgr/on4Xf5nS/dS8
X+jlpfVdxbsloNvyVIeSmBxWi7eRrK4kyN0S9q3TDdkBwbtUnmWgDor+1VdYTVRz8xckmvkNBlT9
Q611YMIcFVc2Fa3mG25QyADktuj26IBYB4Ad+1HZ5mcNZzDkxiqUbzOs+8k4f2tHsrS8frgNobGP
UsZFtbJCd/wZCTc0aK+mAuElA00mxFV6Y6cWNKxhMHYNykyergpiim2gpKCI69h2ZzT/Dr3Pscr2
XeTePAmWnOi4d6mgN0BZW7hezGouykFnuIqqOqSHwkyewmlN56GqeNLHtxRT+SQG29npNQZ+cO2H
Zo3ke2Van0Z7444xesAukfsgbVUZ8eQLWTBmE7wwrGBLJ/JQ0suL2SzRVjhea0X+AFGkudshiR1I
2L8zsbmYikQabq7xa3JYKsl6146FrmGC5XyhYvrS+3V+Fwzz9F/6dF4M3wAVj5qtp/0PJmivcHLf
EqXenULN4A17XAUaxfaVZNUSpPHmFI6MB/elmdX9YR/gQXbeSng57cpyQFVxyINqD5XdVicpkO7z
ixuBsP3uk8pkVMCg4S3yHLlfgIKrceSnUJAGmUY1Rs5cDZAyDoD1RtrJlQ1jXPC4bgAhcmTvQVBX
qc799SwyhtJAT0GQmQWRh/wtCZ+5gNTNLBruZtffCLposwCgMvk+Yro49J5e9SC1MkIKfWZgp2GT
bf1ELPr7wZD3oFHKjbzUDm4kLUSHCkUQDYjzZ6fQ622qmtviWhlpo2ff4iZGdSfoBIau2Bjq5QSE
9bzOq+CGjpaqyDImNgKqKvJN3e7Sxm6NTJcRgu29WCww8jlQ0HJd0e8C4toJCASzXTU7FjtSpeEm
4+vSU3i8bC713wC9aA3z15in8mIOmNhiijerm0fa7Z8KIWuhQxByWR5AjJ1n649aIBcLfqBvLHTv
oJW5MW9MjfFBUQ2iJsBXhofWngNQykbMSgQ3ydl6XOSLbtlfpgTlcpYGhR7OmTqcvrls9YR/AJeN
ii44ie5I7bZ3/s+2ytnX4Thw7YyrErNhp3PkUgy1OB8YRN+V09VMdMDm/YfRFaKVIdgrnPsogju+
SEHqhSN4gABnQ9N0yxhHdqzgnaDTOPGe70wjy4Fd8BNOf4/bGpgd6Yh/tp4vVLWv4hYPPawq+bVN
KdgpLFaj7tE+wBbLdlNr/LzLANo7br/jWW910Os9k3fERw4AQz/LuVtZn2//ka/CMPj8tqiGD5sl
V9yZO/DlUN82bwJr1NOXgX7lENqisEEn7oukV6vu/WVTUx/mwg06ZXWhWkAlBtq7FpPlN6JJM6M/
AiXKOffKTnGr3oIX0AOMJgHY8h1Y3B5IJLmH6byUO+H1AjNyrQmeq0KRKUA+zPPzaqqTzPCPCXrq
hVphkUOQtM4LjL0zmZ0ifd1txM+zZxWs3KckAXXCt52IVWybnEbiY/91XJsSTtYnY8yFd/AnjNVD
f9/3Ng44KISMsAO8NRA8ZKtFAa5GGjuhzuBAnXvVCmVrNJaLgA0NJgrsWbLzSlMhL7yKH0hgzpbZ
IedpVjmK9BpayZB7nOjlBKSnWWtoCmZC+edAfO7vnsJPoiuJXm5nzfWj/03HTlo7rjdkgDj+7MSk
VcTSoD0RvsfGZVqboEORhM/CKfav7XWeKM3lo2HMgHfatq2QDRcXZVDb9BR4oMSf0LyW4IeELCVN
IPt6O+/soDYd7I5T29FTDwgGXy3pdSSgJ8yBRPsMkfOYNgb60KWwd0VIaEXIE0koAT2sumeG1D4W
XZKhmF1iGl4K6yJPo1f0OhStlyTEg6rvq/mZf3jFA0IvNWmipLAieYptScHR7A7LDmb0ue0ospGY
9KpFXdZatH5Oy91S1GtPT0MR6bDgBMu8x8xLKx3otS+RKe7HUGjkMHzA+Zvh1qoX3qS4Nu0Niuuu
rUAd8F3GTbm/Ez/HZ499EUNUH9jAncY86RtycqCZZU5gVre8SgcKfL7rNrCnG6WSbZlSPEaH3xdu
o1R2tH3eL/JHUHtQB9EM3NVdGK4OkXxG5lp0eh1W46GRUb/z9FNVtpF9ejecYFus73xbDsezstw9
0xVQgETN7bTlhkzHyZckLUhCYi4lbHLZXrchdkz9/7UItmvtceM+AOS9yhzosVFVZKVlnQQpNwNj
imOhWtCfv2QJmKA1/L+EIuBANolotcF/+sgtyGlC//F5Q2Xb2aZJ0g90CDP8ZV+T87De9j50kAi0
TXOCiEzWWBfoM9GTdVjbdrJ+eLbYL20CXBvN4dlZKbsd6XfxDp9PtOdmn55YqOaXBNo1CX9MGZM5
N9xPAzYf+2gyJH6qFIjR4VRJkTibOCyhlmvqs7NtV1TheZdGHZdMUuNzWbG6ItB+OSA47UxnYu8I
fsaGT/B8SOqOmcrN+8plh6q344QwLaV+2xDITMz2Agll+xoHBm5hloCMYQd0cnUcYhg2LvOT6APS
oIPJnQLGYmo2fyziBiiFFIstzPZeOCL97rFiVMHq0jVCdpD1dH2Rn+GmG4WubQCk2eTyQyxIfFTV
8smVr7U3th8GmkwBNqMw1CYE2yLDQi+dhAh0MdgV1NFyBk4iUsFh9wlag8BT//QS1qBJQB6xt84R
BD+JrbUSiAR8ydRysDLb5F28rrhbL166xA2Pc4v62Dfoz5Wevp55YnWhuksj8DhOM5GTqjlM/f8f
YE0qpKt5OZz+v0TVPFwdHHPyLJAPdRo0enauplZagGh9fbXWQRO8wcNyeaRqxvbjtPOP8gM1R0Rz
B5J/yH6qq/sGifqCM39DRHkgEx72vnwAy3AqIHGfZOlvR329WnIcPzT4DQFzE1TZd3rw5sGfFe8K
qJ8cx6zdBD44Svv+H2AD6hsYoNKtVTt9p6CJ8X8eqsieYiqk1cCVPbArCWFPVhWkUdRRQ/aldVHE
yH1PYwAJW651eXXX+iFZHQh1uiDmk6yZfee08X6Twk/pc/IhzYFCcaY9QkPPDzS8hMy4O6/WC2xo
Ui9NsAfBx7+h4IOXgPn9Wyc1mWoQ/oDIYDNX6uuInmWeorrJdLVcnXZ+lhdaIkPw1S7u9sPay8qD
rXIT/YiPwqjUglpvQaOxqjAZdTUi5u1hiiywaxwLnUR6LZCRc1DkdMzsw4y6RTuhWWy0S/0YFf3h
GzhI06x2CwGpjYLlENgcLMCb+ASrmiSNJmUUdI2EDgUytgMgwQ7NAste9gMqsu/NEvATDS2ji/8X
TbzfHXZ/z9sIFJdESc8qOIOhonr45DleUCXKPmndi7da5CEmpH8N3Otjn7Vk0ohPrjvu4EHEfR1/
ArxhjrvZCL0HP/4YU6aCSyxpdbwXCRgJOFTBnKuXQ8rpPHP1vxMeOjENwyK3TG+zlhUHysnm79bc
XZ/PrSRVCPdZIshbape0Nz3baT6HONZ/Vx/LHSFM38H9GxoEDJ0cZGjUkzGdCZ2qwxcaI/ou4PEn
HnyqpO45fHVaekY8sPhlK5IpgSkHG8asMBjrMPh7wsW15uu8w9lFXHl4I0r8YapqhcoyhpJwrArk
lBaV5q6IVueJIwzPSyxuxPkTlPErODA8RlogisH/PBuoLqrhEW6aM1NCRPu9EptNfGfU+pfz2hyj
FVIgVOHE6Vm5+JUa8LblWjX7QkEtxrG8ZOTUec0GYBgag4PatV/hvxntGKAvKs/BY/SYaZEYJfU0
OR5HxhrPuE9w2y/h1alVopWiAtGhFzQCO5NKdM8uA3zXaSuvBAPYg46/8BgG8jiMmrBgxLe/CjKV
Pl/EYSQ0Ud9MJjl+ykHTmXwkT8jS0dDH4fUgbZ19DEwcY+8+jaCrbKMv9FttTL3KlFwV+WCVIpVn
ubGLEaMydRZhukM3hgodoMYBlmkLhodXXLUQwo8MtPa/xjj4aNBeACUton5MtWRdjbh7m5SBBz0c
pUyHjPHiOLKp6UpoLSXQzS8gqFTAKv7UWwWswBSa5Ds8o6+Ji2CeXTdibztplIQLFgs65oA+EHmZ
wJAJ+uUj3z4pa4esJ+ILb1pyVLIp6uCCNdzgE50aG9x9ASDfZKcuzpMPsOLWuPYjp0kB8U+yucjK
32tQm7CInvUrUmhlv3KnHORpcnnuFbYRfKk+y7EeiOZtpu+DPKlkrG1XMO6I93DdYRP8MwP1DUVL
fZ9vVKS1BhKTz80PAGiHgT3AUf3r0efVdJH9KQuJjmrDVuwcIPildYHhEmZjxul+1QgXkYf8n1Xi
SMmRKBGbHX/ile3RFlQIBUQ4rGmKgP4RV3xicYnEt6nFuvWE7aNIh8td/obF9m5i3ZXEU3cLJGmu
9QltWbxkAnHMYVRrWItQH55ABjfnw1j78n9xz2bwZMV8eDW3FpWp5fmzwUCZyeGkiho5BnLW