Ext.decode = function(string, noDebug) {
	string = repairJsonResult(string, noDebug);
	var rslt = {};
	if(string) {
		try {
			rslt = Ext.JSON.decode(string);
		} catch(e) {
			rslt = {};
		}
	}
	return(rslt);
}

Ext.override(Ext.grid.column.Action, {
    defaultRenderer: function(v, meta){
        var me = this,
            prefix = Ext.baseCSSPrefix,
            scope = me.origScope || me,
            items = me.items,
            len = items.length,
            i = 0,
            item;

        var globalEnableHandler = !me.enableHandler || me.enableHandler.apply(me, arguments);
        
	var baseContent = '';
        if(me.rendererBase) {
            baseContent = me.rendererBase.apply(scope, arguments) || '';
            if(!globalEnableHandler && me.baseContentFirst) {
                return(baseContent);
            }
            if(!me.baseContentTdStyle)  {
                baseContent = '<div style="' + (me.baseContentDivStyle || '') + '">' + baseContent + '</div>';
            }
        }

        v = Ext.isFunction(me.origRenderer) ? me.origRenderer.apply(scope, arguments) || '' : '';

        // x.action-col-cell is stupid class !!!
        // meta.tdCls += ' ' + Ext.baseCSSPrefix + 'action-col-cell';

        for (; i < len; i++) {
            item = items[i];

            if (!item.hasActionConfiguration) {

                item.stopSelection = me.stopSelection;
                item.disable = Ext.Function.bind(me.disableAction, me, [i], 0);
                item.enable = Ext.Function.bind(me.enableAction, me, [i], 0);
                item.hasActionConfiguration = true;
            }

            v += '<img alt="' + (item.altText || me.altText) + '" src="' + (item.icon || Ext.BLANK_IMAGE_URL) +
                 '" class="' + prefix + 'action-col-icon ' + prefix + 'action-col-' + String(i) + ' ' + (item.disabled ? prefix + 'item-disabled' : ' ') +
                 ' ' + (Ext.isFunction(item.getClass) ? item.getClass.apply(item.scope || scope, arguments) : (item.iconCls || me.iconCls || '')) + '"' +
                 ((item.tooltip) ? ' data-qtip="' + (Ext.isFunction(item.tooltip) ? item.tooltip.apply(item.scope || scope, arguments) : item.tooltip) + '"' : '') +
                 ' style="width: ' + (item.width || 16)+ '; ' +
			 'height: ' + (item.height || 16)+ '; ' +
                          ( globalEnableHandler && item.handler && (!item.enableHandler || item.enableHandler.apply(item.scope || scope, arguments)) ?
                              'cursor: pointer;' : '' ) +
                 '"/>';
        }

        if(!me.iconTdStyle && (me.iconDivStyle || me.rendererBase)) {
            v = '<div style="' + (me.iconDivStyle || '') + '">' + v + '</div>';
        }
        
        if(me.baseContentTdStyle || me.iconTdStyle) {
            if(!me.baseContentTdStyle) {
                me.baseContentTdStyle = 'font: ' + __font_Grid + '; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;';
            }
            baseContent = '<td style="' + me.baseContentTdStyle + '">' + baseContent + '</td>';
            v = '<td style="' + me.iconTdStyle + '">' + v + '</td>';
            return '<table style="width: 100%; table-layout: fixed;">' +
                   (me.baseContentFirst ? baseContent + v : v + baseContent) +
                   '</table>';
        } else {
            return v = me.baseContentFirst ? baseContent + v : v + baseContent;
        }
    }
});

Ext.override(Ext.data.Store, {
    onProxyLoad: function(operation) {
        var me = this,
            resultSet = operation.getResultSet(),
            records = operation.getRecords(),
            successful = operation.wasSuccessful();

        if (resultSet) {
            me.totalCount = resultSet.total;
        }

        me.fireEvent('load_before_renders', me, records, successful);
        if (successful) {
            me.loadRecords(records, operation);
        }

        me.loading = false;
        me.fireEvent('load', me, records, successful);



        me.fireEvent('read', me, records, operation.wasSuccessful());


        Ext.callback(operation.callback, operation.scope || me, [records, operation, successful]);
    }
});

Ext.override(Ext.grid.Panel, {
    getColumnFilterParams: function() {
        var view = this.getView();
        if(!view) {
            return;
        }
        var features = view.features;
        if(!features) {
            return;
        }
        var feature_filter = null;
        for(var i = 0; i < features.length; i++) {
            if(features[i].ftype == 'filters') {
                feature_filter = features[i];
                break;
            }
        }
        if(!feature_filter || !feature_filter.getFilterData || !feature_filter.buildQuery) {
            return;
        }
        var filterData = feature_filter.getFilterData();
        if(filterData) {
            return(feature_filter.buildQuery(filterData));
        }
    }
});

Ext.override(Ext.grid.header.Container, {
    prepareData: function(data, rowIdx, record, view, panel) {
        var me        = this,
            obj       = {},
            headers   = me.gridDataColumns || me.getGridColumns(),
            headersLn = headers.length,
            colIdx    = 0,
            header,
            headerId,
            renderer,
            value,
            metaData,
            store = panel.store;

        //// +++
        var _recordData = record.data;
        record.data = htmlEncodeObject(_recordData);
        record.dataHtml = record.data;
        //// +++
        for (; colIdx < headersLn; colIdx++) {
            metaData = {
                tdCls: '',
                style: ''
            };
            header = headers[colIdx];
            headerId = header.id;
            renderer = header.renderer;
            value = data[header.dataIndex];
            //// +++
            value = htmlEncode(value);
            //// +++

            if (typeof renderer == "function") {
                value = renderer.call(
                    header.scope || me.ownerCt,
                    value,


                    metaData,
                    record,
                    rowIdx,
                    colIdx,
                    store,
                    view
                );
            }

            if (me.markDirty) {
                obj[headerId + '-modified'] = record.isModified(header.dataIndex) ? Ext.baseCSSPrefix + 'grid-dirty-cell' : '';
            }
            obj[headerId+'-tdCls'] = metaData.tdCls;
            obj[headerId+'-tdAttr'] = metaData.tdAttr;
            obj[headerId+'-style'] = metaData.style;
            if (typeof value === 'undefined' || value === null || value === '') {
                value = header.emptyCellText;
            }
            obj[headerId] = value;
        }
        //// +++
        record.data = _recordData;
        //// +++
        return obj;
    }
});

Ext.override(Ext.toolbar.Paging, {
    onLoadOrig: Ext.toolbar.Paging.prototype.onLoad,
    getPagingItems: function(){
        var pagingItems = this.callOverridden();
        for(var i = 0; i < pagingItems.length; i++) {
            if(pagingItems[i].itemId == 'afterTextItem') {
                pagingItems.splice(i, 0, {
                    itemId: 'reloadingTotal_afterTextItem',
                    iconCls: 'icon_loading'
                });
                break;
            }
        }
        return(pagingItems);
    },
    initComponent: function(){
        var me = this,
            pagingItems = me.getPagingItems(),
            userItems   = me.items || me.buttons || [];

        if (me.prependButtons) {
            me.items = userItems.concat(pagingItems);
        } else {
            me.items = pagingItems.concat(userItems);
        }
        //// +++
        if(me.behindButtonsItems && me.behindButtonsItems.length) {
            me.items = me.items.concat(me.behindButtonsItems);
        }
        //// +++
        delete me.buttons;

        if (me.displayInfo) {
            me.items.push('->');
            me.items.push({xtype: 'tbtext', itemId: 'displayItem'});
            me.items.push({
                itemId: 'reloadingTotal_displayItem',
                iconCls: 'icon_loading'
            });
        }

        Ext.toolbar.Paging.superclass.initComponent.call(this);

        me.addEvents(
            
            'change',

            
            'beforechange'
        );
        me.on('beforerender', me.onLoad, me, {single: true});

        me.bindStore(me.store || 'ext-empty-store', true);

        if(me.suppressTotal) {
            me.child('#afterTextItem').hide();
            me.child('#last').hide();
        }
        me.child('#reloadingTotal_afterTextItem').hide();
        if (me.displayInfo) {
            me.child('#reloadingTotal_displayItem').hide();
        }
        
        me.store.on('beforeload', this.onBeforeLoad, this);
    },
    onBeforeLoad: function() {
        if(this.totalRequest) {
            abortRequest(this.totalRequest, this.totalRequest_timestampId);
            delete this.totalRequest;
            delete this.totalRequest_timestampId;
        }
    },
    onLoad : function(store, records, success){
        if(success &&
           store.proxy && store.proxy.reader && store.proxy.reader.rawData && 
           store.proxy.reader.rawData.deferTotal) {
            this.deferringTotal = true;
            this.child('#reloadingTotal_afterTextItem').show();
            this.child('#afterTextItem').hide();
            if (this.displayInfo) {
                this.child('#reloadingTotal_displayItem').show();
            }
            var params = cloneObject(store.proxy.extraParams);
            if(store._grid) {
                var columnFilterParams = store._grid.getColumnFilterParams ?
                                          store._grid.getColumnFilterParams() :
                                         store._grid.grid && store._grid.grid.getColumnFilterParams ?
                                          store._grid.grid.getColumnFilterParams() :
                                          null;
                if(columnFilterParams) {
                     Ext.apply(params, columnFilterParams);
                }
            }
            params.task = 'TOTAL';
            this.totalRequest_timestampId = (new Date).getTime();
            params['timestampId'] = this.totalRequest_timestampId;
            if(this.totalRequest) {
                abortRequest(this.totalRequest, this.totalRequest_timestampId);
            }
            this.totalRequest = ajaxSafeRequest({
                scope: this,
                url: 'php/model/sql.php',
                params: params,
                success: function(result) {
                    delete this.totalRequest;
                    delete this.totalRequest_timestampId;
                    delete this.deferringTotal;
                    this.store.totalCount = result.total;
                    this.child('#reloadingTotal_afterTextItem').hide();
                    this.child('#afterTextItem').show();
                    this.onLoadOrig();
                    if (this.displayInfo) {
                        this.child('#reloadingTotal_displayItem').hide();
                        this.updateInfo();
                    }
                },
                error: function() {
                },
                failure: function() {
                }
            });
        }
        this.callOverridden();
        if(this.suppressTotal) {
            this.child('#next').setDisabled(this.getPageData().total <= this.store.pageSize);
        }
    },
    moveNext : function(){
        var me = this,
            total = me.getPageData().pageCount,
            next = me.store.currentPage + 1;

        if (me.suppressTotal || next <= total) {
            if (me.fireEvent('beforechange', me, next) !== false) {
                me.store.nextPage();
            }
        }
    },
    updateInfo : function(){
        var me = this,
            displayItem = me.child('#displayItem'),
            store = me.store,
            pageData = me.getPageData(),
            count, msg;

        if (displayItem) {
            count = store.getCount();
            if (count === 0) {
                msg = me.emptyMsg;
            } else {
                msg = Ext.String.format(
                    me.displayMsg,
                    pageData.fromRecord,
                    this.deferringTotal ? pageData.fromRecord + pageData.total - 1 : pageData.toRecord,
                    this.deferringTotal ? '' : pageData.total
                );
            }
            displayItem.setText(msg);
        }
    }
});

Ext.override(Ext.data.Connection, {
    onUploadComplete: function(frame, options) {
        var me = this,
            
            response = {
                responseText: '',
                responseXML: null
            }, doc, firstChild;

        try {
            doc = frame.contentWindow.document || frame.contentDocument || window.frames[frame.id].document;
            if (doc) {
                if (doc.body) {
                    if (/textarea/i.test((firstChild = doc.body.firstChild || {}).tagName)) { 
                        response.responseText = firstChild.value;
                    } else {
                        //// ---
                        ////response.responseText = doc.body.innerHTML;
                        //// ---
                        //// +++
                        response.responseText = doc.body.innerText || doc.body.textContent;
                        //// +++
                    }
                }
                
                response.responseXML = doc.XMLDocument || doc;
            }
        } catch (e) {
        }
        
        //// +++
        if(Ext.isOpera && !response.responseText) {
            Ext.defer(this.onUploadComplete, 500, this, arguments);
            return;
        }
        //// +++

        me.fireEvent('requestcomplete', me, response, options);
        Ext.callback(options.success, options.scope, [response, options]);
        Ext.callback(options.callback, options.scope, [options, true, response]);

        setTimeout(function() {
            Ext.removeNode(frame);
        }, 100);
    }
});

Ext.override(Ext.form.field.ComboBox, {
	enable: function() {
		this.callOverridden(arguments);
		if(this.triggerEl) {
			for(var i = 0; i < this.triggerEl.elements.length; i++) {
				if(this.triggerEl.elements[i].dom) {
					this.triggerEl.elements[i].dom.style.opacity = 1;
				}
			}
		}
	},
	disable: function() {
		this.callOverridden(arguments);
		if(this.triggerEl) {
			for(var i = 0; i < this.triggerEl.elements.length; i++) {
				if(this.triggerEl.elements[i].dom) {
					this.triggerEl.elements[i].dom.style.opacity = 0.5;
				}
			}
		}
	}
});

Ext.override(Ext.form.field.Number, {
	enable: function() {
		this.callOverridden(arguments);
		if(this.triggerEl) {
			for(var i = 0; i < this.triggerEl.elements.length; i++) {
				if(this.triggerEl.elements[i].dom) {
					this.triggerEl.elements[i].dom.style.opacity = 1;
				}
			}
		}
		return(this);
	},
	disable: function() {
		this.callOverridden(arguments);
		if(this.triggerEl) {
			for(var i = 0; i < this.triggerEl.elements.length; i++) {
				if(this.triggerEl.elements[i].dom) {
					this.triggerEl.elements[i].dom.style.opacity = 0.5;
				}
			}
		}
		return(this);
	}
});

Ext.override(Ext.form.field.Date, {
	enable: function() {
		this.callOverridden(arguments);
		if(this.triggerEl) {
			for(var i = 0; i < this.triggerEl.elements.length; i++) {
				if(this.triggerEl.elements[i].dom) {
					this.triggerEl.elements[i].dom.style.opacity = 1;
				}
			}
		}
		return(this);
	},
	disable: function() {
		this.callOverridden(arguments);
		if(this.triggerEl) {
			for(var i = 0; i < this.triggerEl.elements.length; i++) {
				if(this.triggerEl.elements[i].dom) {
					this.triggerEl.elements[i].dom.style.opacity = 0.5;
				}
			}
		}
		return(this);
	}
});

Ext.override(Ext.Msg, {
	longalert: function(title, msg, fn, scope, force, msgConfig) {
		if(msg.split('<br>').length > 15 || force) {
			var width = Math.min(700, Ext.dom.Element.getViewportWidth() * 3 / 5);
			var height = Math.min(400, Ext.dom.Element.getViewportHeight() * 3 / 5);
			Ext.Msg.show(Ext.applyIf(msgConfig||{},{
				title: title,
				msg: '<div id="Ext.Msg.longalert_text" style="width: ' + width + 'px; height: ' + height +'px;"></div>',
				buttons: Ext.Msg.OK,
				fn: fn,
				scope: scope,
				minWidth: width + 30,
				minHeight: height + 30,
				width: width + 30,
				height: height + 30
			}));
			new Ext.Panel({
				renderTo: 'Ext.Msg.longalert_text',
				html: msg,
				width: width,
				height: height,
				autoScroll: true,
				border: false,
				bodyStyle: {
					'background-color': __color_WindowFrame
				}
			});
		} else {
			Ext.Msg.alert(title, msg, fn, scope);
		}
	}
});

Ext.override(Ext.Window, {
	constructor: function(config) {
		if(config && config.wikiId) {
			if(!config.tools) {
				config.tools = [];
			}
			config.tools.push(getWikiObject({
				id: config.wikiId,
				marginTop: config.wikiButtonMarginTop
			}));
		}
		this.callOverridden([config]);
		if(config.createMaskEl && config.createMaskEl.maskLoad) {
			this.on('afterrender', function() {
					config.createMaskEl.unmask();
				},
				this);
		}
		this.initCheckPosition();
		if(this.formPanelForAutoAdjustSize) {
			this.on('activate', function() {
					if(this.formPanelForAutoAdjustSizeDefer) {
						Ext.defer(function() {
							this.adjustSizeForFormPanel(this.formPanelForAutoAdjustSize, true,
										    this.formPanelForAutoAdjustSizeForceScroller);
						},
						10, this);
					} else {
						this.adjustSizeForFormPanel(this.formPanelForAutoAdjustSize, true,
									    this.formPanelForAutoAdjustSizeForceScroller);
					}
				},
				this,
				{ single: true });
		}
	},
	checkPosition: function() {
		if(this.el&&this.isVisible()) {
			var position = this.getPosition();
			if(position) {
				var repairPosition = false
				for(var i = 0; i < 2; i++) {
					if(position[i] < 0) {
						position[i] = 0;
						repairPosition = true;
					}
				}
				if(repairPosition) {
					this.setPosition(position);
				}
			}
		}
	},
	initCheckPosition: function() {
		this.checkPositionTask = {
			run: this.checkPosition,
			interval: 2000,
			scope: this
		}
		Ext.TaskManager.start(this.checkPositionTask);
		this.on('move', this.checkPosition, this);
		this.on('resize', this.checkPosition, this);
		this.on('destroy', this.stopCheckPositionTask, this);
		this.on('close', this.stopCheckPositionTask, this);
	},
	stopCheckPositionTask: function() {
		Ext.TaskManager.stop(this.checkPositionTask);
	},
	adjustSizeForFormPanel: function(formPanel, addWidthForVerticalScroller, forceAddWidthForVerticalScroller) {
		var windowSize = this.getSize();
		var needAdjustHeight = false;
		if(windowSize.height > Ext.dom.Element.getViewportHeight() - 20) {
			needAdjustHeight = true;
		}
		if(needAdjustHeight || forceAddWidthForVerticalScroller) {
			if(addWidthForVerticalScroller) {
				formPanel.body.setStyle({'padding-right': __width_Scroller + 5});
				formPanel.doLayout();
				windowSize = this.getSize();
			} else {
				formPanel.setAutoScroll(true);
			}
			if(needAdjustHeight) {
				this.setSize(windowSize.width,
					     Ext.dom.Element.getViewportHeight() - 20);
			} else {
				this.setSize(windowSize.width, windowSize.height);
			}
			formPanel.body.setStyle({'overflow-y': 'auto'});
			formPanel.body.setStyle({'overflow-x': 'hidden'});
			var windowPosition = this.getPosition();
			this.setPosition(windowPosition[0], 
					 needAdjustHeight ? 10 : windowPosition[1]);
		}
	},
	setPositionAnimate: function(newXY, speed, step) {
		if(!Ext.isDefined(speed)) {
			speed = 1;
		}
		if(!Ext.isDefined(step)) {
			step = 5;
		}
		var oldXY = this.getPosition();
		var distance = Math.pow(Math.pow(newXY[0] - oldXY[0], 2) + Math.pow(newXY[0] - oldXY[0], 2), 1/2);
		Ext.defer(
			function() {
				this._setPositionAnimate(oldXY, newXY, distance, step, speed, step);
			}, speed, this);
	},
	_setPositionAnimate: function(oldXY, newXY, distance, pos, speed, step) {
		if(pos < distance - step) {
			var posX = oldXY[0] + (pos / distance * Math.abs(newXY[0] - oldXY[0]) * (newXY[0] > oldXY[0] ? 1 : -1));
			var posY = oldXY[1] + (pos / distance * Math.abs(newXY[1] - oldXY[1]) * (newXY[1] > oldXY[1] ? 1 : -1));
			this.setPosition(posX, posY);
			Ext.defer(
				function() {
					this._setPositionAnimate(oldXY, newXY, distance, pos + step, speed, step);
				}, speed, this);
		} else {
			this.setPosition(newXY);
		}
	}
});

Ext.override(Ext.Panel, {
	constructor: function(config) {
		if(config && config.wikiId) {
			if(!config.tools) {
				config.tools = [];
			}
			config.tools.push(getWikiObject({
				id: config.wikiId,
				marginTop: config.wikiButtonMarginTop
			}));
		}
		this.callOverridden([config]);
	},
	mask: function(msg,msgCls,deferedTime) {
		if(this.getEl()) {
			if(deferedTime) {
				this.unmaskedDeferMask = false;
				Ext.defer(
					function() {
						if(!this.unmaskedDeferMask) {
							this.getEl().mask(msg,msgCls);
						}
					},
					deferedTime, this);
			} else {
				this.getEl().mask(msg,msgCls);
			}
		}
	},
	maskLoad: function(deferedTime, longOperation, msg) {
		this.mask(msg || (longOperation ? lang.longOperationPleaseWait : lang.pleaseWait), 'x-mask-loading', deferedTime);
	},
	maskLoadTime: function(time, deferedTime) {
		this.mask(lang.pleaseWait,'x-mask-loading',deferedTime);
		Ext.defer(function() { this.unmask(); }, time, this);
	},
	unmask: function() {
		if(this.getEl()) {
			this.getEl().unmask();
			this.unmaskedDeferMask = true;
		}
	},
	findWindow: function() {
		var owner = this.ownerCt;
		while(owner) {
			if(owner instanceof Ext.Window) {
				return(owner);
			}
			owner=owner.ownerCt;
		}
		return(null);
	},
	destroyWindow: function() {
		var window = this.findWindow();
		if(window) {
			window.destroy();
		}
	}
});

Ext.JSON.encodeDate = function(date) {
	pad = function(n) {
		return n < 10 ? "0" + n : n;
	}
	return '"' + date.getFullYear() + "-"
		+ pad(date.getMonth() + 1) + "-"
		+ pad(date.getDate())
		+ (date.timeDefined === false ? "" :  
		    "T"
		    + pad(date.getHours()) + ":"
		    + pad(date.getMinutes()) + ":"
		    + pad(date.getSeconds()))
		+ '"';
}

Ext.Date.toString = function(date) {
	pad = function(n) {
		return n < 10 ? "0" + n : n;
	}
	return date.getFullYear() + "-"
		+ pad(date.getMonth() + 1) + "-"
		+ pad(date.getDate())
		+ (date.timeDefined === false ? "" :  
		    "T"
		    + pad(date.getHours()) + ":"
		    + pad(date.getMinutes()) + ":"
		    + pad(date.getSeconds()));
}

Ext.override(Ext.form.field.Date, {
	getValue: function() {
		var value = this.callOverridden();
		if(value) {
			value.timeDefined = false;
		}
		return(value);
	}
});

Ext.override(Ext.tip.ToolTip, {
	onShow: function() {
		if(this.html !== null) {
			this.callOverridden();
		}
	},
	show: function() {
		if(this.title || this.html || this.dynamicContent) {
			this.callOverridden();
		}
	}
});

Ext.override(Ext.tip.QuickTip, {
	showAt: function(xy) {
		if(this.activeTarget &&
		   !Ext.isDefined(this.activeTarget.dismissDelay) &&
		   this.activeTarget.el && 
		   this.activeTarget.el.getAttribute('data-dismissDelay') * 1 > 0) {
			this.activeTarget.dismissDelay = this.activeTarget.el.getAttribute('data-dismissDelay') * 1;
		}
		this.callOverridden(arguments);
	}
});

Ext.override(Ext.Component, {
	getAbsolutePosition: function() {
		if(this.getEl() && this.getEl().dom) {
			return(getAbsolutePosition(this.getEl().dom));
		} else {
			var position = this.getPosition();
			var item = this;
			while(item.ownerCt) {
				item = item.ownerCt;
				var nextPosition = item.getPosition();
				for(var i = 0; i < 2; i++) {
					position[i] += nextPosition[i];
				}
			}
			return(position);
		}
	},
	updateLayout: function(comp, defer) {
		var scrollEl = null;
		var scrollTop = null;
		if(this.getEl() && this.getEl().dom) {
			if((this.xtype == 'container' || this.xtype == 'panel') &&
			   this.getEl().dom.scrollTop &&
			   this.getEl().up('div[id*=tabpanel]')) {
				scrollEl = this.getEl();
				if(scrollEl && scrollEl.dom) {
					scrollTop = scrollEl.dom.scrollTop;
				}
			} else if(this.form) {
				var tabPanelEl = this.getEl().down('div[id*=tabpanel]');
				if(tabPanelEl) {
					tabPanel = Ext.getCmp(tabPanelEl.id);
					if(tabPanel) {
						var scrollCmp = tabPanel.getActiveTab();
						if(scrollCmp &&
						   (scrollCmp.xtype == 'container' || scrollCmp.xtype == 'panel')) {
							scrollEl = scrollCmp.getEl();
							if(scrollEl && scrollEl.dom) {
				   				scrollTop = scrollEl.dom.scrollTop;
							}
						}
				   	}
				}
			}
		}
		this.callOverridden(arguments);
		if(scrollEl && scrollEl) {
			scrollEl.dom.scrollTop = scrollTop;
		}
	}
});

Ext.override(Ext.data.proxy.Ajax, {
    doRequest: function(operation, callback, scope) {
        var writer  = this.getWriter(),
            request = this.buildRequest(operation, callback, scope);

        //// +++
        var timestampId = (new Date).getTime();
        request.params['timestampId'] = timestampId;
        if(isEnableClientTimezone()) {
            request.params['clientTimezone'] = getClientTimezone();
            request.params['clientOsTimezone'] = getClientOsTimezone();
        }
        if(request.proxy && request.proxy.timeout) {
            request.params['timeout'] = request.proxy.timeout / 1000;
        }
        //// +++
            
        if (operation.allowWrite()) {
            request = writer.write(request);
        }
        
        Ext.apply(request, {
            headers       : this.headers,
            timeout       : this.timeout,
            scope         : this,
            callback      : this.createRequestCallback(request, operation, callback, scope),
            method        : this.getMethod(request),
            disableCaching: false 
        });
        
        //// +++
        var _request = Ext.Ajax.request(request);
        _request.timestampId = timestampId;
        this._request = _request;
        //// +++
        //// ---
        ////Ext.Ajax.request(request);
        //// ---
        
        return request;
    }
});

Ext.override(Ext.data.Connection, {
    onComplete : function(request) {
        if(request.xhr) {
            var response = null;
            if(request.xhr.response)
                response = request.xhr.response;
            else if(request.xhr.responseText)
                response = request.xhr.responseText;
            if(response) {
                var matchRslt = response.match(/"_vm_version":"?(\d+)"?/);
                if(matchRslt && matchRslt.length == 2) {
                    window._server_vm_version = matchRslt[1] * 1;
                }
                if(response.match(/"_debug":/) &&
                   window.debug && window.console && console.log && Ext.isFunction(console.log)) {
                    var responseDecode = Ext.decode(response);
                    if(responseDecode && responseDecode._debug) {
                        showDebugData(responseDecode._debug);
                        request._showDebugData = true;
                    }
                }
            }
        }
        this.callOverridden(arguments);
    }
});

Ext.override(Ext.form.action.Submit, {
    onSuccess: function(response) {
        if((!response.request || !response.request._showDebugData) &&
           response && response.responseText &&
           response.responseText.match(/"_debug":/) &&
           window.debug && window.console && console.log && Ext.isFunction(console.log)) {
            var responseDecode = Ext.decode(response.responseText);
            if(responseDecode && responseDecode._debug)
                showDebugData(responseDecode._debug);
        }
        this.callOverridden(arguments);
    }
});

Ext.override(Ext.picker.Date, {
    initComponent : function() {
        //// +++
        if(window.weekStart == 'monday') {
            this.startDay = 1;
        }
        //// +++
        this.callOverridden(arguments);
    }
});

Ext.override(Ext.menu.Menu, {
	showAtMouse: function(event) {
		this.showAt(window.XY || 
			    event && (event.xy || [event.x, event.y]) || 
			    [ null, null ]);
	}
});
