Ext.define('Ext.ux.form.IconCombo', {
	extend:'Ext.form.field.ComboBox',
	alias:'widget.iconcombo',
	initComponent: function() {
		Ext.apply(this, {
			listConfig: {
				iconClsField:this.iconClsField,
				getInnerTpl: function() {
					return '<tpl for=".">'
						+ '<div class="x-combo-list-item ux-icon-combo-item '
						+ '{' +this.iconClsField+ '}">'
						+ '{' + this.displayField + '}'
						+ '</div></tpl>';
				}
			},
			fieldSubTpl: [
				'<div class="{hiddenDataCls}" role="presentation"></div>',
				'<div class="ux-icon-combo-wrap">',
				'<input id="{id}" type="{type}" {inputAttrTpl}',
				'<tpl if="value"> value="{value}"</tpl>',
				'<tpl if="name"> name="{name}"</tpl>',
				'<tpl if="placeholder"> placeholder="{placeholder}"</tpl>',
				'<tpl if="size"> size="{size}"</tpl>',
				'<tpl if="maxLength !== undefined"> maxlength="{maxLength}"</tpl>',
				'<tpl if="readOnly"> readonly="readonly"</tpl>',
				'<tpl if="disabled"> disabled="disabled"</tpl>',
				'<tpl if="tabIdx"> tabIndex="{tabIdx}"</tpl>',
				'<tpl if="fieldStyle"> style="{fieldStyle}"</tpl>',
				'class="{fieldCls} {typeCls}" autocomplete="off" />',
				'</div>',
			{
				compiled: true,
				disableFormats: true
			} ]
		});
		this.callParent(arguments);

		},
	onRender: function(ct, position) {
		this.callParent(arguments);
		var wrap = this.el.down('div.ux-icon-combo-wrap');
		if(wrap) {
			wrap.applyStyles({position:'relative'});
			this.icon = Ext.core.DomHelper.append(wrap, {
				tag: 'div',
				style:'position:absolute'
			});
		}
		var input = this.el.down('input');
		if(input) {
			input.addCls('ux-icon-combo-input');
		}
	},
	setIconCls: function() {
		if(this.rendered) {
			var rec = this.store.findRecord(this.valueField, this.getValue());
			if(rec) {
				this.icon.className = 'ux-icon-combo-icon ' + rec.get(this.iconClsField);
			}
		} else {
			this.on('render', this.setIconCls, this, { single: true });
		}
	},
	setValue: function(value) {
		this.callParent(arguments);
		this.setIconCls();
	}
});
