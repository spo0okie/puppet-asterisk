var page = require('webpage').create();
var fs = require('fs');
page.content = fs.read('/dev/stdin');

page.onError = function (msg, trace) {
	fs.write('/dev/stderr', 'ERROR: ' + msg + '\n', 'w');
	trace.forEach(function(item) {
		fs.write('/dev/stderr', 'trace: ' + item.file + ' : ' + item.line + '\n', 'w');
	});
	phantom.exit(2);
};

var i = 0;
window.setInterval(function() {
	if(i > 40) {
		phantom.exit(1);
	}
	if(page.evaluate(function() { return window.chart && window.chart.surface && window.chart.rendered; })) {
		var svg = page.evaluate(function() { return Ext.draw.engine.SvgExporter.self.generate({}, window.chart.surface); });
		if(svg) {
			console.log(svg);
			phantom.exit(0);
		}
	}
	++i;
}, 250);
