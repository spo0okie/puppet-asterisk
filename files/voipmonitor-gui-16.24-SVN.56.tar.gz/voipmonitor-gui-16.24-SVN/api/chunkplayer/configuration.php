<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPyfJcDC1kM3ak+KDyEdycsIkSa9ZBrNZ5OpVJMgfZrqbL8Vq/agxw1otvKILgMyuBMQj+Uvf
R71BeGjgxedCqf3LJtdsUSCDfd2kZiaGU/2sDUIX6Tt+I9Xku9CsbheUPpHirmY9hdTdmQJ3fLdf
k1PHpVukRBE4vJLJhqW1+KEzh4HxRTOkBtyV1RGXnqCFM4pIfZTxeNs4ei6mRuBwLtAkdUEyKKWM
bUrC27dps2jyFq2ae0ZXqTVIqemeZeIh+NkMhKgTLmY0ox8HZXrL1kukZkPmTlfg+P06jIvxz6QE
mlNhu5pkYBm41lMtZWm9h7zveMSFFHBOdDs2YmgZ1gHKEXcLLjx1vpug9laWkFTYEw7l/g0WRqkp
auw4uI7FpXVSHYjO73yzBgFkq6pRWcxhYW2I0980Zm2R08u091KwAT/S166Kc8jIVwvZQ54mwIXW
W6+408K0dW2N08O0WG2808y0dW2409S0ARF3ihOLVVxlHguc4h8pscXE8uK1wBVUmE5alV6kP+vP
RjUm95IWeZTGBWt0RpQAGMEG7z8X4G6PgVXjZqrqa2e5s8hXJjexaOT8twT1P4dCkLXMhUTO7ZEV
yKvc6q0XDHUwmFzA8zeDXLNwax0rDlEU4isnutuFnRFeGjCxDzp12zT+nak9iY2OjEpkIRyJ4tGp
+eFWOB7SlkCDo/Y4Jz3SwavjpoQBVxRzf3JUvp4DOszWsHh/dObgqOnrR6Rn2nrcIbbgUQdvcZGZ
jCY8DfnqxRdPdRLGmfbWb9VYYP7Dzpr8nXUoo53eAq6uU21MVtZPumABvucyeCbwhBXrh1bs+Wdo
Yv9XlSTnMvvtyeu+hukcv51eKO93ZioHo1jvV35YUoe83jJBQULrIvcDUqj6vDwXitTQAWie20pP
ghteiNHfywF5/jj/6lGa/2x6GW2nOAwsA3cZan5125Uzj8BEyi56CmQ/VTipZZ89rKzG2qxAKfqP
g9w1qSsRu74K4vo3+PIjB9t7UFpfEA8BM83RlrTxuxPIQPu/Xiuk4SLi9YgBgeEoXTkwMh68UOGv
IXE+/Nx/Fl+gXbOQckSW+J2eJZIPq3hZ2vq6Tnk/4NCK/GPCaTd2bSqOS6ihw86Jg1oCvgJC7ypA
KEZKCtya9NUWSOUuYs23E8m5LDhQGPnNPfYsrvv67AXad26qrR9ipW872MKDSgcWaCUvZJPpZt/K
mktNpdS4vHcpvlTYds2+eiJsFQpSzUndt7yBbGzumh9V/xkE96oCXz8XcXGpq010W7UkDGY+KRab
PsCVLBpMYmzpTdacDDxSwNIgG6/jfl8ceOVvV+Nna/jReBdwXswdQcxazxJ0u/T4Yt7bUov2Odc4
pMls7s70b/+5rG4MJXS+Z+GbgahoylaNPx5FZNoDUms3PGvVLHsDNe8kHBc60ewdcepKAziSBnBR
9RY+MC9byOaAyYUC9/lXXvTaUUbCanz2qd9REQg8DPY+8IrXG3rjcohgnK5SfsHaxgqH8nFb0W7N
B0fG9PXHqFUVKZO868JZroHmqkEMrZYW0D8iiuTP/s1OfoY9Pfus4c+uMSTBHUTuhBSRzUh5alFy
1dpg9cJq+ks4wG0s/Ef0JEVt7jVrFgCEo+Jm9brR8OXnZQa1hSyFPCqU6ZleQhRRWwJwQgx8KvMW
EC9q4xj5LjbxMBo9XBD0CwVJuMy1AV4jurjSVt4bK5FRXWyQ4+QmX+grjSlJywpYLSYBaxwFnasD
l1GPphW7vGOpq1s0f0A0ldDJUJ3UdE8B5CdC8mgBPd+eYq5J0DKnIRpAX7XSmPfSt97v58SwWHmb
FTplDMtEtp/mULbfmVm3WILemCiMtIWASDmgS9DQFlRy8B5XWNSmE9VfKk2UrIyhMAMvjaJm9w3f
BPppGq3enQUVCcwVyHPcIlYUO/lGfLSW2tB3LfAt3bNqZ0==